"""
作業者リポジトリ (WorkerRepository)
作成者: Lynn
----------------------------------
【役割】
「間口操作」や「パレット供給スケジュール」など、現場作業者向けの機能を支えるDB操作クラスです。

【チームへのメリット】
1. 複雑な並べ替えロジックの隠蔽:
   パレットの挿入・削除時に発生する「INDEXのずらし操作（Shift Up/Down）」を
   リポジトリ内で完結させ、上位層にはクリーンな結果だけを返します。
2. 安全な状態遷移:
   `READY -> WORK -> COMP` といった業務ルールに沿った遷移かどうかを、
   DB更新直前に厳格にチェックします。
"""
# app/infrastructure/repositories/worker_repository.py
from __future__ import annotations
from typing import Optional, Iterable, List, Dict
from mysql.connector.cursor import MySQLCursorDict

from app.interfaces.sql.wcs_sql_query import WCSSQLQuery
from app.infrastructure.factory.domain_factory import WorkerFactory
from app.domain.entities import Maguchi, LiftEntrance, PalletScheduleLine, PalletPair

from app.domain.exception import NotFoundError, InvalidStateError, StaleWriteError

from app.infrastructure.setup_log import setup_log
import app.config.config as cfg

# ログ設定 (名前を付ける)
logger = setup_log(cfg.LOG_FOLDER, cfg.WORKER_REPO_LOG_FILE, cfg.BACKUP_DAYS, logger_name="worker_repo")


class WorkerRepository(WorkerFactory):
    """
    現場作業者画面に関連するMySQL操作の具象実装です。
    """

    def __init__(self, db, wcs_sql: WCSSQLQuery, db_name: str = "futaba_ok2_shippment"):
        self._db = db
        self._db_name = db_name
        self._sql = wcs_sql
        logger.info("[WorkerRepository] initialized", extra={"db_name": db_name})

    def list_lift_entrance(self) -> list:
        sql = self._sql.t_lift_station_select_all()
        conn = self._db.get_connection()

        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            rows = cur.fetchall()

            for row in rows:
                pallet_id = row.get("pallet_id")
                status = str(row.get("transport_status", "")).upper()

                if not pallet_id:
                    continue

                # =========================
                # 1. Get pallet from t_pallet_status
                # =========================
                cur.execute("""
                    SELECT ps.pallet_type, m.pallet_name, m.line_id
                    FROM t_pallet_status ps
                    JOIN m_pallet m 
                        ON ps.pallet_type = m.pallet_type
                    WHERE ps.pallet_id = %s
                    LIMIT 1
                """, (pallet_id,))
                pallet_row = cur.fetchone()

                real_name = pallet_row["pallet_name"] if pallet_row else ""

                # ✅ KANBAN detection
                line_id = pallet_row.get("line_id") if pallet_row else None

                cur.execute("""
                    SELECT m.pallet_name
                    FROM t_pallet_supply_pairs p
                    JOIN m_pallet m ON p.pallet_type = m.pallet_type
                    WHERE p.line_id = %s
                    AND p.pair_index = 0
                    LIMIT 1
                """, (line_id,))
                pair_row = cur.fetchone()

                is_kanban = (
                    pair_row and "掛けカンバン" in pair_row["pallet_name"]
                )

                # =====================================================
                # ✅ KANBAN (ALL STATES — PRIORITY FIRST ✅)
                # =====================================================
                if is_kanban:
                    row["pallet_name"] = (
                        pair_row["pallet_name"]
                        if pair_row else "掛けカンバン"
                    )

                # =====================================================
                # ✅ STATUS: READY (NOT Kanban)
                # =====================================================
                elif status == "READY":

                    cur.execute("""
                        SELECT m.pallet_name
                        FROM t_kotatsu_status k
                        JOIN t_pallet_status ps 
                            ON k.loaded_pallet_id = ps.pallet_id
                        JOIN m_pallet m 
                            ON ps.pallet_type = m.pallet_type
                        WHERE k.loaded_pallet_id = %s
                        LIMIT 1
                    """, (pallet_id,))

                    ready_row = cur.fetchone()

                    row["pallet_name"] = (
                        ready_row["pallet_name"]
                        if ready_row else real_name
                    )

                # =====================================================
                # ✅ STATUS: WORK (NORMAL)
                # =====================================================
                elif status in ("WORK"):
                    
                    line_id = pallet_row.get("line_id") if pallet_row else None
                        
                    row["pallet_name"] = (
                        pair_row["pallet_name"]
                        if pair_row else real_name
                    )
                    
                elif status == "COMP":
                    # ✅ freeze display for one cycle
                        row["pallet_name"] = real_name
                        
            cur.close()
            return [WorkerFactory.get_lift_entrance(r) for r in rows]

        finally:
            conn.close()
               
    # --- get single row by primary key ---
    def get_by_pk(self, plat_no: int, seq_no: int) -> LiftEntrance | None:
        sql = self._sql.t_lift_station_select_one_by_pk()
        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql, (plat_no, seq_no))
            row = cur.fetchone()
            cur.close()
            return WorkerFactory.get_lift_entrance(row) if row else None
        finally:
            conn.close() 
    
    def update_state(self, plat_no: int, seq_no: int, pallet_id: int, next_state: str) -> LiftEntrance:

        code_to_status = {0: "READY", 1: "WAIT", 2: "WORK", 3: "COMP"}

        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)

            # 1) Lock lift station
            cur.execute(self._sql.t_lift_station_lock_status_by_pk(), (plat_no, seq_no))
            row = cur.fetchone()
            if not row:
                raise NotFoundError(f"Platform {plat_no}, seq {seq_no} not found.")

            raw = row["transport_status"]
            current = code_to_status.get(int(raw)) if str(raw).isdigit() else str(raw).upper()

            desired = "COMP" if str(next_state).upper() == "FINISH" else str(next_state).upper()

            logger.warning(
                "STATE CHECK: current=%s desired=%s next_state=%s raw=%r",
                current, desired, next_state, raw
            )

            # State Transition Logic
            if current in ("READY", "WAIT") and desired == "WORK":
                db_next = "WORK"
            elif current == "WORK" and desired == "COMP":
                db_next = "COMP"
            else:
                raise InvalidStateError(f"Invalid transition: {current} -> {desired}")

            # 2) Get Cell Code
            cur.execute(self._sql.m_location_select_cell_by_pk(), (plat_no, seq_no))
            cell_row = cur.fetchone()
            if not cell_row:
                raise NotFoundError(f"No cell info for plat={plat_no}, seq={seq_no}")
            
            logger.info("cell_code=%r kotatsu_id=%r pallet_id=%r", 
                    cell_row["cell_code"], 
                    cell_row["kotatsu_id"],
                    cell_row["pallet_id"]
            )
            
            kotatsu_id = cell_row.get("kotatsu_id")
                        
            # mismatch check
            if str(pallet_id) != str(cell_row.get("pallet_id")):
                logger.warning(
                    f"Error in pallet id is different: Lift ST.: {pallet_id}, Kotatsu: {cell_row.get('pallet_id')}"
                )

            # =========================
            # Get REAL pallet
            # =========================
            cur.execute("""
                SELECT m.pallet_name, m.pallet_type, m.line_id
                FROM t_pallet_status t
                JOIN m_pallet m ON t.pallet_type = m.pallet_type
                WHERE t.pallet_id = %s
                LIMIT 1
            """, (pallet_id,))
            pallet_row = cur.fetchone()

            if not pallet_row:
                logger.warning(f"[UNKNOWN PALLET] pallet_id={pallet_id}")
                return WorkerFactory.get_lift_entrance(row)

            real_pallet_name = pallet_row.get("pallet_name", "")
            real_pallet_type = pallet_row.get("pallet_type")
            line_id = pallet_row.get("line_id")
            
            pair_row = None
            pallet_name = None
            
            # ✅ ✅ READY → use kotatsu loaded pallet
            if current == "READY" and db_next != "WORK":

                cur.execute("""
                    SELECT m.pallet_name, m.pallet_type
                    FROM t_kotatsu_status k
                    JOIN t_pallet_status ps 
                        ON k.loaded_pallet_id = ps.pallet_id
                    JOIN m_pallet m 
                        ON ps.pallet_type = m.pallet_type
                    WHERE k.kotatsu_id = %s
                    LIMIT 1
                """, (kotatsu_id,))

                ready_row = cur.fetchone()

                pallet_name = ready_row["pallet_name"] if ready_row else real_pallet_name
                logger.info(f"[READY FLOW] Using kotatsu pallet: {pallet_name}")


            # =========================
            # SUPPLY FLOW (WORK)
            # =========================
            else:
                cur.execute("""
                    SELECT p.line_id, p.pallet_type, m.pallet_name
                    FROM t_pallet_supply_pairs p
                    JOIN m_pallet m ON p.pallet_type = m.pallet_type
                    WHERE p.line_id = %s
                    AND p.pair_index = 0
                    LIMIT 1
                """, (line_id,))

                pair_row = cur.fetchone()
                pallet_name = pair_row["pallet_name"] if pair_row else real_pallet_name
                logger.info(f"[SUPPLY FLOW] Using pair pallet: {pallet_name}")
                
            # =========================
            # ✅ FIXED KANBAN DETECTION
            # =========================
            is_kanban = (
                pair_row and "掛けカンバン" in pair_row.get("pallet_name", "")
            )

                
            # ✅ always sync pallet_id
            cur.execute(
                self._sql.update_t_lift_station_pallet_id(),
                (pallet_id, plat_no, seq_no)
            )
            
            # ===========================================
            # WORK (START ACTION 取出開始　→　投入完了 )
            # ===========================================
            if db_next == "WORK":  
                
                if is_kanban:
                    # ✅ update lift state
                    cur.execute(self._sql.op_update_lift_station(),
                        (pallet_id, "WORK", plat_no, seq_no))
                    logger.info(f"[WORK - KANBAN (NO DB CHANGE)] {pallet_name}")
                    
                else:
                    logger.info(f"[WORK - START] pallet={pallet_id}, kotatsu={kotatsu_id}")
                    
                    # update kotatsu
                    cur.execute(self._sql.t_kotatsu_update_loaded_pallet(), (pallet_id, kotatsu_id))
                    
                    # Update t_pallet_statusのstatus only
                    cur.execute(self._sql.t_pallet_status_update(), ("EMPTY", pallet_id))
                    logger.info(f"Loaded pallet {pallet_id} onto {kotatsu_id}")
                    
                    # ✅ SAFE pallet_type
                    supply_type = pair_row["pallet_type"] if pair_row else real_pallet_type
                    
                    # ✅ IMPORTANT: DO NOT use kanban as supply
                    # if "掛けカンバン" in pair_row["pallet_name"]:
                    #     logger.warning(f"[SKIP UPDATE] pair_index is KANBAN → ignore ({pair_row['pallet_name']})")
                    #     supply_type = real_pallet_type   # ✅ fallback to safe value
                    
                    # ✅ Now update safely
                    cur.execute(
                        self._sql.update_t_pallet_status_pallet_id(),
                        (supply_type, pallet_id)
                    )

                    # Update lift status
                    cur.execute(self._sql.op_update_lift_station(), (pallet_id, "WORK", plat_no, seq_no))
                    logger.info(f"[PALLET TYPE UPDATED] pallet_id={pallet_id} → type={supply_type}")
                    
                    
            elif db_next == "COMP": # --- FINISH ACTION 投入完了 → 完了ボタンを押す時の場合---
                                    
                if is_kanban:
                    # ✅ DO NOTHING to pallet_type
                    cur.execute(self._sql.op_update_lift_station(),
                        (pallet_id, "COMP", plat_no, seq_no))

                    logger.info(f"[COMP - KANBAN (NO DB CHANGE)] {pallet_name}")

                else:
                    # ✅ only use pair_row for count (NOT for display)
                    updated = self.ps_decrease_supply_count(
                        line_id=line_id,
                        pallet_type=pair_row["pallet_type"]
                    )
                    
                    if updated:
                        logger.info(
                            f"Decreased supply count: line={line_id} pallet_type={pair_row['pallet_type']}"
                        )
                    else:
                        logger.warning(f"[SKIP DECREASE] line_id is None for pallet_id={pallet_id}")

                        
                    # Update t_pallet_status EMPTY
                    cur.execute(self._sql.t_pallet_status_update(), ("EMPTY", pallet_id))
                    cur.execute(self._sql.op_update_lift_station(), (pallet_id, "COMP", plat_no, seq_no))
                    
                    # Update t_kotatsu_status→ booking=0
                    cur.execute(self._sql.t_kotatsu_status_update(), (kotatsu_id,))       
                    
                    logger.info(f"[COMP] pallet={pallet_id}")

            conn.commit()

            # 4) Return updated row for UI refresh
            cur.execute(self._sql.t_lift_station_select_one_by_pk(), (plat_no, seq_no))
            final_row = cur.fetchone()
            
            return WorkerFactory.get_lift_entrance(final_row)
        
        except Exception as e:
            conn.rollback() 
            logger.error(f"Error in update_state: {str(e)}")
            raise
        finally:
            conn.close()
            
    ### ------------------------###
    ### 空パレット供給スケジュール
    ### ------------------------###
    def ps_line_exists(self, line_name: str) -> bool:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM m_line WHERE line_name = %s", (line_name,))
            return cur.fetchone() is not None
        finally:
            conn.close()
    
    def ps_list_all(self) -> List[PalletScheduleLine]:
        results = []
        conn = self._db.get_connection(self._db_name)

        try:
            cur = conn.cursor(dictionary=True)

            # ✅ 1. get all lines
            cur.execute(self._sql.ps_get_all_lines())
            lines = cur.fetchall()

            for row in lines:
                l_id = row["line_id"]

                # ✅ 2. get current pairs
                cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
                pairs = cur.fetchall()

                # ✅ ✅ ✅ NEW LOGIC
                if not pairs:
                    
                    # 🔥 find kanban pallet_type by line_id
                    cur.execute("""
                        SELECT pallet_type
                        FROM m_pallet
                        WHERE pallet_name LIKE '掛けカンバン(%'
                        AND line_id = %s
                        LIMIT 1
                    """, (l_id,))
                    kanban_row = cur.fetchone()

                    if kanban_row:
                        kanban_type = kanban_row["pallet_type"]

                        logger.info(f"[AUTO INSERT] 掛けカンバン for line_id={l_id}")

                        # ✅ insert default row
                        cur.execute("""
                            INSERT INTO t_pallet_supply_pairs
                                (line_id, pair_index, pallet_type, count)
                            VALUES (%s, 0, %s, 1)
                        """, (l_id, kanban_type))

                        conn.commit()

                        # ✅ reload pairs after insert
                        cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
                        pairs = cur.fetchall()

                # ✅ 3. build entity
                results.append(
                    WorkerFactory.pallet_schedule_line_from_rows(
                        line_name=row["line_name"],
                        rows=pairs,
                        line_id=l_id
                    )
                )

            return results

        finally:
            conn.close()

    def ps_list_names(self, line_name: str) -> List[Dict]:
        """Return [{pallet_type, pallet_name}] for UI dropdown."""
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(self._sql.ps_get_all_master_pallets())
            rows = cur.fetchall()
            return [{"pallet_type": r["pallet_type"], "pallet_name": r["pallet_name"]} for r in rows]
        finally:
            conn.close()
            
    def ps_apply_pattern(self, pattern_no: int):
        conn = self._db.get_connection(self._db_name)
        try:
            conn.start_transaction()
            cur = conn.cursor()

            # 1. Clear transaction table
            cur.execute("TRUNCATE TABLE t_pallet_supply_pairs")

            # 2. Insert from master
            insert_sql = """
                INSERT INTO t_pallet_supply_pairs
                    (line_id, pair_index, pallet_type, count)
                SELECT SQL_NO_CACHE
                    line_id,
                    pair_index,
                    pallet_type,
                    count
                FROM m_pallet_supply_pairs
                WHERE pattern_no = %s
                ORDER BY line_id, pair_index
            """
            cur.execute(insert_sql, (pattern_no,))
            # if pattern_apply, update transport_status to WORK
            existing = cur.fetchall()
            # if not existing:
            #     cur.execute(self._sql.update_t_lift_station_transport_status(), ("READY",))
            #     conn.commit()

            conn.commit()
            return self.ps_list_all()

        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    # ---------- パレット供給スケジュール (Pallet Schedule) ----------
    def ps_update_pair(self, line_id: int, pair_id: int, pallet_type: int, count: int) -> Optional[PalletScheduleLine]:
        """
        特定の行のパレット種別や数量を更新します。
        """
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # 1. ライン情報と現在のリビジョンを取得
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None
            l_id = line["line_id"]


            # (optional) validate pallet_type exists
            cur.execute(self._sql.ps_check_pallet_type_exists(), (pallet_type,))
            if cur.fetchone() is None:
                return None  # or raise NotFoundError

            # 2. データの更新
            cur.execute(self._sql.ps_update_pair(), (pallet_type, count, pair_id))
            conn.commit()
            return self.ps_get_line(line_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()    

    def ps_add_pair(self, line_id: int, before_index: Optional[int], pallet_type: int, count: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # Resolve line & ensure status row exists (first time)
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None
            l_id = line["line_id"]

            # (optional) validate pallet_type exists
            cur.execute(self._sql.ps_check_pallet_type_exists(), (pallet_type,))
            if cur.fetchone() is None:
                return None

            # Determine insertion index from current view
            cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
            existing = cur.fetchall()
            
            # if not existing:
            #     cur.execute(self._sql.update_t_lift_station_transport_status(), ("READY",))
            #     conn.commit()
            
            n = len(existing)
            target_idx = before_index if (before_index is not None and 0 <= int(before_index) <= n) else n

            # Shift up and insert
            cur.execute(self._sql.ps_shift_pairs_up(), (l_id, target_idx))
            cur.execute(self._sql.ps_insert_pair(), (l_id, target_idx, pallet_type, count))

            conn.commit()
            return self.ps_get_line(line_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_delete_pair(self, line_id: int, pair_id: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # 1. get line
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None

            # 2. get pair_index
            cur.execute(
                "SELECT pair_index FROM t_pallet_supply_pairs WHERE id = %s AND line_id = %s",
                (pair_id, line_id)
            )
            row = cur.fetchone()
            if not row:
                return None

            pair_index = row["pair_index"]

            # 3. delete
            cur.execute(self._sql.ps_delete_pair(), (pair_id,))
            cur.execute(self._sql.ps_shift_pairs_down(), (line_id, pair_index))

            conn.commit()
            return self.ps_get_line(line_id)

        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_move_to_group0(self, line_id: int, pair_index: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None
            
            l_id = line["line_id"]

            # Move target out
            cur.execute("UPDATE t_pallet_supply_pairs SET pair_index = -1 WHERE line_id = %s AND pair_index = %s", (l_id, pair_index))
            # Close gap
            cur.execute(self._sql.ps_shift_pairs_down(), (l_id, pair_index))
            # Open gap at 0
            cur.execute(self._sql.ps_shift_pairs_up(), (l_id, 0))
            # Place at 0
            cur.execute("UPDATE t_pallet_supply_pairs SET pair_index = 0 WHERE line_id = %s AND pair_index = -1", (l_id,))

            conn.commit()
            return self.ps_get_line(line_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_get_line(self, line_id: int) -> Optional[PalletScheduleLine]:
        """Helper to refresh a single line row in UI"""
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # get line header
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            row = cur.fetchone()
            if not row:
                return None

            # get pairs
            cur.execute(self._sql.ps_get_pairs_by_line(), (row["line_id"],))
            pairs = cur.fetchall()

            return WorkerFactory.pallet_schedule_line_from_rows(
                line_name=row["line_name"],   # ✅ comes from DB
                rows=pairs,
                line_id=row["line_id"],       # ✅ passed once
            )
        finally:
            conn.close()
    
    def get_all_master_pallets(self) -> List[Dict]:
        """Service calls this exactly"""
        # Use self._queries (not self._sql if you renamed it)
        sql = self._sql.ps_get_all_master_pallets() 
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            return cur.fetchall()
        except Exception as e:
            print(f"Database Error: {e}") # This will show in your terminal
            raise e
        finally:
            conn.close()
            
    def ps_decrease_supply_count(self, line_id: int, pallet_type: int) -> bool:
        """
        Decrease pallet supply count by 1 (if count > 0).
        Returns True if decremented, False if nothing changed.
        """
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            
            logger.warning(
                f"[DEBUG] ENTER ps_decrease_supply_count → line_id={line_id}, pallet_type={pallet_type}"
            )

            cur.execute(
                self._sql.ps_decrease_pair_count_if_positive(),
                (line_id, pallet_type)
            )

            logger.warning(f"[DEBUG] SQL EXECUTED → rowcount={cur.rowcount}")
            
            updated = cur.rowcount > 0
            if updated:
                conn.commit()
            else:
                conn.rollback()  # optional, but clean

            return updated

        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
