# app/infrastructure/runners/run_controll.py

import threading
from app.infrastructure.repositories.iotds_repository import IOTDSRepository
from app.infrastructure.repositories.operation_repository import OperationRepository
from app.infrastructure.setup_log import setup_log
import app.config.config as cfg
from app.services.iotds_service import IoTDSService
from app.services.operation_ni_service import OperationNiService
from app.services.operation_service import OperationService

logger = setup_log(
    cfg.LOG_FOLDER,
    cfg.RUN_CONTROLL_LOG_FILE,
    cfg.BACKUP_DAYS,
    logger_name="run_controll"
)

class ThreadManager:
    def __init__(self):
        self.threads = {}
        self.lock = threading.Lock()

    def start(self, line_id, target):
        with self.lock:
            t = self.threads.get(line_id)

            if t and t.is_alive():
                logger.debug(f"🟨 Thread for line {line_id} already running — skip start.")
                return False

            logger.info(f"🟩 Starting new worker thread for line {line_id} ...")

            # スレッドを起動して非同期に処理を実行
            th = threading.Thread(target=target, daemon=True)
            self.threads[line_id] = th
            th.start()
            return True


class RunControll:
    """
    自動搬送モードの監視＋ライン作業スレッド起動  
    OperationService(line_id, repo, op_rms) を起動する
    """

    def __init__(self, w, i):
        # w: WCSSQLQuery, i: IOTDSSQLQuery
        self._repo = OperationRepository(w, i)
        self.wcs_sql = w
        # self._service = OperationNiService()
        self._manager = ThreadManager()
        self._iotrepo = IOTDSRepository(w, i) 
        
    def run_cycle(self):

        logger.debug("✅ RunControll: run_cycle() called")
        iot = IoTDSService(self._iotrepo)
        
        mode = True  # 各個モードの状態を追跡するフラグ
        status_auto = {}  # システム状態を追跡する変数

        while True:
            iot.detect_and_update()

            system = self._repo.get_system_status()
            if not system:
                logger.error("❌ No system status returned")
                return

            status = system[0]
            auto_mode = status["mode"] == 1
            prepared  = status["preparation_ok"] == 1
            running   = status["auto_running"] == 1
            
            # 各個モード
            if not (auto_mode and prepared and running):
                if mode is True:
                    logger.info(
                        "⏹ 各個モード → skip OperationService "
                        "(mode=%s, prep=%s, running=%s)",
                        status["mode"],
                        status["preparation_ok"],
                        status["auto_running"],
                    )
                    mode = False
                continue
            else:
                mode = True

            # ラインの起動状態を確認しているが2間口対応となる為、条件多すぎる
            lines = self._repo.get_line_status()
            if not lines:
                logger.error("❌ No line status returned")

            for row in lines:
                line_id = int(row["line_id"])
                permission = row["transport_permission"]
                carry_pattern = row.get("carry_pattern")

                updata = False
                if line_id not in status_auto:
                    status_auto[line_id] = permission
                    updata = True

                if status_auto[line_id] != permission:
                    updata = True
                    status_auto[line_id] = permission

                if permission != 1:
                    continue

                if carry_pattern is None:
                    logger.error(
                        "❌ Line %s has NULL carry_pattern — skip",
                        line_id,
                    )
                    continue

                if isinstance(carry_pattern, int):
                    if updata:
                        logger.info(f"🟦 Line {line_id} allowed (carry_pattern={carry_pattern})")
                else:
                    logger.error(f"carry pattern miss setteing, line_id:{line_id}")
                    continue

                # サービスのインスタンス化
                if isinstance(carry_pattern, int) and carry_pattern == 1:
                    service = OperationService(self.wcs_sql, self._iotrepo)
                elif isinstance(carry_pattern, int) and carry_pattern == 2:
                    service = OperationNiService(self.wcs_sql, self._iotrepo)
                
                start_flg, operation_data = service.check_start_conditions(line_id)
                """ operation_data = {"plat_no", "seq_no", "pallet_id", "request_time"}"""
                if start_flg:
                    self._repo.update_request_execution(operation_data)
                    logger.debug(f"🔍 Line {line_id} service started")
                    started = self._manager.start(line_id, lambda: service.start_operation(line_id, operation_data["plat_no"], operation_data["seq_no"]))
