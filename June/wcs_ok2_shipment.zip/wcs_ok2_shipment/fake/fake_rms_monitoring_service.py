# app/services/fake_rms_monitoring_service.py
from __future__ import annotations
from typing import Dict, Any, List

class FakeRMSMonitoringService:
    """
    Pure fake map provider for testing UI without RMS or DB.
    Produces static but realistic cells / shelves / AMRs.
    """

    def get_display_data(self) -> Dict[str, Any]:
        # Mock map size
        size = {"x": 1200, "y": 800}

        # Mock cells
        cells = [
            {"cellCode": "A01", "location_x": 100, "location_y": 100, "width": 60, "height": 60, "color": "#c7faff"},
            {"cellCode": "A02", "location_x": 200, "location_y": 100, "width": 60, "height": 60, "color": "#61d6ce"},
            {"cellCode": "A03", "location_x": 300, "location_y": 100, "width": 60, "height": 60, "color": "#f7c820"},
            {"cellCode": "B01", "location_x": 100, "location_y": 200, "width": 60, "height": 60, "color": "gray"},
        ]

        # Mock shelves (kotatsus)
        kotatsus = [
            {
                "id": "SHELF-100",
                "location_x": 400,
                "location_y": 300,
                "width": 80,
                "height": 60,
                "angle": 0,
                "shelfCode": "SHELF-100",
                "color": "blue"
            },
            {
                "id": "SHELF-200",
                "location_x": 600,
                "location_y": 300,
                "width": 80,
                "height": 60,
                "angle": 90,
                "shelfCode": "SHELF-200",
                "color": "green"
            }
        ]

        # Mock AMRs
        amrs = [
            {
                "id": "AMR-01",
                "robotId": "AMR-01",
                "status": "NORMAL",
                "location_x": 350,
                "location_y": 500,
                "path": "350,500 380,500 410,520"
            },
            {
                "id": "AMR-02",
                "robotId": "AMR-02",
                "status": "BUSY",
                "location_x": 700,
                "location_y": 450,
                "path": "700,450 720,460 740,455 760,455"
            }
        ]

        return {
            "siza": size,      # keep 'siza' because controller normalizes it
            "cells": cells,
            "kotatsus": kotatsus,
            "amrs": amrs,
        }