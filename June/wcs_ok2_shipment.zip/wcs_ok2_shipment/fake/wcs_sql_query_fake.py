# app/interfaces/fake/wcs_sql_query_fake.py
from __future__ import annotations
from typing import List, Dict

class FakeWCSSQLQuery:
    """
    Minimal fake for WCSSQLQuery so RMSMonitoringService can run without DB.
    Replace sample data with what helps your demo.
    """

    def m_robot(self) -> List[Dict]:
        # Robot master: {id, name}
        return [
            {"id": "AMR-01", "name": "Turtle-01"},
            {"id": "AMR-02", "name": "Turtle-02"},
            {"id": "AMR-03", "name": "Turtle-03"},
        ]

    def t_kotatsu_status(self) -> List[Dict]:
        # Kotatsu status: {id (shelfCode), type, palletCode?, occupiedRobotId?}
        return [
            {"id": "SHELF-100", "type": "330D", "palletCode": "PAL-100", "occupiedRobotId": None},
            {"id": "SHELF-200", "type": "155D", "palletCode": "PAL-200", "occupiedRobotId": "AMR-02"},
            {"id": "SHELF-300", "type": "557",  "palletCode": None,  "occupiedRobotId": None},
        ]