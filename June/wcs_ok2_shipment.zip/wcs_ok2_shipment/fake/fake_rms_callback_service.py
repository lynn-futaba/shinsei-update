# app/services/fake_rms_callback_service.py
from __future__ import annotations
from typing import Dict, Any, List
import time
import logging

class FakeRMSCallbackService:
    """
    Fake service for RMS callback integration tests (no DB, no RMSCallbackApi needed).

    - Validates minimal payload shape:
        * msgType == "RobotTaskCallbackMsg"
        * request.header.requestId exists
        * request.body.taskId, request.body.taskStatus exist
    - Simulates persistence:
        * Appends full 'body' JSON into in-memory event list (idempotent by taskId+requestId)
        * Upserts current status snapshot in memory by taskId
    - Builds ACK JSON inline (echoes msgType and responseId=requestId)
    - Exposes getters to inspect what would have been saved
    """

    ALLOWED_STATUSES = {"NEW", "ASSIGNED", "EXECUTING", "COMPLETED", "CANCELED"}

    # Optional: soft-allow sets (log only)
    ALLOWED_TASK_TYPES = {
        "GO_SOMEWHERE_TO_STAY","DELIVER_SHELF_TO_STATION","DELIVER_SHELF","DELIVER_NEW_SHELF",
        "GO_WORK","CARRY_PACKAGE","DELIVER_PALLET","DELIVER_BOX","GO_WORK_ORDER_TO_PERSON",
        "MOVE_SHELF","GO_MAINTAIN_TO_STAY","GO_CHARGE_YOURSELF","GO_CIRCLE","GO_TO_INSPECTION"
    }
    ALLOWED_INSTRUCTIONS = {
        "NONE","GO_FETCH","GO_TURN","GO_RETURN","CANCEL","CANCEL_INSTRUCTION","GO_NEXT","PRIORITY_SET",
        "CLEAR_WAITPOINT","GO_RECEIVE","GO_DROP","ALLOW_ENTER_ELEVATOR","ALLOW_LEAVE_ELEVATOR",
        "UPDATE_PARCEL","UPDATE_BOX","FINISHED"
    }
    ALLOWED_PHASES = {
        "GO_FETCHING","SHELF_FETCHED","GO_DELIVERING","QUEUING","SHELF_ARRIVED","GO_RETURN","SHELF_TURNING",
        "MOVING","CHARGING","ARRIVED_RECEIVE","ARRIVED_DROP","ARRIVED_WAIT_POINT","LEAVING_WAIT_POINT",
        "RECEIVE_FINISH","DROP_FINISH","BOX_FETCHED","BOX_ARRIVED","ARRIVED_ELEVATOR_ENTRY","ENTERED_ELEVATOR",
        "LEAVED_ELEVATOR","ARRIVED","FETCHED"
    }

    def __init__(self, client_id: str = "geekCode_geekWarehouseCode_001",
                 ack_version: str = "3.3.0",
                 ack_code: str = "ca5ebc4251374e35a5f6afb2a52fd6dd"):
        # In-memory stores
        self._events: List[Dict[str, Any]] = []     # append-only history
        self._status: Dict[str, Dict[str, Any]] = {}  # snapshot by taskId

        # For ACK building
        self._client_id = client_id
        self._ack_version = ack_version
        self._ack_code = ack_code

    # ---------------- Controller entry point ----------------
    def process_callback_and_build_ack(self, msg: Dict[str, Any]) -> Dict:
        """
        API used by controller:
          1) Validate & simulate persistence
          2) Build ACK JSON to return to RMS
        """
        self._handle_callback(msg)
        return self._build_ack_from_request(msg)

    # ---------------- Core handler (fake persistence) ----------------
    def _handle_callback(self, msg: Dict[str, Any]) -> None:
        # 1) Structure validation
        if str(msg.get("msgType")) != "RobotTaskCallbackMsg":
            raise ValueError(f"Unsupported msgType: {msg.get('msgType')}")

        req = msg.get("request") or {}
        header = req.get("header") or {}
        body = req.get("body") or {}

        request_id  = str(header.get("requestId") or "")
        task_id     = str(body.get("taskId") or "")
        robot_id    = str(body.get("robotId") or "")
        task_status = str(body.get("taskStatus") or "").upper()
        task_phase  = str(body.get("taskPhase") or "")
        dest_cell   = str(body.get("destCellCode") or "")
        task_type   = str(body.get("taskType") or "")
        instruction = str(body.get("instruction") or "")
        ts          = int(time.time())

        if not request_id:
            raise ValueError("Missing request.header.requestId in callback")
        if not task_id or not task_status:
            raise ValueError("Missing taskId or taskStatus in callback")

        # 2) Soft validations: log unknowns; do not block
        if self.ALLOWED_STATUSES and task_status not in self.ALLOWED_STATUSES:
            logging.warning("[fake-callback] Unknown taskStatus: %s", task_status)
        if task_type and task_type not in self.ALLOWED_TASK_TYPES:
            logging.warning("[fake-callback] Unknown taskType: %s", task_type)
        if instruction and instruction not in self.ALLOWED_INSTRUCTIONS:
            logging.warning("[fake-callback] Unknown instruction: %s", instruction)
        if task_phase and task_phase not in self.ALLOWED_PHASES:
            logging.warning("[fake-callback] Unknown taskPhase: %s", task_phase)

        # 3) Event log (idempotent by taskId+requestId)
        if not any(e for e in self._events if e["task_id"] == task_id and e["request_id"] == request_id):
            self._events.append({
                "task_id": task_id,
                "request_id": request_id,
                "event_json": body,   # FULL body for future-proofing
                "ts": ts
            })

        # 4) Current status upsert
        self._status[task_id] = {
            "task_id": task_id,
            "status": task_status,
            "phase": task_phase,
            "robot_id": robot_id,
            "dest_cell": dest_cell,
            "task_type": task_type,
            "instruction": instruction,
            "updated_date": ts
        }

        logging.info(
            "[fake-callback] task=%s robot=%s status=%s phase=%s dest=%s type=%s instr=%s",
            task_id, robot_id, task_status, task_phase, dest_cell, task_type, instruction
        )

    # ---------------- ACK builder (inline; no external dependency) ----------------
    def _build_ack_from_request(self, request_json: Dict[str, Any]) -> Dict:
        try:
            msg_type = str(request_json["msgType"])
            response_id = str(request_json["request"]["header"]["requestId"])
        except Exception:
            raise ValueError("Invalid RMS callback: missing msgType or request.header.requestId")

        return {
            "id": self._client_id,
            "msgType": msg_type,
            "response": {
                "header": {
                    "responseId": response_id,       # echo requestId
                    "code": self._ack_code,          # vendor-specific header value (if required)
                    "msg": self._ack_version,        # version / notes
                },
                "body": {}
            }
        }

    # ---------------- Introspection helpers (for tests / debugging) ----------------
    def get_events(self) -> List[Dict[str, Any]]:
        """Return the in-memory event list (append-only)."""
        return list(self._events)

    def get_status_snapshot(self) -> Dict[str, Dict[str, Any]]:
        """Return the in-memory status snapshot (by task_id)."""
        return dict(self._status)

    def clear(self) -> None:
        """Clear in-memory stores (between tests)."""
        self._events.clear()
        self._status.clear()