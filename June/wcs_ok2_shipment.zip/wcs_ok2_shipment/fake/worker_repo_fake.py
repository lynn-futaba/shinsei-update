"""
作業者用フェッキリポジトリ (FakeWorkerRepository)
作成者: Lynn
----------------------------------
リフト間口および空パレット登録機能の挙動をメモリ上でシミュレーションするクラス。

主な役割:
1. 排他制御のシミュレーション (Rev/StaleWriteError):
   - `rev`（リビジョン番号）の不一致をチェックすることで、複数ユーザーによる同時編集
     （楽観的ロック）の競合を本番環境と同様に再現します。
2. スレッドセーフなデータ操作:
   - `threading.Lock` を使用し、並行して発生するAPIリクエストがメモリ内のデータを
     破壊しないよう保護しています。
3. 動的なパレット供給列の管理:
   - パレットの追加、更新、削除、および「搬送グループへの移動（move_to_group0）」
     といった複雑なリスト操作を擬似的に実行します。
4. ドメイン駆動設計の継承:
   - `NotFoundError` や `StaleWriteError` など、ドメイン層で定義された例外を
     適切に送出することで、サービス層のロジックを修正なしでテスト可能です。

フロントエンドのUIテストにおいて、実際にデータを保存・編集した際の挙動を確認するための
「モック・データベース」として機能します。
"""
# app/infrastructure/repositories/fake/worker_repo_fake.py
from __future__ import annotations
from typing import Dict, Iterable, Optional, List
import threading

from app.domain.entities import LiftEntrance, PalletScheduleLine, PalletPair
from app.domain.value_objects import demo_lift_entrance, demo_pallet_supply, demo_pallet_master_names

from app.domain.exception import NotFoundError, StaleWriteError


class FakeWorkerRepository:
    """
    開発/オフライン用のフェイク実装（Domain準拠）
    """

    def __init__(self, *, max_pairs: int = 10):
        self._lock = threading.Lock()

        # Lift Entrance (unchanged in this excerpt)
        self._le_store: Dict[str, Dict] = {}
        for e in demo_lift_entrance():
            self._le_store[e.seq_no] = {"entity": e, "rev": 1}

        # Pallet Supply
        self._ps_max_pairs = int(max_pairs)
        # line_name -> PalletScheduleLine
        self._ps_store: Dict[str, PalletScheduleLine] = {}
        for line_name, pairs in demo_pallet_supply().items():
            self._ps_store[line_name] = PalletScheduleLine(
                line_name=line_name,
                rev=1,
                pairs=[PalletPair(pallet_name=str(p["pallet_name"]), count=int(p["count"])) for p in pairs]
            )

    # ===== Lift Entrance (stubs to fit your earlier code path) =====
    def list_lift_entrance(self) -> Iterable[LiftEntrance]:
        return [v["entity"] for v in self._le_store.values()]

    def get_by_seq_no(self, seq_no: str) -> Optional[LiftEntrance]:
        rec = self._le_store.get(seq_no)
        return rec["entity"] if rec else None

    def update_state(self, seq_no: str, next_state: str, expected_rev: int) -> LiftEntrance:
        with self._lock:
            rec = self._le_store.get(seq_no)
            if not rec:
                raise NotFoundError(seq_no)
            cur_rev = int(rec["rev"])
            if int(expected_rev) != cur_rev:
                raise StaleWriteError(f"rev mismatch: expected {expected_rev}, current {cur_rev}")

            ent: LiftEntrance = rec["entity"]
            ent = type(ent)(
                plat_no=ent.plat_no,
                seq_no=ent.seq_no,
                kotatsu_id=ent.kotatsu_id,
                transport_status=str(next_state).upper(),
            )
            rec["entity"] = ent
            rec["rev"] = cur_rev + 1
            return ent

    def get_rev(self, seq_no: str) -> int:
        rec = self._le_store.get(seq_no)
        return int(rec["rev"]) if rec else 0

    # ===== Pallet Supply (domain contracts) =====
    def ps_max_pairs(self) -> int:
        return int(self._ps_max_pairs)

    def ps_list_all(self) -> List[PalletScheduleLine]:
        with self._lock:
            lines = list(self._ps_store.values())
            return sorted(lines, key=lambda x: x.line_name)

    def ps_get_line(self, line_name: str) -> Optional[PalletScheduleLine]:
        with self._lock:
            return self._ps_store.get(line_name)

    def ps_line_exists(self, line_name: str) -> bool:
        return line_name in self._ps_store

    def ps_list_names(self, line_name: str) -> List[str]:
        with self._lock:
            line = self._ps_store.get(line_name)
            if not line:
                return []
            seen = set()
            names: List[str] = []
            for p in line.pairs:
                if p.pallet_name not in seen:
                    seen.add(p.pallet_name)
                    names.append(p.pallet_name)
            # merge demo master names (optional)
            for n in demo_pallet_master_names():
                if n not in seen:
                    names.append(n)
            return names

    def _get_line_and_check_rev(self, line_name: str, expected_rev: int) -> PalletScheduleLine:
        line = self._ps_store.get(line_name)
        if not line:
            raise NotFoundError(line_name)
        if int(expected_rev) != int(line.rev):
            raise StaleWriteError(f"rev mismatch: expected {expected_rev}, current {line.rev}")
        return line

    def ps_add_pair(
        self,
        *,
        line_name: str,
        pallet_name: str,
        count: int,
        before_index: Optional[int],
        expected_rev: int
    ) -> PalletScheduleLine:
        with self._lock:
            line = self._get_line_and_check_rev(line_name, expected_rev)
            line.add_pair(PalletPair(pallet_name=pallet_name, count=int(count)), before_index)
            line.rev += 1
            return line

    def ps_update_pair(
        self,
        *,
        line_name: str,
        pair_index: int,
        pallet_name: str,
        count: int,
        expected_rev: int
    ) -> PalletScheduleLine:
        with self._lock:
            line = self._get_line_and_check_rev(line_name, expected_rev)
            line.update_pair(pair_index, PalletPair(pallet_name=pallet_name, count=int(count)))
            line.rev += 1
            return line

    def ps_delete_pair(
        self,
        *,
        line_name: str,
        pair_index: int,
        expected_rev: int
    ) -> PalletScheduleLine:
        with self._lock:
            line = self._get_line_and_check_rev(line_name, expected_rev)
            line.delete_pair(pair_index)
            line.rev += 1
            return line

    def ps_move_to_group0(
        self,
        *,
        line_name: str,
        pair_index: int,
        expected_rev: int
    ) -> PalletScheduleLine:
        with self._lock:
            line = self._get_line_and_check_rev(line_name, expected_rev)
            line.move_to_group0(pair_index)
            line.rev += 1
            return line