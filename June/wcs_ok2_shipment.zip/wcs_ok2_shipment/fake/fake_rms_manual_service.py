# app/services/fake_rms_manual_service.py
from __future__ import annotations
from typing import Dict, Any, Optional, List
import logging

class FakeRMSManualService:
    """
    Fake RMS manual command service for offline/UI testing.
    Mirrors RMSManualService public API (Flask-agnostic).
    """

    def __init__(
        self,
        *,
        initial_robots: Optional[List[Dict[str, Any]]] = None,
        initial_shelves: Optional[List[Dict[str, Any]]] = None,
    ):
        # Robots example: { "robotId": "AMR-01", "status": "IDLE", "taskId": None, "last_cell_code": None }
        self._robots: Dict[str, Dict[str, Any]] = {}
        self._shelves: Dict[str, Dict[str, Any]] = {}

        for r in (initial_robots or [
            {"robotId": "AMR-01", "status": "IDLE", "taskId": None, "last_cell_code": None},
            {"robotId": "AMR-02", "status": "IDLE", "taskId": None, "last_cell_code": None},
        ]):
            self._robots[str(r["robotId"])] = {**r, "robotId": str(r["robotId"])}

        # Shelves example: { "shelfCode": "SHELF-100", "angle": 0, "location_cell": "A01" }
        for s in (initial_shelves or [
            {"shelfCode": "SHELF-100", "angle": 0, "location_cell": "A01"},
            {"shelfCode": "SHELF-200", "angle": 90, "location_cell": "B01"},
        ]):
            self._shelves[str(s["shelfCode"])] = {**s, "shelfCode": str(s["shelfCode"])}

    # ---------- Public API (mirrors RMSManualService) ----------

    def move(self, robot_id: str, cell_code: str) -> None:
        robot = self._ensure_robot(robot_id)
        robot["last_cell_code"] = cell_code
        robot["status"] = "NORMAL"   # simulate moving -> normal
        if robot.get("taskId") is None:
            robot["taskId"] = 1000  # fake task
        logging.info(f"[FAKE RMS] move: robot_id={robot_id} -> cell_code={cell_code}")

    def cancel(self, robot_id: str, cell_code: str) -> None:
        robot = self._ensure_robot(robot_id)
        # Only cancel if task matches context (we don't track per-cell tasks; keep simple)
        robot["taskId"] = None
        robot["status"] = "IDLE"
        logging.info(f"[FAKE RMS] cancel: robot_id={robot_id}")

    def load(self, robot_id: str, shelf_code: str, cell_code: str, angle: int = 0) -> None:
        robot = self._ensure_robot(robot_id)
        shelf = self._ensure_shelf(shelf_code)
        # simulate returning the shelf to a cell
        shelf["location_cell"] = cell_code
        shelf["angle"] = int(angle)
        robot["status"] = "BUSY"
        robot["taskId"] = robot.get("taskId") or 1001
        logging.info(f"[FAKE RMS] load: robot_id={robot_id}, shelf_code={shelf_code} -> cell_code={cell_code}")

    def fetch(self, robot_id: str, shelf_code: str, cell_code: str, angle: int = 0) -> None:
        robot = self._ensure_robot(robot_id)
        shelf = self._ensure_shelf(shelf_code)
        # simulate fetching and moving with shelf
        shelf["location_cell"] = cell_code
        shelf["angle"] = int(angle)
        robot["status"] = "BUSY"
        robot["taskId"] = robot.get("taskId") or 1002
        logging.info(f"[FAKE RMS] fetch: robot_id={robot_id}, shelf_code={shelf_code} -> cell_code={cell_code}")

    def remove_shelf(self, shelf_code: str) -> None:
        # simulate deleting shelf master
        key = str(shelf_code)
        if key not in self._shelves:
            raise RuntimeError(f"棚が存在しません: shelf_id={shelf_code}")
        del self._shelves[key]
        logging.info(f"[FAKE RMS] remove_shelf: shelf_code={shelf_code}")

    # ---------- Helpers ----------

    def _ensure_robot(self, robot_id: str) -> Dict[str, Any]:
        key = str(robot_id)
        robot = self._robots.get(key)
        if not robot:
            raise RuntimeError(f"操作エラー:ロボットがいません (robot_id={robot_id})")
        return robot

    def _ensure_shelf(self, shelf_code: str) -> Dict[str, Any]:
        key = str(shelf_code)
        shelf = self._shelves.get(key)
        if not shelf:
            raise RuntimeError(f"棚が存在しません: shelf_id={shelf_code}")
        return shelf