"""
管理用フェッキリポジトリ (FakeManageRepository)
作成者: Lynn
----------------------------------
データベース(MySQL)に接続せずに、メモリ上でデータを管理するテスト用リポジトリ。

主な役割:
1. オフライン開発のサポート:
   - 工場ネットワーク外やDB未設置環境でも、ダミーデータ（Value Objects）を使用して
     フロントエンドやAPIの動作確認を可能にします。
2. ステートフルなシミュレーション:
   - メモリ内変数（`self._store`, `self._rms`）により、画面でボタンを押した際の
     「状態の変化（モード切替やフラグ反転）」を擬似的に再現します。
3. 安全なプロトタイピング:
   - 実機のロボットを動かしたり、本番DBを書き換えたりするリスクなしに、
     新しい機能や複雑なロジックのテストを繰り返すことができます。
4. 設定ファイルとの連動:
   - `config.USE_FAKE = True` の場合に `ManageService` によって呼び出されます。

開発スピードを加速させ、本番デプロイ前の「安全な実験場」を提供するコンポーネントです。
"""
# app/infrastructure/repositories/fake/manage_repo_fake.py
from typing import Dict, Iterable, Optional, List
from app.domain.entities import Maguchi, ErrorListItem, TransportTask, RMSCurrentMode
from app.domain.value_objects import (
    demo_line_state_maguchis, 
    demo_error_list_items, 
    demo_task_status, 
    demo_lift_entrance,
    demo_rms_current_mode
)

class FakeManageRepository:
    """
    In-memory fake repository for offline/dev mode.
    Data source: domain.value_objects.demo_line_state_maguchis()
    """
    def __init__(self):
        self._store: Dict[str, Maguchi] = {
            e.line_id: e for e in demo_line_state_maguchis()
        }
        
    
        rms_seed: List[RMSCurrentMode] = demo_rms_current_mode()
        # keep one system row for now
        self._rms: List[RMSCurrentMode] = [rms_seed[0]] if rms_seed else [
            RMSCurrentMode(system_id="RMS-01", system_name="Main RMS", mode=False, preparation_ok=False, auto_running=False)
        ]



    def list(
        self,
        *,
        pallet_name: Optional[str] = None,
        line_id: Optional[str] = None,
        request_flag: Optional[bool] = None,
        line_name: Optional[str] = None,
    ) -> Iterable[Maguchi]:
        items = list(self._store.values())
        if pallet_name is not None:
            items = [e for e in items if e.pallet_name == pallet_name]
        if line_id is not None:
            items = [e for e in items if e.line_id == line_id]
        if request_flag is not None:
            items = [e for e in items if e.request_flag == request_flag]
        if line_name is not None:
            items = [e for e in items if e.line_name == line_name]
        return sorted(items, key=lambda e: e.line_id)

    def get_line_state_list(self) -> Iterable[Maguchi]:
        return sorted(self._store.values(), key=lambda e: e.line_id)
    
    def get_error_list(self) -> Iterable[ErrorListItem]:
            """
            Return joined error rows (log + master) for the エラー表示 table.
            """
            return demo_error_list_items()
    
    
   # ★ 追加: 搬送タスク（DB未接続でもAPI確認可能）
    def get_task_status(self) -> Iterable[TransportTask]:
        return demo_task_status()
    
    # ★ 追加: リフト間口画面（DB未接続でもAPI確認可能）
    def get_lift_entrance(self) -> Iterable[TransportTask]:
        return demo_lift_entrance()
    
    
    # ============================
    # ★ Add this to test the flow
    # ============================
    def toggle_request_flag(self, line_id: str) -> bool:
        """
        Flip in-memory Maguchi.request_flag for the given line_id.
        Return the updated boolean.
        Raise KeyError if not found (controller will turn it into 404).
        """
        if line_id not in self._store:
            raise KeyError(f"line_id not found: {line_id}")
        entity = self._store[line_id]
        entity.request_flag = not entity.request_flag
        # Optionally: also mirror line_name == line_id if you rely on it
        # entity.line_name = entity.line_name or line_id
        return entity.request_flag
    
    
    
    # --- RMS MODE ---
    def get_rms_current_mode(self) -> Iterable[RMSCurrentMode]:
        return list(self._rms)  # shallow copy

    def rms_set_mode(self, mode: int) -> bool:
        # 1 = 自動, 0 = 各個
        if not self._rms:
            raise KeyError("RMS row is empty")
        new_mode = (int(mode) == 1)
        self._rms[0].mode = new_mode
        # optional: reset running flags when switching mode
        # self._rms[0].preparation_ok = False
        # self._rms[0].auto_running = False
        return new_mode
    
    
    def _rms0(self) -> RMSCurrentMode:
        if not self._rms:
            raise KeyError("RMS row is empty")
        return self._rms[0]

    def rms_auto_prepare(self) -> RMSCurrentMode:
        m = self._rms0()
        m.mode = True            # 自動
        m.preparation_ok = True  # 起動準備 完了
        m.auto_running = False   # 運転中: 停止
        return m

    def rms_auto_start(self) -> RMSCurrentMode:
        m = self._rms0()
        m.mode = True
        m.preparation_ok = True
        m.auto_running = False   # まだ運転中ではない（起動段階）
        return m

    def rms_auto_run(self) -> RMSCurrentMode:
        m = self._rms0()
        m.mode = True
        m.preparation_ok = True
        m.auto_running = True    # 運転中
        return m





