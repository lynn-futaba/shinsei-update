/**
 * RMS Map Monitoring Frontend (clean version)
 * ✅ No manual alignment
 * ✅ Fully RMS-driven
 * ✅ Stable even if RMS map changes
 */

const SIZE = {
  amrRadius: 12,
  cellFont: 6
};

/* ================= Inline CSS ================= */
$("<style>", { type: "text/css" })
  .html(`
    .amr-clickable { cursor: pointer; }
    .shelf-clickable { cursor: pointer; }
    .cell-clickable { cursor: crosshair; }
  `)
  .appendTo("head");

$(document).ready(function () {

  /* ================= PAN / ZOOM ================= */
  let scale = 1;
  let pointX = 0;
  let pointY = 0;
  let isDragging = false;
  let start = { x: 0, y: 0 };

  const prevBackendPos = {};

  const ORANGE_CELLS = new Set([
    "26054328", 
    "28154328", 
    "26053824", 
    "28153824", 
    "22853769", 
    "21533538", 
    "21533338", 
    "21533138", 
    "22852700", 
    "25002700", 
    "27002700", 
    "21532430", 
    "21532230", 
    "21532030",  
    "22851000", // temp T66 6/11 HVT TRY
    "25001000", // input T66
    "27001000", // wait T66
    // 仮想環境マップ情報
    "22603765",
    "21233530", // complete T63, T64
    "21233300", // complete T63, T64
    "21233130", // complete T63, T64
    "22602700", // temp T65
    "21232430", // 80,0 complete T65, T66
    "21232230", // 80,1 complete T65, T66
    "21232030", // 80,2 complete T65, T66
    "22601000", // temp T66
  ]);

  const $map = $("#map");
  const $container = $("#map-container");

  function setTransform() {
    $map.css({
      transform: `translate(${pointX}px, ${pointY}px) scale(${scale})`,
      "transform-origin": "0 0"
    });
  }

  /* ---------- PAN ---------- */
  $container.on("mousedown", function (e) {
    if ($(e.target).is("button")) return;
    start.x = e.clientX - pointX;
    start.y = e.clientY - pointY;
    isDragging = true;
  });

  $(window)
    .on("mousemove", function (e) {
      if (!isDragging) return;
      pointX = e.clientX - start.x;
      pointY = e.clientY - start.y;
      setTransform();
    })
    .on("mouseup", function () {
      isDragging = false;
    });

  /* ---------- ZOOM ---------- */
  $container.on("wheel", function (e) {
    e.preventDefault();
    const factor = e.originalEvent.deltaY > 0 ? 0.9 : 1.1;
    scale = Math.min(Math.max(scale * factor, 0.05), 15);
    setTransform();
  });

  $("#zoom-in").click(() => { scale = Math.min(scale * 1.2, 15); setTransform(); });
  $("#zoom-out").click(() => { scale = Math.max(scale / 1.2, 0.05); setTransform(); });
  $("#zoom-reset").click(() => {
    scale = 1;
    pointX = 0;
    pointY = 0;
    setTransform();
  });

  /* ================= MAIN RENDER ================= */
  function renderMap() {

    $.get("/manage/api/v1/rms_map_monitor", function (res) {

      if (!res || !res.data) return;

      const cells = res.data.cells || [];
      const amrs = res.data.amrs || [];
      const kotatsus = res.data.kotatsus || [];
      const size = res.data.size || [2000, 2000];

      const width = size[0];
      const height = size[1];
      const svgNS = "http://www.w3.org/2000/svg";

      /* ---------- SVG ---------- */
      const svg = document.createElementNS(svgNS, "svg");
      svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
      svg.setAttribute("width", width);
      svg.setAttribute("height", height);
      svg.style.background = "#ffffff";

      // ✅ invert Y axis
      const root = document.createElementNS(svgNS, "g");
      root.setAttribute("transform", `translate(0, ${height}) scale(1,-1)`);
      svg.appendChild(root);

      /* ================= CELLS ================= */
      const GAP = 6;

      cells.forEach(c => {

        const g = document.createElementNS(svgNS, "g");
        g.classList.add("cell-clickable");

        // ✅ IMPORTANT FIX → swap
        const drawW = c.height;
        const drawH = c.width;

        
        const minSize = 10;

        const finalW = Math.max(drawW - GAP, minSize);
        const finalH = Math.max(drawH - GAP, minSize);

        // ✅ FIX: recalc center-based position using FINAL size
        const x = c.location_x - finalW / 2;
        const y = c.location_y - finalH / 2;


        const rect = document.createElementNS(svgNS, "rect");

        rect.setAttribute("x", x);
        rect.setAttribute("y", y);

        rect.setAttribute("width", finalW);
        rect.setAttribute("height", finalH);

        // console.log("CELL COLOR:", c.cellCode, c.color);

        let fillColor = c.color || "#e0f7fa";
        
        // ✅ replace gray only with 水色
        if (fillColor.toLowerCase() === "#cccccc") {
          fillColor = "#e0f7fa";
        }

        if (ORANGE_CELLS.has(c.cellCode)) {
          fillColor = "#ffcc00"; 
        } 

        rect.setAttribute("fill", fillColor);
        rect.setAttribute("opacity", "1"); // ✅ force full visibility

        rect.setAttribute("stroke", "#555");
        rect.setAttribute("stroke-width", 1);

        g.appendChild(rect);

        // ✅ label ABOVE cell (not center)
        const labelOffset = 5;

        // get top edge (remember we swapped width/height)
        const topY = c.location_y + (drawH / 2);

        const textX = c.location_x;
        const textY = topY + labelOffset;

        const text = document.createElementNS(svgNS, "text");

        text.setAttribute("x", textX);
        text.setAttribute("y", textY);

        text.setAttribute("font-size", 7);
        text.setAttribute("fill", "#000"); // ✅ better visibility
        text.setAttribute("font-weight", "bold");
        text.setAttribute("text-anchor", "middle");

        // flip back
        text.setAttribute(
          "transform",
          `scale(1,-1) translate(0, ${-2 * textY})`
        );

        text.textContent = c.cellCode;

        g.appendChild(text);


        // ✅ click works
        g.onclick = function (e) {
          e.stopPropagation();
          $(document).trigger("map:select", {
            type: "cell",
            id: c.cellCode
          });
        };

        root.appendChild(g);
      });

      
      function drawRobotPath(robot, cells, svgNS, root) {

        if (!Array.isArray(robot.path) || robot.path.length < 2) return;
      
        const CELL_SCALE = 40; // ✅ REQUIRED (RMS → UI scale)
      
        const pointsArr = [];
      
        robot.path.forEach(p => {
      
          const worldX = p.x * CELL_SCALE;
          const worldY = p.y * CELL_SCALE;
      
          // ✅ find closest cell (simple version)
          let nearest = null;
          let minDist = Infinity;
      
          for (const c of cells) {
            const dx = c.location_x - worldX;
            const dy = c.location_y - worldY;
            const dist = dx * dx + dy * dy;
      
            if (dist < minDist) {
              minDist = dist;
              nearest = c;
            }
          }
      
          if (nearest) {
            pointsArr.push(`${nearest.location_x},${nearest.location_y}`);
          }
        });
      
        if (pointsArr.length < 2) return;
      
        const polyline = document.createElementNS(svgNS, "polyline");
      
        polyline.setAttribute("points", pointsArr.join(" "));
        polyline.setAttribute("fill", "none");
        polyline.setAttribute("stroke", "#2196f3"); // ✅ BLUE
        polyline.setAttribute("stroke-width", 4);
        polyline.setAttribute("stroke-dasharray", "6,4");
        polyline.setAttribute("stroke-linecap", "round");
        polyline.setAttribute("opacity", "0.9");
      
        // ✅ draw behind
        root.insertBefore(polyline, root.firstChild);
      }
      
      /* ================= AMR ================= */
      amrs.forEach(r => {

        const g = document.createElementNS(svgNS, "g");
        g.classList.add("amr-clickable");

        const cx = r.location_x;
        const cy = r.location_y;

        // ✅ detect movement
        let moving = false;

        if (!prevBackendPos[r.robotId]) {
          prevBackendPos[r.robotId] = {
            x: r.location_x,
            y: r.location_y
          };
        }

        const prev = prevBackendPos[r.robotId];

        const dx = r.location_x - prev.x;
        const dy = r.location_y - prev.y;

        moving = Math.hypot(dx, dy) > 0.5;

        if (moving) {
          drawRobotPath(r, cells, svgNS, root); // ✅ pass cells
        }

        // update
        prevBackendPos[r.robotId] = {
          x: r.location_x,
          y: r.location_y
        };

        // ✅ color logic
        let color;

        if (r.status !== "NORMAL") {
          color = "#f44336"; // error
        } else if (moving) {
          color = "#2196f3"; // ✅ moving = BLUE
        } else {
          color = "#4caf50"; // idle
        }

        // body
        const body = document.createElementNS(svgNS, "circle");
        body.setAttribute("cx", cx);
        body.setAttribute("cy", cy);
        body.setAttribute("r", SIZE.amrRadius);
        body.setAttribute("fill", color);
        body.setAttribute("stroke", "#fff");
        body.setAttribute("stroke-width", 2);

        g.appendChild(body);

        // label
        const text = document.createElementNS(svgNS, "text");
        text.setAttribute("x", cx);
        text.setAttribute("y", cy);
        text.setAttribute("font-size", 8);
        text.setAttribute("fill", "#000"); // ✅ better visibility
        text.setAttribute("text-anchor", "middle");

        text.setAttribute(
          "transform",
          `scale(1,-1) translate(0, ${-2 * cy})`
        );

        text.textContent = String(r.robotId).slice(-3);

        g.appendChild(text);

        g.onclick = function (e) {
          e.stopPropagation();
          $(document).trigger("map:select", {
            type: "amr",
            id: r.robotId
          });
        };

        root.appendChild(g);
      });

      /* ================= KOTATSU ================= */
      kotatsus.forEach(k => {

        // ignore invalid
        if (k.location_x === 0 && k.location_y === 0) return;

        const g = document.createElementNS(svgNS, "g");
        g.classList.add("shelf-clickable");

        // ✅ use raw RMS position (no snapping)
        const cx = k.location_x;
        const cy = k.location_y;

        const horizontal = k.angle === 90 || k.angle === -90;

        // ✅ stable size (no dependency on cell)
        const stem = 40;   // main body length
        const bar = 24;    // top/bottom bar
        const thick = 8;   // thickness

        function rect(x, y, w, h) {
          const r = document.createElementNS(svgNS, "rect");

          r.setAttribute("x", x);
          r.setAttribute("y", y);
          r.setAttribute("width", w);
          r.setAttribute("height", h);
          
          r.setAttribute("fill", "none");                // ✅ no fill
          r.setAttribute("stroke", "#3f51b5");           // ✅ outline only
          r.setAttribute("stroke-width", 3);

          return r;
        }

        if (!horizontal) {
          // ✅ vertical "I"
          g.append(rect(cx - thick / 2, cy - stem / 2, thick, stem));
          g.append(rect(cx - bar / 2, cy + stem / 2 - thick, bar, thick));
          g.append(rect(cx - bar / 2, cy - stem / 2, bar, thick));
        } else {
          // ✅ horizontal "I"
          g.append(rect(cx - stem / 2, cy - thick / 2, stem, thick));
          g.append(rect(cx - stem / 2, cy - bar / 2, thick, bar));
          g.append(rect(cx + stem / 2 - thick, cy - bar / 2, thick, bar));
        }

        /* ✅ LABEL */
        const labelY = cy - stem / 2 - 8;
        const label = document.createElementNS(svgNS, "text");

        label.setAttribute("x", cx);
        label.setAttribute("y", labelY);
        label.setAttribute("font-size", 7);
        label.setAttribute("fill", "#fff");
        label.setAttribute("text-anchor", "middle");

        label.setAttribute(
          "transform",
          `scale(1,-1) translate(0, ${-2 * labelY})`
        );

        label.textContent = k.shelfCode;
        label.style.display = "none";

        g.appendChild(label);

        g.addEventListener("mouseenter", () => label.style.display = "block");
        g.addEventListener("mouseleave", () => label.style.display = "none");

        /* ✅ CLICK */
        g.onclick = function (e) {
          e.stopPropagation();
          $(document).trigger("map:select", {
            type: "shelf",
            id: k.shelfCode
          });
        };

        root.appendChild(g);
      });

      $("#map").empty().append(svg);
      setTransform();

    });
  }

  /* ================= LOOP ================= */
  setInterval(renderMap, 500);
});