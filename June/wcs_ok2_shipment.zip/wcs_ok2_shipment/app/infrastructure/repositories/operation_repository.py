# app/infrastructure/repositories/operation_repository.py

from app.interfaces.sql.wcs_sql_query import WCSSQLQuery
from app.interfaces.sql.iotds_sql_query import IOTDSSQLQuery
from app.domain.rms_domain import Cell, Kotatsu, Pallet, Task
from app.infrastructure.setup_log import setup_log
import app.config.config as cfg

# ログ設定 (名前を付ける)
logger = setup_log(
    cfg.LOG_FOLDER, 
    cfg.OPERATION_REPO_LOG_FILE, 
    cfg.BACKUP_DAYS, 
    logger_name="operation_repo"
)

class OperationRepository:
    """
    ライン作業に必要なDBアクセスを提供するリポジトリ
    ・システム状態
    ・ライン状態
    ・セル / コタツ情報
    ・タスク情報
    """

    def __init__(self, w, i):
        # w: WCSSQLQuery, i: IOTDSSQLQuery
        self._sql = w
        self._iotds_sql = i

    # --------------------------
    # システム状態取得
    # --------------------------
    def get_system_status(self):
        sql = self._sql.get_system_status()
        with self._sql.cursor_ctx(dictionary=True) as cur:
            cur.execute(sql)
            return cur.fetchall()
    
    # ------------------------------------------------
    # [WCSDB] t_line_statusのrequest_execution=1 更新
    # ------------------------------------------------
    def update_request_execution(self, data):
        sql = self._sql.update_request_execution()
        with self._sql.write_cursor_ctx() as cur:
            cur.execute(sql, (data["plat_no"], data["seq_no"]))

    # --------------------------
    # ライン状態取得
    # --------------------------
    def get_line_status(self):
        sql = self._sql.get_line_status()
        with self._sql.cursor_ctx(dictionary=True) as cur:
            cur.execute(sql)
            return cur.fetchall()

    # --------------------------
    # ライン状態出力
    # --------------------------
    def out_system_status_off(self):
        sql1 = self._sql.get_signal_status()
        sql2 = self._iotds_sql.change_t_output_value()
        try:
            with self._sql.cursor_ctx(dictionary=True) as cur:
                cur.execute(sql1, ("MODE",))
                rows = cur.fetchall()
                if not rows:
                    logger.debug(f"out_system_status_on: No rows returned for signal status query.")
                    return
                with self._iotds_sql.write_cursor_ctx() as cur2:
                    for row in rows:
                        params = (0, row['signal_id'])
                        cur2.execute(sql2, params)
        except Exception as e:
            logger.error(f"Error in out_system_status_off: {e} {self._sql.get_signal_status()}, {self._iotds_sql.change_t_output_value()}, 0, {row['signal_id']}")

    def out_system_status_on(self):
        sql1 = self._sql.get_signal_status()
        sql2 = self._iotds_sql.change_t_output_value()
        try:
            with self._sql.cursor_ctx(dictionary=True) as cur:
                cur.execute(sql1, ("MODE",))
                rows = cur.fetchall()
                if not rows:
                    logger.debug(f"out_system_status_on: No rows returned for signal status query.")
                    return
                with self._iotds_sql.write_cursor_ctx() as cur2:
                    for row in rows:
                        params = (1, row['signal_id'])
                        cur2.execute(sql2, params)
        except Exception as e:
            logger.error(f"Error in out_system_status_off: {e} {self._sql.get_signal_status()}, {self._iotds_sql.change_t_output_value()}, 0, {row['signal_id']}")
