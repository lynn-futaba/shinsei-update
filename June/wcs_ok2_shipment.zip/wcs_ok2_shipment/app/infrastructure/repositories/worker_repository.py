"""
作業者リポジトリ (WorkerRepository)
作成者: Lynn
----------------------------------
【役割】
「間口操作」や「パレット供給スケジュール」など、現場作業者向けの機能を支えるDB操作クラスです。

【チームへのメリット】
1. 複雑な並べ替えロジックの隠蔽:
   パレットの挿入・削除時に発生する「INDEXのずらし操作（Shift Up/Down）」を
   リポジトリ内で完結させ、上位層にはクリーンな結果だけを返します。
2. 安全な状態遷移:
   `READY -> WORK -> COMP` といった業務ルールに沿った遷移かどうかを、
   DB更新直前に厳格にチェックします。
"""
# app/infrastructure/repositories/worker_repository.py
from __future__ import annotations
from typing import Optional, Iterable, List, Dict
from mysql.connector.cursor import MySQLCursorDict

from app.interfaces.sql.wcs_sql_query import WCSSQLQuery
from app.infrastructure.factory.domain_factory import WorkerFactory
from app.domain.entities import Maguchi, LiftEntrance, PalletScheduleLine, PalletPair

from app.domain.exception import NotFoundError, InvalidStateError, StaleWriteError

from app.infrastructure.setup_log import setup_log
import app.config.config as cfg

# ログ設定 (名前を付ける)
logger = setup_log(cfg.LOG_FOLDER, cfg.WORKER_REPO_LOG_FILE, cfg.BACKUP_DAYS, logger_name="worker_repo")


class WorkerRepository(WorkerFactory):
    """
    現場作業者画面に関連するMySQL操作の具象実装です。
    """

    def __init__(self, db, wcs_sql: WCSSQLQuery, db_name: str = "futaba_ok2_shippment"):
        self._db = db
        self._db_name = db_name
        self._sql = wcs_sql
        logger.info("[WorkerRepository] initialized", extra={"db_name": db_name})

    def list_lift_entrance(self) -> list:
        sql = self._sql.t_lift_station_select_all()
        conn = self._db.get_connection()

        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            rows = cur.fetchall()

            for row in rows:
                pallet_id = row.get("pallet_id")
                status = str(row.get("transport_status", "")).upper()

                if not pallet_id:
                    continue

                # =========================
                # Get real pallet
                # =========================
                cur.execute("""
                    SELECT ps.pallet_type, m.pallet_name, m.line_id
                    FROM t_pallet_status ps
                    JOIN m_pallet m 
                        ON ps.pallet_type = m.pallet_type
                    WHERE ps.pallet_id = %s
                    LIMIT 1
                """, (pallet_id,))
                pallet_row = cur.fetchone()

                real_name = pallet_row["pallet_name"] if pallet_row else ""

                line_id = pallet_row.get("line_id") if pallet_row else None

                # =========================
                # Get pair_index = 0
                # =========================
                cur.execute("""
                    SELECT m.pallet_name
                    FROM t_pallet_supply_pairs p
                    JOIN m_pallet m ON p.pallet_type = m.pallet_type
                    WHERE p.line_id = %s
                    AND p.pair_index = 0
                    LIMIT 1
                """, (line_id,))
                pair_row = cur.fetchone()

                pair_name = pair_row["pallet_name"] if pair_row else None

                is_kanban = (
                    pair_name and "掛けカンバン" in pair_name
                )

                # ===========================================
                # ✅ STATUS-BASED DISPLAY (FIXED)
                # ===========================================

                if status == "COMP":
                    row["pallet_name"] = real_name

                elif status == "WORK":
                    row["pallet_name"] = (
                        pair_name if pair_name else real_name
                    )

                elif status == "READY":
                    # if is_kanban:
                    #     row["pallet_name"] = pair_name
                    # else:
                    # get kotatsu pallet
                    cur.execute("""
                        SELECT m.pallet_name
                        FROM t_kotatsu_status k
                        JOIN t_pallet_status ps 
                            ON k.loaded_pallet_id = ps.pallet_id
                        JOIN m_pallet m 
                            ON ps.pallet_type = m.pallet_type
                        WHERE k.loaded_pallet_id = %s
                        LIMIT 1
                    """, (pallet_id,))
                    ready_row = cur.fetchone()

                    row["pallet_name"] = (
                        ready_row["pallet_name"]
                        if ready_row else real_name
                    )

                else:
                    # fallback safety
                    row["pallet_name"] = real_name
                   
            cur.close()
            return [WorkerFactory.get_lift_entrance(r) for r in rows]

        finally:
            conn.close()
               
    # --- get single row by primary key ---
    def get_by_pk(self, plat_no: int, seq_no: int) -> LiftEntrance | None:
        sql = self._sql.t_lift_station_select_one_by_pk()
        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql, (plat_no, seq_no))
            row = cur.fetchone()
            cur.close()
            return WorkerFactory.get_lift_entrance(row) if row else None
        finally:
            conn.close() 
    
    def update_state(self, plat_no: int, seq_no: int, pallet_id: int, next_state: str) -> LiftEntrance:

        code_to_status = {0: "READY", 1: "WAIT", 2: "WORK", 3: "COMP"}

        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)

            # 1) Lock lift station
            cur.execute(self._sql.t_lift_station_lock_status_by_pk(), (plat_no, seq_no))
            row = cur.fetchone()
            if not row:
                raise NotFoundError(f"Platform {plat_no}, seq {seq_no} not found.")

            raw = row["transport_status"]
            current = code_to_status.get(int(raw)) if str(raw).isdigit() else str(raw).upper()

            desired = "COMP" if str(next_state).upper() == "FINISH" else str(next_state).upper()

            logger.warning(
                "STATE CHECK: current=%s desired=%s next_state=%s raw=%r",
                current, desired, next_state, raw
            )

            # State Transition Logic
            if current in ("READY", "WAIT") and desired == "WORK":
                db_next = "WORK"
            elif current == "WORK" and desired == "COMP":
                db_next = "COMP"
            else:
                raise InvalidStateError(f"Invalid transition: {current} -> {desired}")

            # 2) Get Cell Code
            cur.execute(self._sql.m_location_select_cell_by_pk(), (plat_no, seq_no))
            cell_row = cur.fetchone()
            if not cell_row:
                raise NotFoundError(f"No cell info for plat={plat_no}, seq={seq_no}")
            
            logger.info("cell_code=%r kotatsu_id=%r pallet_id=%r", 
                    cell_row["cell_code"], 
                    cell_row["kotatsu_id"],
                    cell_row["pallet_id"]
            )
            
            kotatsu_id = cell_row.get("kotatsu_id")
                        
            # mismatch check
            if str(pallet_id) != str(cell_row.get("pallet_id")):
                logger.warning(
                    f"Error in pallet id is different: Lift ST.: {pallet_id}, Kotatsu: {cell_row.get('pallet_id')}"
                )

            # =========================
            # Get REAL pallet
            # =========================
            cur.execute("""
                SELECT m.pallet_name, m.pallet_type, m.line_id
                FROM t_pallet_status t
                JOIN m_pallet m ON t.pallet_type = m.pallet_type
                WHERE t.pallet_id = %s
                LIMIT 1
            """, (pallet_id,))
            pallet_row = cur.fetchone()

            if not pallet_row:
                logger.warning(f"[UNKNOWN PALLET] pallet_id={pallet_id}")
                return WorkerFactory.get_lift_entrance(row)

            real_pallet_name = pallet_row.get("pallet_name", "")
            real_pallet_type = pallet_row.get("pallet_type")
            line_id = pallet_row.get("line_id")
            
            pair_row = None
            pallet_name = None
            
            # ✅ ✅ READY → use kotatsu loaded pallet
            if current == "READY" and db_next != "WORK":

                cur.execute("""
                    SELECT m.pallet_name, m.pallet_type
                    FROM t_kotatsu_status k
                    JOIN t_pallet_status ps 
                        ON k.loaded_pallet_id = ps.pallet_id
                    JOIN m_pallet m 
                        ON ps.pallet_type = m.pallet_type
                    WHERE k.kotatsu_id = %s
                    LIMIT 1
                """, (kotatsu_id,))

                ready_row = cur.fetchone()

                pallet_name = ready_row["pallet_name"] if ready_row else real_pallet_name
                logger.info(f"[READY FLOW] Using kotatsu pallet: {pallet_name}")


            # =========================
            # SUPPLY FLOW (WORK)
            # =========================
            else:
                cur.execute("""
                    SELECT p.line_id, p.pallet_type, m.pallet_name
                    FROM t_pallet_supply_pairs p
                    JOIN m_pallet m ON p.pallet_type = m.pallet_type
                    WHERE p.line_id = %s
                    AND p.pair_index = 0
                    LIMIT 1
                """, (line_id,))

                pair_row = cur.fetchone()
                pallet_name = pair_row["pallet_name"] if pair_row else real_pallet_name
                logger.info(f"[SUPPLY FLOW] Using pair pallet: {pallet_name}")
                
            # =========================
            # ✅ FIXED KANBAN DETECTION
            # =========================
            is_kanban = (
                pair_row and "掛けカンバン" in pair_row.get("pallet_name", "")
            )

            # ✅ always sync pallet_id
            cur.execute(
                self._sql.update_t_lift_station_pallet_id(),
                (pallet_id, plat_no, seq_no)
            )
            
            # ===========================================
            # WORK (START ACTION 取出開始　→　投入完了 )
            # ===========================================
            if db_next == "WORK":  
                
                # ✅ 1. Determine supply pallet_type (COMMON for both cases)
                if pair_row:
                    supply_type = pair_row["pallet_type"] # pairs, index0
                else:
                    supply_type = real_pallet_type

                # ✅ 2. Always sync pallet_type (VERY IMPORTANT)
                cur.execute(
                    self._sql.update_t_pallet_status_pallet_id(),
                    (supply_type, pallet_id)
                )
    
                if is_kanban:
                    # Update t_pallet_status EMPTY
                    cur.execute(self._sql.t_pallet_status_update(), ("EMPTY", pallet_id))
                    logger.info(f"[WORK - KANBAN] No kotatsu update")
                    
                else:
                    logger.info(f"[WORK - REAL] pallet={pallet_id}, kotatsu={kotatsu_id}")
                    
                    # update kotatsu
                    cur.execute(self._sql.t_kotatsu_update_loaded_pallet(), (pallet_id, kotatsu_id))
                    
                    # Update t_pallet_statusのstatus only
                    cur.execute(self._sql.t_pallet_status_update(), ("EMPTY", pallet_id))
                    logger.info(f"WORK - Loaded pallet {pallet_id} onto {kotatsu_id}")
                    
                # Update lift status
                cur.execute(self._sql.op_update_lift_station(), (pallet_id, "WORK", plat_no, seq_no))
                    
                    
            elif db_next == "COMP": # --- FINISH ACTION 投入完了 → 完了ボタンを押す時の場合--- 
                                   
                if is_kanban:
                    # Update t_pallet_status EMPTY
                    cur.execute(self._sql.t_pallet_status_update(), ("EMPTY", pallet_id))
                    # ✅ DO NOTHING to pallet_type
                    cur.execute(self._sql.op_update_lift_station(),
                        (pallet_id, "COMP", plat_no, seq_no))

                    logger.info(f"[COMP - KANBAN (NO DB CHANGE)] {pallet_name}")

                else:
                    # ✅ decrease supply
                    if pair_row:
                        updated = self.ps_decrease_supply_count(
                            cur,  # ✅ IMPORTANT: pass SAME cursor TODO: add lynn
                            line_id=line_id,
                            pallet_type=pair_row["pallet_type"]
                        )
                        
                        if updated:
                            logger.info(
                                f"Decreased supply count: line={line_id} pallet_type={pair_row['pallet_type']}"
                            )
                        else:
                            logger.warning(f"[SKIP DECREASE] line_id is None for pallet_id={pallet_id}")
                            
                        # ✅ AFTER ps_decrease_supply_count
                        # 1. get current group0 pair
                        cur.execute("""
                            SELECT id, count
                            FROM t_pallet_supply_pairs
                            WHERE line_id = %s AND pair_index = 0
                            LIMIT 1
                        """, (line_id,))
                        p = cur.fetchone()

                        if p:
                            pair_id = p["id"]
                            count = p["count"]

                            # ✅ 2. If count reached 0 → delete directly
                            if count == 0:
                                logger.info(f"[AUTO DELETE TRIGGER] pair_id={pair_id}")

                                # ✅ 1. DELETE current group0
                                cur.execute("""
                                    DELETE FROM t_pallet_supply_pairs
                                    WHERE id = %s
                                """, (pair_id,))
                                
                                logger.info(f"[AUTO DELETE DONE] pair_id={pair_id}")
                                
                                # ✅ 2. SHIFT indexes down
                                cur.execute("""
                                    UPDATE t_pallet_supply_pairs
                                    SET pair_index = pair_index - 1
                                    WHERE line_id = %s
                                    AND pair_index > 0
                                """, (line_id,))

                                logger.info(f"[INDEX SHIFT DONE] line_id={line_id}")

                                # ✅ 3. Check if next group0 exists
                                cur.execute("""
                                    SELECT pallet_type
                                    FROM t_pallet_supply_pairs
                                    WHERE line_id = %s AND pair_index = 0
                                    LIMIT 1
                                """, (line_id,))
                                
                                new_group0 = cur.fetchone()

                                if new_group0:
                                    # ✅ 3. Sync ONLY using NEW group0
                                    self._sync_group0_pallet_type(cur, line_id)
                                else:
                                    logger.warning(f"[SYNC SKIP] no next group0 after delete for line={line_id}")

                        else:
                            logger.warning(f"[DEBUG] No group0 found for line_id={line_id}")

                    
                    # ✅ remove ONLY kanban rows (not real pallets)
                    # cur.execute("""
                    #     DELETE p
                    #     FROM t_pallet_supply_pairs p
                    #     JOIN m_pallet m ON p.pallet_type = m.pallet_type
                    #     WHERE p.line_id = %s
                    #     AND m.pallet_name LIKE '掛けカンバン%%'
                    # """, (line_id,))

                    # logger.info(f"[COMP] removed kanban pair rows for line={line_id}")

                    # ✅ 3. 🔥 RESTORE REAL pallet_type (MOST IMPORTANT)
                    cur.execute(
                        self._sql.update_t_pallet_status_pallet_id(),
                        (real_pallet_type, pallet_id)
                    )

                    logger.info(
                        f"[COMP] restore pallet_type → {real_pallet_type} for pallet_id={pallet_id}"
                    )
                    # Update t_pallet_status EMPTY
                    cur.execute(self._sql.t_pallet_status_update(), ("EMPTY", pallet_id))
                    cur.execute(self._sql.op_update_lift_station(), (pallet_id, "COMP", plat_no, seq_no))
                    
                    # Update t_kotatsu_status→ booking=0
                    cur.execute(self._sql.t_kotatsu_status_update(), (kotatsu_id,))       
                    
                    logger.info(f"[COMP] pallet={pallet_id}")

            conn.commit()

            # 4) Return updated row for UI refresh
            cur.execute(self._sql.t_lift_station_select_one_by_pk(), (plat_no, seq_no))
            final_row = cur.fetchone()
            
            return WorkerFactory.get_lift_entrance(final_row)
        
        except Exception as e:
            conn.rollback() 
            logger.error(f"Error in update_state: {str(e)}")
            raise
        finally:
            conn.close()
            
    ### ------------------------###
    ### 空パレット供給スケジュール
    ### ------------------------###
    def ps_line_exists(self, line_name: str) -> bool:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM m_line WHERE line_name = %s", (line_name,))
            return cur.fetchone() is not None
        finally:
            conn.close()
    
    def ps_list_all(self) -> List[PalletScheduleLine]:
        results = []
        conn = self._db.get_connection(self._db_name)

        try:
            cur = conn.cursor(dictionary=True)

            # ✅ 1. get all lines
            cur.execute(self._sql.ps_get_all_lines())
            lines = cur.fetchall()

            for row in lines:
                l_id = row["line_id"]

                # ✅ 2. get current pairs
                cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
                pairs = cur.fetchall()

                # ===========================================
                # ✅ ✅ FIX: SAFE KANBAN INSERT CONDITION
                # ===========================================
                if not pairs:

                    # ✅ check if this line is currently in use (WORK)
                    cur.execute("""
                        SELECT COUNT(*) AS cnt
                        FROM t_lift_station ls
                        JOIN t_pallet_status ps ON ls.pallet_id = ps.pallet_id
                        JOIN m_pallet m ON ps.pallet_type = m.pallet_type
                        WHERE m.line_id = %s
                        AND ls.transport_status IN ('WORK')
                    """, (l_id,))

                    active_row = cur.fetchone()
                    is_active = active_row and active_row["cnt"] > 0
                    
                    if not is_active:

                        # 🔥 find kanban pallet_type
                        cur.execute("""
                            SELECT pallet_type
                            FROM m_pallet
                            WHERE pallet_name LIKE '掛けカンバン(%'
                            AND line_id = %s
                            LIMIT 1
                        """, (l_id,))
                        kanban_row = cur.fetchone()

                        if kanban_row:
                            kanban_type = kanban_row["pallet_type"]

                            logger.info(
                                f"[AUTO INSERT SAFE] 掛けカンバン line_id={l_id}"
                            )

                            # ✅ insert ONLY ONCE
                            cur.execute("""
                                INSERT INTO t_pallet_supply_pairs
                                    (line_id, pair_index, pallet_type, count)
                                VALUES (%s, 0, %s, 1)
                            """, (l_id, kanban_type))

                            conn.commit()

                            # reload
                            cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
                            pairs = cur.fetchall()
                    else:
                        logger.info(
                            f"[SKIP INSERT] line {l_id} still active (WORK/COMP)"
                        )

                # ✅ 3. build entity
                results.append(
                    WorkerFactory.pallet_schedule_line_from_rows(
                        line_name=row["line_name"],
                        rows=pairs,
                        line_id=l_id
                    )
                )

            return results

        finally:
            conn.close()

    def ps_list_names(self, line_name: str) -> List[Dict]:
        """Return [{pallet_type, pallet_name}] for UI dropdown."""
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(self._sql.ps_get_all_master_pallets())
            rows = cur.fetchall()
            return [{"pallet_type": r["pallet_type"], "pallet_name": r["pallet_name"]} for r in rows]
        finally:
            conn.close()
            
    def ps_apply_pattern(self, pattern_no: int):
        conn = self._db.get_connection(self._db_name)
        try:
            conn.start_transaction()
            cur = conn.cursor()

            # 1. Clear transaction table
            cur.execute("TRUNCATE TABLE t_pallet_supply_pairs")

            # 2. Insert from master
            insert_sql = """
                INSERT INTO t_pallet_supply_pairs
                    (line_id, pair_index, pallet_type, count)
                SELECT SQL_NO_CACHE
                    line_id,
                    pair_index,
                    pallet_type,
                    count
                FROM m_pallet_supply_pairs
                WHERE pattern_no = %s
                ORDER BY line_id, pair_index
            """
            cur.execute(insert_sql, (pattern_no,))
            # if pattern_apply, update transport_status to WORK
            existing = cur.fetchall()
            # if not existing:
            #     cur.execute(self._sql.update_t_lift_station_transport_status(), ("READY",))
            #     conn.commit()

            conn.commit()
            return self.ps_list_all()

        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
            
    # ---------- パレット供給スケジュール (Pallet Schedule) ----------
    def ps_update_pair(self, line_id: int, pair_id: int, pallet_type: int, count: int) -> Optional[PalletScheduleLine]:
        """
        特定の行のパレット種別や数量を更新します。
        """
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # 1. ライン情報と現在のリビジョンを取得
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None
            l_id = line["line_id"]


            # 2. validate pallet_type exists
            cur.execute(self._sql.ps_check_pallet_type_exists(), (pallet_type,))
            if cur.fetchone() is None:
                return None  # or raise NotFoundError
            
            # ✅ 3. get pair_index of this pair_id  🔥 IMPORTANT
            cur.execute("""
                SELECT pair_index
                FROM t_pallet_supply_pairs
                WHERE id = %s
            """, (pair_id,))
            pair_row = cur.fetchone()

            if not pair_row:
                return None

            pair_index = pair_row["pair_index"]

            # 4. update pair table
            cur.execute(self._sql.ps_update_pair(), (pallet_type, count, pair_id))
            
            # ✅ Sync after delete # TODO: added to update pallet_type for t_pallet_status
            self._sync_group0_pallet_type(cur, line_id)
                
            conn.commit()
            return self.ps_get_line(line_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()    

    def ps_add_pair(self, line_id: int, before_index: Optional[int], pallet_type: int, count: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # Resolve line & ensure status row exists (first time)
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None
            l_id = line["line_id"]

            # (optional) validate pallet_type exists
            cur.execute(self._sql.ps_check_pallet_type_exists(), (pallet_type,))
            if cur.fetchone() is None:
                return None

            # Determine insertion index from current view
            cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
            existing = cur.fetchall()
            
            # if not existing:
            #     cur.execute(self._sql.update_t_lift_station_transport_status(), ("READY",))
            #     conn.commit()
            
            n = len(existing)
            target_idx = before_index if (before_index is not None and 0 <= int(before_index) <= n) else n

            # Shift up and insert
            cur.execute(self._sql.ps_shift_pairs_up(), (l_id, target_idx))
            cur.execute(self._sql.ps_insert_pair(), (l_id, target_idx, pallet_type, count))
            
            # ✅ Sync after delete # TODO: added to update pallet_type for t_pallet_status
            self._sync_group0_pallet_type(cur, line_id)

            conn.commit()
            return self.ps_get_line(line_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_delete_pair(self, line_id: int, pair_id: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # 1. get line
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None

            # 2. get pair_index
            cur.execute(
                "SELECT pair_index FROM t_pallet_supply_pairs WHERE id = %s AND line_id = %s",
                (pair_id, line_id)
            )
            row = cur.fetchone()
            if not row:
                return None

            pair_index = row["pair_index"]

            # 3. delete
            cur.execute(self._sql.ps_delete_pair(), (pair_id,))
            cur.execute(self._sql.ps_shift_pairs_down(), (line_id, pair_index))
            
            # 4. after delete + shift
            cur.execute("""
                SELECT COUNT(*) AS cnt
                FROM t_pallet_supply_pairs
                WHERE line_id = %s
            """, (line_id,))
            cnt_row = cur.fetchone()

            if cnt_row and cnt_row["cnt"] == 0:

                # ✅ check COMP state (same as ps_list_all), we can delete in WORK state
                cur.execute("""
                    SELECT COUNT(*) AS cnt
                    FROM t_lift_station ls
                    JOIN t_pallet_status ps ON ls.pallet_id = ps.pallet_id
                    JOIN m_pallet m ON ps.pallet_type = m.pallet_type
                    WHERE m.line_id = %s
                    AND ls.transport_status IN ('COMP')
                """, (line_id,))
                
                active_row = cur.fetchone()
                is_active = active_row and active_row["cnt"] > 0

                if not is_active:

                    # ✅ find kanban pallet
                    cur.execute("""
                        SELECT pallet_type
                        FROM m_pallet
                        WHERE pallet_name LIKE '掛けカンバン(%'
                        AND line_id = %s
                        LIMIT 1
                    """, (line_id,))
                    kanban_row = cur.fetchone()

                    if kanban_row:
                        cur.execute("""
                            INSERT INTO t_pallet_supply_pairs
                            (line_id, pair_index, pallet_type, count)
                            VALUES (%s, 0, %s, 1)
                        """, (line_id, kanban_row["pallet_type"]))

                        logger.info(f"[KANBAN RE-INSERT after delete] line={line_id}")
            
            
                # ✅ Sync only if at least 1 row exists
                cur.execute("""
                    SELECT COUNT(*) AS cnt
                    FROM t_pallet_supply_pairs
                    WHERE line_id = %s
                """, (line_id,))
                row_after = cur.fetchone()

                if row_after and row_after["cnt"] > 0:
                    self._sync_group0_pallet_type(cur, line_id)
                else:
                    logger.warning(f"[SYNC SKIP AFTER DELETE] no rows for line={line_id}")


            conn.commit()
            return self.ps_get_line(line_id)

        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_move_to_group0(self, line_id: int, pair_index: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            line = cur.fetchone()
            if not line:
                return None
            
            l_id = line["line_id"]

            # Move target out
            cur.execute("UPDATE t_pallet_supply_pairs SET pair_index = -1 WHERE line_id = %s AND pair_index = %s", (l_id, pair_index))
            # Close gap
            cur.execute(self._sql.ps_shift_pairs_down(), (l_id, pair_index))
            # Open gap at 0
            cur.execute(self._sql.ps_shift_pairs_up(), (l_id, 0))
            # Place at 0
            cur.execute("UPDATE t_pallet_supply_pairs SET pair_index = 0 WHERE line_id = %s AND pair_index = -1", (l_id,))

            
            # ✅ Sync after move # TODO: added to update pallet_type in t_pallet_status
            self._sync_group0_pallet_type(cur, l_id)


            conn.commit()
            return self.ps_get_line(line_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_get_line(self, line_id: int) -> Optional[PalletScheduleLine]:
        """Helper to refresh a single line row in UI"""
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # get line header
            cur.execute(self._sql.ps_get_line_by_id(), (line_id,))
            row = cur.fetchone()
            if not row:
                return None

            # get pairs
            cur.execute(self._sql.ps_get_pairs_by_line(), (row["line_id"],))
            pairs = cur.fetchall()

            return WorkerFactory.pallet_schedule_line_from_rows(
                line_name=row["line_name"],   # ✅ comes from DB
                rows=pairs,
                line_id=row["line_id"],       # ✅ passed once
            )
        finally:
            conn.close()
    
    def get_all_master_pallets(self) -> List[Dict]:
        """Service calls this exactly"""
        # Use self._queries (not self._sql if you renamed it)
        sql = self._sql.ps_get_all_master_pallets() 
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            return cur.fetchall()
        except Exception as e:
            print(f"Database Error: {e}") # This will show in your terminal
            raise e
        finally:
            conn.close()
    
    # TODO: added cur        
    def ps_decrease_supply_count(self, cur, line_id: int, pallet_type: int) -> bool:
        """
        Decrease pallet supply count by 1 (if count > 0).
        Uses SAME transaction cursor (no new connection).
        Returns True if decremented, False if nothing changed.
        """
            
        logger.warning(
            f"[DEBUG] ENTER ps_decrease_supply_count → line_id={line_id}, pallet_type={pallet_type}"
        )

        cur.execute(
            self._sql.ps_decrease_pair_count_if_positive(),
            (line_id, pallet_type)
        )

        logger.warning(f"[DEBUG] SQL EXECUTED → rowcount={cur.rowcount}")
        
        updated = cur.rowcount > 0
        return updated
    
    def _sync_group0_pallet_type(self, cur, line_id: int):
        """
        Sync t_pallet_status.pallet_type with group0 pallet
        """
        cur.execute("""
            SELECT pallet_type
            FROM t_pallet_supply_pairs
            WHERE line_id = %s AND pair_index = 0
            LIMIT 1
        """, (line_id,))
        row = cur.fetchone()

        if not row:
            logger.warning(f"[SYNC SKIP] no group0 for line={line_id}")
            return

        new_type = row["pallet_type"]

        cur.execute("""
            UPDATE t_pallet_status ps
            JOIN t_lift_station ls ON ps.pallet_id = ls.pallet_id
            JOIN m_pallet m ON ps.pallet_type = m.pallet_type
            SET ps.pallet_type = %s
            WHERE m.line_id = %s
        """, (new_type, line_id))

        logger.info(f"[SYNC OK] line={line_id} pallet_type={new_type}")
