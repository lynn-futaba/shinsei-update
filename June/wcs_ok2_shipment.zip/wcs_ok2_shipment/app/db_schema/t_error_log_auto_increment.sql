INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1476, 'E112011', 3341002, 3442006, '2025-04-28 17:40:00', b'1', '2025-04-28 17:40:07', '2026-05-26 14:11:53');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1477, 'E121000', 3341002, 3442006, '2025-04-28 17:42:25', b'1', '2025-04-28 17:42:54', '2026-04-15 19:24:05');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1478, 'E112000', 3341002, 3442006, '2025-04-28 17:43:36', b'1', '2025-04-28 17:43:45', '2026-04-15 19:24:00');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1479, 'E112003', NULL, 3442005, '2025-04-28 17:49:00', b'1', '2025-04-28 17:49:04', '2026-04-15 19:23:58');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1480, 'E112003', NULL, 3441935, '2025-04-28 17:49:07', b'1', '2025-04-28 17:49:18', '2026-04-15 19:23:56');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1481, 'E121111', NULL, 3441935, '2025-04-28 17:49:23', b'1', '2025-04-28 17:49:29', '2026-04-14 02:48:53');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1482, 'E121111', NULL, 3442005, '2025-04-28 17:49:15', b'1', '2025-04-28 17:49:29', '2026-04-14 02:49:23');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1483, 'E121057', NULL, 3441935, '2025-04-28 17:50:15', b'1', '2025-04-28 17:50:19', '2026-04-14 02:45:10');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1484, 'E112007', 3341003, 3442005, '2025-04-28 17:51:41', b'1', '2025-04-28 17:51:51', '2026-04-14 02:45:00');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1485, 'E121108', 3341003, 3442005, '2025-04-28 17:52:56', b'1', '2025-04-28 17:53:02', '2026-04-14 02:44:41');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1486, 'E121111', 3341003, 3442005, '2025-04-28 17:53:08', b'1', '2025-04-28 17:53:21', '2026-04-14 02:14:38');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1487, 'E112000', 3341003, 3442005, '2025-04-28 17:53:46', b'1', '2025-04-28 17:53:48', '2026-04-14 02:14:34');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1488, 'E121111', NULL, 3441935, '2025-04-28 17:54:43', b'1', '2025-04-28 17:54:52', '2026-04-14 02:14:20');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1489, 'E121000', 3341004, 3441935, '2025-04-28 17:57:04', b'1', '2025-04-28 17:57:19', '2026-04-14 02:13:46');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1490, 'E112011', 3341004, 3441935, '2025-04-28 17:57:58', b'1', '2025-04-28 17:58:07', '2026-04-14 02:13:23');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1491, 'E121111', 3341003, 3442005, '2025-04-28 18:01:13', b'1', '2025-04-28 18:01:27', '2026-04-14 02:13:20');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1492, 'E121072', 3341003, 3442005, '2025-04-28 18:01:28', b'1', '2025-04-28 18:01:34', '2026-04-14 02:13:17');
INSERT INTO `t_error_log_new` (`error_num`, `error_code`, `task_id`, `robot_id`, `error_datetime`, `is_completed`, `created_date`, `updated_date`) VALUES (1493, 'E112000', 3341004, 3441935, '2025-04-28 18:01:39', b'1', '2025-04-28 18:01:48', '2026-04-14 02:13:14');

CREATE TABLE `t_error_log` (
	`error_num` INT NOT NULL AUTO_INCREMENT COMMENT 'エラーID',
	`error_code` VARCHAR(50) NOT NULL COMMENT 'エラーコード' COLLATE 'utf8mb4_unicode_ci',
	`task_id` INT NULL DEFAULT NULL COMMENT 'タスクID',
	`robot_id` INT NULL DEFAULT NULL COMMENT 'ロボットID',
	`error_datetime` DATETIME NOT NULL DEFAULT (now()) COMMENT 'エラー発生時刻(yyyy/MM/dd hh:mm:ss)',
	`is_completed` BIT(1) NOT NULL COMMENT '完了状況',
	`created_date` DATETIME NOT NULL DEFAULT (now()) COMMENT '作成日時(yyyy/MM/dd hh:mm:ss)',
	`updated_date` DATETIME NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP COMMENT '変更日時(yyyy/MM/dd hh:mm:ss)',
	PRIMARY KEY (`error_num`) USING BTREE
)
COLLATE='utf8mb4_unicode_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1579

RENAME TABLE
    t_error_log TO t_error_log_old,
    t_error_log_new TO t_error_log;