"""
自動搬送運用サービス（OperationNiService）
作成者: Lynn
---------------------------------------------
単一台のAMRを使用した、順次実行型の搬送制御サービス。

本サービスはすべての搬送工程を「直列（順番どおり）」に実行し、
前工程の完了を確認してから次工程へ進む運用を行う。

【実行シーケンス（固定順）】
順次 ➀-1 ⇒ ➀-2 ⇒ ➀-4 ⇒ ➀-3

  ➀-1 完成品 → TEMP
  ➀-2 空パレット → WAIT
  ➀-4 TEMP → 完成品出口
  ➀-3 WAIT → 投入口

主な役割:
1. 搬送手順の順序制御:
   - 並列処理を行わず、1つずつ確実に工程を進める。
2. 搬送状態の管理:
   - セル・コタツ・パレットの予約と解放を適切に制御。
3. 安全性重視の設計:
   - 各工程で異常が発生した場合は、即時処理を中断。
4. 疎結合設計:
   - RMS操作は OperationRMS に委譲し、本クラスは搬送手順の制御に専念する。

本クラスは、搬送をシンプルかつ確実に行う運用モードで使用される。
"""
# app/services/operation_ni_service.py

import time
import threading
from app.infrastructure.setup_log import setup_log
import app.config.config as cfg
from app.interfaces.api_client.operation_rms_api import OperationRMS

logger = setup_log(
    cfg.LOG_FOLDER, cfg.OPERATION_SEV_LOG_FILE, cfg.BACKUP_DAYS,
    logger_name="operation_svc"
)

# =====================================================================
#  FULL OPERATION NI SERVICE 完全運用サービス
# =====================================================================
class OperationService:
    """
    ライン単位の搬送作業を実行するサービス
    ・完成品搬送
    ・空パレット搬送
    ・セル/コタツの更新
    """

    def __init__(self, wcs_sql, iot_repo):
        self.op_rms = OperationRMS(wcs_sql)
        self.iot_repo = iot_repo

    # =====================================================================
    # 初期搬送(回転セルまで)
    # =====================================================================
    def first_carry_step(self, cells, kot, pal):
        """
        回転セルまで搬送する処理
        1、セルとコタツの状態を更新 - DBに情報をUP
        2、搬送のAPI発行
        3、搬送完了待ち
        """
        logger.info("➀-1 完成品,【CELL】INPUT取出し開始")

        # ✅ 1) State update
        # セルとコタツの状態を更新
        if not self.op_rms.update_state(cells["turn"], kot["complete"]):
            logger.error("[OPS] ➀-1 update_state 失敗")
            self.op_rms.insert_error_log(error_code="E400010",robot_id=None,task_id=None)
            return None, False

        # ✅ 2) Task execution
        # 完成品を投入間口から回転セルまで搬送のスレット登録
        res, task_id, start_cell = self.op_rms.send_fetch(
            step="cw_rotion_carry",
            start_cell=cells["input"],
            dest_cell=cells["turn"],
            kotatsu=kot["complete"],
            pallet=pal["complete"],
            task_number=None,
        )

        if not res:
            logger.error("[OPS] ➀-1 send_task 失敗")
            return None, False

        logger.info(f"[OPS] ➀-1 send_task 成功, task_id={task_id}, dest_cell={cells['turn'].id}")
        # ✅ 3) Wait for completion
        ok, task_id, task = self.op_rms.wait_for_task(
            task_id,
            start_cell,
            dest_cell_id=cells["turn"].id,
            kotatsu_id=kot["complete"].id
        )

        if not ok:
            logger.error("[OPS] ➀-1 wait_for_task 失敗")
            return None, False

        # ✅ 5) Clear update
        # セルの占有をクリアする処理
        cells["input"].clear_occupant()
        # self.op_rms.update_cell(cells["input"], resrve=False)
        self.op_rms.clear_state(cells["input"], cells["turn"], kot["complete"])
        logger.info(f"[OPS] ➀-1 搬送成功-task_id={task_id}, dest_cell={cells['turn'].id}, start_cell={cells['input'].id}, kotatsu={kot['complete'].id}")
        return task_id, True

    # =============================================================================================
    # 完成品置き場検索
    # =============================================================================================
    def find_complete_dest(self, plat, seq):
        # リフト間口を検出するまでループ処理
        logger.info(f"[OPS] ➀-2 搬送先検索開始")
        while True:
            t_cells, t_kot, t_pal = self.op_rms.get_carry_data(plat, seq)
            if t_cells["complete"] is not None:
                logger.info(f"[OPS] ➀-2 搬送先検索成功, dest_cell={t_cells['complete'].id}")
                return t_cells["complete"]

    # =============================================================================================
    # 完成品置き場まで搬送
    # =============================================================================================
    def secnd_carry_step(self, cells, kot, pal, task_id):
        """
        回転セルからリフト間口まで搬送する処理
        1、セルとコタツの状態を更新 - DBに情報をUP
        2、搬送のAPI発行
        3、搬送完了待ち
        """
        logger.info("➀-3 完成品,【CELL】trun取出し開始")
        task = None
        # ✅ 1) State update
        # セルとコタツの状態を更新
        if not self.op_rms.update_state(cells["complete"], kot["complete"]):
            logger.error("[OPS] ➀-3 update_state 失敗")
            self.op_rms.insert_error_log(
                error_code="E400010",
                robot_id=None,
                task_id=None
            )
            return None, False, task

        # ✅ 2) Task execution
        res, task_id, start_cell = self.op_rms.send_task(
            step="carry",
            start_cell=cells["turn"],
            dest_cell=cells["complete"],
            kotatsu=kot["complete"],
            pallet=pal["complete"],
            task_number=task_id,
            is_continue=True
        )

        if not res:
            logger.error("[OPS] ➀-3 send_task 失敗")
            return None, False, task

        logger.info(f"[OPS] ➀-3 send_task 成功, task_id={task_id}, dest_cell={cells['turn'].id}")

        # ✅ 3) Wait for completion
        ok, task_id, task = self.op_rms.wait_for_task(
            task_id,
            start_cell,
            dest_cell_id=cells["complete"].id,
            kotatsu_id=kot["complete"].id
        )

        if not ok:
            logger.error("[OPS] ➀-3 wait_for_task 失敗")
            return None, False, task

        # ✅ 5) Clear update
        # セルの占有をクリアする処理
        cells["turn"].clear_occupant()
        # self.op_rms.update_cell(cells["turn"], resrve=False)
        # self.op_rms.update_cell(cells["complete"], resrve=False)
        self.op_rms.clear_state(cells["turn"], cells["complete"], kot["complete"])
        logger.info(f"[OPS] ➀-3 搬送成功-task_id={task_id}, dest_cell={cells['complete'].id}, start_cell={cells['turn'].id}, kotatsu={kot['complete'].id}")
        return task_id, True, task

    # =============================================================================================
    # 空パレットを検索
    # =============================================================================================
    def find_empty_pallet(self, plat_no, seq_no, line_id):
        logger.info("➀-4 空パレット検索開始")
        while True:
            cell, kot, pal = self.op_rms.get_empty_carry_data(plat_no, seq_no, line_id)
            if cell is not None:
                logger.info(f"搬送するコタツ: {kot.id}")
                break
            time.sleep(1)

        return cell, kot, pal

    # =============================================================================================
    # 空パレットを投入間口に搬送
    # =============================================================================================
    def third_carry_step(self, cells, kot, pal, task_id):
        """
        リフト間口から作業者間口まで搬送する処理
        1、セルとコタツの状態を更新 - DBに情報をUP
        2、搬送のAPI発行
        3、搬送完了待ち
        """
        logger.info("➀-5 空パレット,【CELL】INPUT 搬入開始")

        # ✅ 1) State update
        # セルとコタツの状態を更新
        if not self.op_rms.update_state(cells["input"], kot["empty"]):
            logger.error("[OPS] ➀-5 update_state 失敗")
            self.op_rms.insert_error_log(
                error_code="E400010",
                robot_id=None,
                task_id=None
            )
            return None, False

        # ✅ 2) Task execution
        res, task_id, start_cell = self.op_rms.send_task(
            step="empty_carry",
            start_cell=cells["complete"],
            dest_cell=cells["input"],
            kotatsu=kot["empty"],
            pallet=pal["empty"],
            task_number=task_id,
            is_continue=False,
            ratation_cell=cells["turn"]
        )

        if not res:
            logger.error("[OPS] ➀-5 send_task 失敗")
            return None, False

        logger.info(f"[OPS] ➀-5 send_task 成功, task_id={task_id}, dest_cell={cells['input'].id}")

        # ✅ 3) Wait for completion
        ok, task_id, task = self.op_rms.wait_for_task(
            task_id,
            start_cell,
            dest_cell_id=cells["input"].id,
            kotatsu_id=kot["empty"].id
        )

        if not ok:
            logger.error("[OPS] ➀-5 wait_for_task 失敗")
            return None, False

        # ✅ 5) Clear update
        # セルの占有をクリアする処理
        cells["turn"].clear_occupant()
        # self.op_rms.update_cell(cells["turn"], resrve=False)
        # self.op_rms.update_cell(cells["complete"], resrve=False)
        self.op_rms.clear_state(cells["complete"], cells["input"], kot["empty"])
        logger.info(f"[OPS] ➀-5 搬送成功-task_id={task_id}, dest_cell={cells['input'].id}, start_cell={cells['complete'].id}, kotatsu={kot['empty'].id}")
        return task_id, True

    # =============================================================================================
    # Operation開始条件の確認 リクエストの確認と実行の確認
    # =============================================================================================
    def check_start_conditions(self, line_id):
        # logger.info(f"🚀 OperationNiService START line {line_id}")
        return self.op_rms.get_operation(line_id)

    # =============================================================================================
    # Operation開始（順次実行）Sequence、AMR 1台(タスク継続で、AMR1台を拘束)
    # =============================================================================================
    def start_operation(self, line_id: int, plat: int, seq: int):
        logger.info(f"🚀 OperationNiService START line {line_id}")

        # # --------------------------------------------------
        # # STEP 1: Get carry data (cell / kotatsu / pallet)
        # # --------------------------------------------------
        """プラット Seq からセルとコタツを取得する処理"""
        try:
            cells, kot, pal = self.op_rms.get_carry_data(plat, seq)
            logger.debug(cells)
        except Exception:
            logger.exception(
                "[OP][RMS] get_carry_data failed "
                "(line_id=%s, step=complete_carry)",
                line_id
            )

        logger.info(
            """[OP get_carry_data] 作業開始 セル: input=%s, turn=%s コタツ: complete=%s パレット: complete=%s""",
            getattr(cells["input"], "id", None), getattr(cells["turn"], "id", None),
            getattr(kot["complete"], "id", None), getattr(pal["complete"], "id", None),
        )

        # --------------------------------------------------
        # STEP 2: 搬送中の信号をONにする 　
        # --------------------------------------------------
        accrpted_signal_id = self.op_rms.get_signal_id(plat, seq, "ACCEPTED")
        logger.info("✅設定から搬送中 signal_id: %s", accrpted_signal_id)
        self.iot_repo.set_t_output_value(accrpted_signal_id)

        # --------------------------------------------------
        # STEP 3: 回転セルまで搬送 ➀-1
        # --------------------------------------------------
        task, ok1 = self.first_carry_step(cells, kot, pal)
        if not ok1:
            logger.error("[OP2] ➀-1 回転セルまで搬送 first_carry_step: 失敗")
            self.op_rms.error_operation(plat, seq)
            return

        # --------------------------------------------------
        # STEP 4: 完成品置き場検索 ➀-2
        # --------------------------------------------------
        dest_cell = self.find_complete_dest(plat, seq)
        cells["complete"] = dest_cell
 
        # --------------------------------------------------
        # STEP 4: 完成品置き場まで搬送 ➀-3
        # --------------------------------------------------
        task, ok2, task_data= self.secnd_carry_step(cells, kot, pal, task)
        if not ok2:
            logger.error("[OP2] ➀-3 完成品置き場まで搬送 secnd_carry_step: 失敗")
            self.op_rms.error_operation(plat, seq)
            return
        # リフト間口に完成品が搬送された処理
        self.op_rms.set_lift_plat(task_data, cells["complete"], False)

        # --------------------------------------------------
        # STEP 5: 空パレットを検索 ➀-4
        # --------------------------------------------------
        empty_cell, empty_kot, empty_pal = self.find_empty_pallet(plat, seq, line_id)
        kot["empty"] = empty_kot
        pal["empty"] = empty_pal

        # --------------------------------------------------
        # STEP 6: 空パレットを投入間口に搬送 ➀-5
        # --------------------------------------------------
        # リフトプラットをリセットする処理
        self.op_rms.set_lift_plat(task, empty_cell, True)
        task, ok3 = self.third_carry_step(cells, kot, pal, task)
        if not ok3:
            logger.error("[OP2] ➀-5 空パレットを投入間口に搬送 third_carry_step: 失敗")
            self.op_rms.error_operation(plat, seq)
            return

        # --------------------------------------------------
        # STEP 7: 搬送完了作業
        # --------------------------------------------------
        # 搬出処理中信号のOFF
        self.iot_repo.reset_t_output_value(accrpted_signal_id)
        # t_line_stationのセルとコタツの状態を処理する
        self.op_rms.update_line_pallet(plat, seq, pal["empty"].id)
        # パレットの投入時間登録
        self.op_rms.update_pallet_time(pal["empty"].id, "supply_time")
        self.op_rms.update_pallet_time(pal["empty"].id, "input_time")
        # t_line_statusの搬送完了処理
        self.op_rms.operation_update(plat, seq, "COMP")
