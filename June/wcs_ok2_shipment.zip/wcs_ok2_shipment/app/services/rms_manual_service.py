"""
RMS各個操作サービス (RMSManualService)
作成者: Lynn
----------------------------------
ロボット（AMR）や設備に対して、直接的な指示（コマンド）を送信するサービス。

主な役割:
1. 手動指示の実行: 
   - 「移動 (Move)」「棚持ち上げ (Fetch)」「棚降ろし (Load)」「タスク中止 (Cancel)」
     といった具体的なアクションをRMS API経由でロボットに命令します。
2. タスクIDの自動追跡: 
   - コマンド送信前に最新のロボット状態を確認し、現在実行中の `taskId` を
     自動で取得して命令に付加します。これにより、命令の不整合を防ぎます。
3. エラーハンドリングとロギング: 
   - RMSからのレスポンスを厳格にチェックし、応答がない場合やエラー時には
     例外をスローしてログに記録します。

管理者画面の「手動操作パネル」から呼び出される、システムの実行部です。
"""
# app/services/rms_manual_service.py
from app.interfaces.api_client.post_rms_api import PostRmsApi
from app.interfaces.sql.wcs_sql_query import WCSSQLQuery
from app.domain.rms_domain import Map
from typing import List, Dict, Any, Optional
from app.infrastructure.setup_log import setup_log

import app.config.config as cfg
import time

# ログ設定 (名前を付ける)
logger = setup_log(cfg.LOG_FOLDER, cfg.RMS_MANUAL_SEV_LOG_FILE, cfg.BACKUP_DAYS, logger_name="rms_manual_service")

class RMSManualService:
    """RMS 各個操作サービス（Flask非依存）"""

    def __init__(self, ip: str, port: int, db, wcs_sql: WCSSQLQuery, db_name: str = "futaba_ok2_shippment"):
        self.ip = ip
        self.port = port
        self._db = db  # DbFactory（.get_connection(name) を持つ）
        self._db_name = db_name
        self._sql = wcs_sql
        self.map = Map()
        
        # ✅ ADD THIS
        self._last_fetch = None


    # ---------- public commands ----------

    # def move(self, robot_id: str, cell_code: str) -> None:
    #     """単体移動: go_next"""
    #     with PostRmsApi(self.ip, self.port) as rms:
    #         robots = self._get_robots(rms)
            
    #         if not robot_id:
    #                 robot_id = self._find_idle_robot(robots)

    #         if not robot_id:
    #             raise RuntimeError("利用可能なAMRがありません")

    #         task_id = self._find_task_id(robots, robot_id, default=-1)
    #         ans = rms.go_next(cell_code, task_id, False, robot_id, False)
    #         self._ensure_response(ans, f"move: robot_id={robot_id}, cell_code={cell_code}")
    #         logger.info(f"[RMS] move: robot_id={robot_id} -> cell_code={cell_code}")

    def move(self, robot_id: str, cell_code: str) -> None:
        """単体移動: always independent"""

        with PostRmsApi(self.ip, self.port) as rms:
            robots = self._get_robots(rms)

            if not robot_id:
                robot_id = self._find_idle_robot(robots)

            if not robot_id:
                raise RuntimeError("利用可能なAMRがありません")

            # ✅ ALWAYS NEW TASK
            task_id = -1

            ans = rms.go_next(cell_code, task_id, False, robot_id, False)

            self._ensure_response(ans, f"move: robot_id={robot_id}")
            logger.info(f"[RMS] move independent: {robot_id} -> {cell_code}")
            
    # def cancel(self, robot_id: str, cell_code: str) -> None:
    #     """タスクキャンセル: cancel"""
    #     with PostRmsApi(self.ip, self.port) as rms:
    #         robots = self._get_robots(rms)
    #         task_id = self._find_task_id(robots, robot_id, default=None)
    #         ans = rms.cancel(task_id, 3, cell_code)
    #         self._ensure_response(ans, f"cancel: robot_id={robot_id}, cell_code={cell_code}")
    #         logger.info(f"[RMS] cancel: robot_id={robot_id}")

    def cancel(self, robot_id: str, cell_code: str) -> None:
        """タスクキャンセル: cancel"""

        with PostRmsApi(self.ip, self.port) as rms:
            robots = self._get_robots(rms)
            task_id = self._find_task_id(robots, robot_id, default=None)

            if not task_id:
                raise RuntimeError("キャンセル対象タスクがありません")

            ans = rms.cancel(task_id, 3, cell_code)

            self._ensure_response(ans, f"cancel: {robot_id}")

            # ✅ reset chain
            self._last_fetch = None

            logger.info(f"[RMS] cancel independent: {robot_id}")
        
    # def load(self, robot_id: str, shelf_code: str, cell_code: str, angle: int = 0) -> None:
    #     """棚移動: go_return"""
    #     with PostRmsApi(self.ip, self.port) as rms:
    #         robots = self._get_robots(rms)
    #         if not robots:
    #             raise RuntimeError("操作エラー:ロボットがいません")
            
    #         if not robot_id:
    #             robot_id = self._find_idle_robot(robots)

    #         if not robot_id:
    #             raise RuntimeError("利用可能なAMRがありません（全て稼働中）")

    #         task_id = self._find_task_id(robots, robot_id, default=-1)
    #         ans = rms.go_return(cell_code, shelf_code, task_id, angle, False, robot_id)
    #         self._ensure_response(ans, f"load: robot_id={robot_id}, shelf_code={shelf_code}, cell_code={cell_code}")
    #         logger.info(f"[RMS] load: robot_id={robot_id}, shelf_code={shelf_code} -> cell_code={cell_code}")

    def load(self, robot_id: str, shelf_code: str, cell_code: str, angle: int = 0):
        """棚搬送: auto-fetch if needed"""

        with PostRmsApi(self.ip, self.port) as rms:

            robots = self._get_robots(rms)

            # ✅ find robot
            if not robot_id:
                robot_id = self._find_idle_robot(robots)

            if not robot_id:
                raise RuntimeError("利用可能なAMRがありません")

            # ✅ find robot state
            robot_info = next((r for r in robots if str(r.get("robotId")) == str(robot_id)), None)

            if not robot_info:
                raise RuntimeError("ロボット情報取得失敗")

            carrying = robot_info.get("loadedShelfCode") or robot_info.get("loadedShelfId")

            # ✅ ✅ CASE 1: NOT carrying → DO FETCH FIRST
            if not carrying:

                logger.info(f"[AUTO] Robot {robot_id} not carrying → FETCH first")

                # 🔥 fetch FIRST
                fetch_ans = rms.go_fetch(
                    cell_code,
                    shelf_code,
                    -1,
                    angle,
                    False,
                    robot_id
                )

                self._ensure_response(fetch_ans, "auto-fetch")

                task_id = self._extract_task_id(fetch_ans)

                if not task_id:
                    raise RuntimeError("fetch失敗 task_idなし")

                use_continue = True

            else:
                # ✅ already carrying
                task_id = -1
                use_continue = False

            # ✅ ✅ THEN RETURN
            return_ans = rms.go_return(
                cell_code,
                shelf_code,
                task_id,
                angle,
                False,
                robot_id,
                use_continue
            )

            self._ensure_response(return_ans, f"load: {robot_id}")

            logger.info(f"[RMS] load (auto-fixed) robot={robot_id}")
        
    # def fetch(self, robot_id: str, shelf_code: str, cell_code: str, angle: int = 0) -> None:
    #     """棚持ち移動: go_fetch (returns robot_id, task_id)"""
    #     with PostRmsApi(self.ip, self.port) as rms:
    #         robots = self._get_robots(rms)
            
    #         if not robots:
    #             raise RuntimeError("操作エラー:ロボットがいません")
            
    #         if not robot_id:
    #             robot_id = self._find_idle_robot(robots)

    #         if not robot_id:
    #             raise RuntimeError("利用可能なAMRがありません（全て稼働中）")
            
    #         task_id = self._find_task_id(robots, robot_id, default=-1)
    #         ans = rms.go_fetch(cell_code, shelf_code, task_id, angle, False, robot_id)
    #         self._ensure_response(ans, f"fetch: robot_id={robot_id}, shelf_code={shelf_code}, cell_code={cell_code}")
    #         logger.info(f"[RMS] fetch: robot_id={robot_id}, shelf_code={shelf_code} -> cell_code={cell_code}")

    def fetch(self, robot_id: str, shelf_code: str, cell_code: str, angle: int = 0):
        """棚持ち上げ Pick up"""
        with PostRmsApi(self.ip, self.port) as rms:
            robots = self._get_robots(rms)

            if not robot_id:
                robot_id = self._find_idle_robot(robots)

            if not robot_id:
                raise RuntimeError("利用可能なAMRがありません")

            # ✅ ALWAYS NEW TASK
            task_id = -1

            ans = rms.go_fetch(cell_code, shelf_code, task_id, angle, False, robot_id)

            self._ensure_response(ans, f"fetch: {robot_id}")

            new_task_id = self._extract_task_id(ans)

            # ✅ store ONLY for safe chaining
            if new_task_id:
                self._last_fetch = {
                    "robot_id": robot_id,
                    "task_id": new_task_id,
                    "time": time.time()
                }
                logger.info(f"[CHAIN READY] {self._last_fetch}")
            else:
                self._last_fetch = None
              
    def remove_shelf(self, shelf_code: str) -> None:
        """棚削除: remove_shelf"""
        with PostRmsApi(self.ip, self.port) as rms:
            ans = rms.remove_shelf(shelf_code)
            self._ensure_response(ans, f"remove_shelf: shelf_code={shelf_code}")
            logger.info(f"[RMS] remove_shelf: shelf_code={shelf_code}")

    # ---------- helpers ----------

    def _get_robots(self, rms) -> List[Dict[str, Any]]:
        try:
            ans = rms.get_rms_info(5)
            if ans is None:
                return []
            return ans.get("response", {}).get("body", {}).get("robots", []) or []
        except Exception as e:
            logger.error(f"Error fetching robots from RMS API: {e}")
            return []

    def _find_task_id(self, robots: List[Dict[str, Any]], robot_id: str, default: Optional[int]) -> Optional[int]:
        for r in robots:
            rid = r.get("robotId")
            if str(rid) == str(robot_id):
                return r.get("taskId", default)
        return default

    def _ensure_response(self, ans: Optional[Dict[str, Any]], context: str) -> None:
        if ans is None:
            logger.error(f"RMSが応答しませんでした: {context}")
            raise RuntimeError("RMSが応答しませんでした")
    
    
    def _find_idle_robot(self, robots):
        for r in robots:
            
            logger.info(f"""
                Robot {r.get('robotId')}
                taskId={r.get('taskId')}
                status={r.get('robotStatus')}
                """)

            task_id = r.get("taskId", None)
            status = r.get("robotStatus")

            if (task_id is None or task_id == -1) and status == "NORMAL":
                return r.get("robotId")

        return None
    
    def _extract_task_id(self, ans: Optional[Dict[str, Any]]) -> Optional[int]:
        try:
            return (
                ans.get("response", {})
                .get("body", {})
                .get("taskId")
            )
        except Exception:
            return None

