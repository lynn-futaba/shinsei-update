#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Simple MySQL connection checker for WCS, EIP, and IOTDS DBs.

- Uses hardcoded config values below (no env vars needed).
- Prints concise status and latency per DB.
- Exit code: 0 if all DBs OK, 1 if any DB fails.

Usage examples:
  python db_connection_check.py
  python db_connection_check.py --json
  python db_connection_check.py --host-wcs 127.0.0.1 --user-wcs root --db-wcs futaba-okazaki_2
"""

import sys
import time
import json
import argparse
from dataclasses import dataclass
from typing import Optional

try:
    import mysql.connector
except Exception:
    mysql = None  # graceful handling if connector is missing


# --------- Hardcoded Config (edit as you need) ---------
DEFAULT_WCS = {
    "host": "192.168.3.10",  # 192.168.3.10 10.102.12.81
    "port": 3306,
    "user": "athena",
    "password": "WGQKJPL8V/xQ",
    "database": "futaba_ok2_shippment",
}
DEFAULT_EIP = {
    "host": "192.168.3.10",  # 192.168.3.10
    "port": 3306,
    "user": "athena",
    "password": "WGQKJPL8V/xQ",
    "database": "eip_signal",
}
DEFAULT_IOTDS = {
    "host": "192.168.3.10",  # 192.168.3.10
    "port": 3306,
    "user": "athena",
    "password": "WGQKJPL8V/xQ",
    "database": "futaba_ok2_iot",
}
# -------------------------------------------------------


@dataclass
class DbConfig:
    host: str
    port: int
    user: str
    password: str
    database: str


@dataclass
class DbResult:
    ok: bool
    ms: int
    error: Optional[str] = None


def ping_mysql(cfg: DbConfig) -> DbResult:
    """
    Try connecting to MySQL and executing SELECT 1.
    Returns DbResult with ok flag, latency in ms, and optional error.
    """
    if mysql is None:
        return DbResult(ok=False, ms=0, error="mysql-connector-python not installed")

    start = time.perf_counter()
    conn = None
    cur = None
    try:
        conn = mysql.connector.connect(
            host=cfg.host,
            port=cfg.port,
            user=cfg.user,
            password=cfg.password,
            database=cfg.database,
            connection_timeout=5,
        )
        cur = conn.cursor()
        cur.execute("SELECT 1")
        _ = cur.fetchone()
        ms = int((time.perf_counter() - start) * 1000)
        return DbResult(ok=True, ms=ms)
    except Exception as ex:
        ms = int((time.perf_counter() - start) * 1000)
        return DbResult(ok=False, ms=ms, error=str(ex))
    finally:
        try:
            cur and cur.close()
        except Exception:
            pass
        try:
            conn and conn.close()
        except Exception:
            pass


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="MySQL connection checker for WCS/EIP/IOTDS.")

    p.add_argument("--json", action="store_true", help="Output JSON instead of human-readable text.")

    # Optional overrides for WCS
    p.add_argument("--host-wcs", type=str, help="WCS host")
    p.add_argument("--port-wcs", type=int, help="WCS port")
    p.add_argument("--user-wcs", type=str, help="WCS user")
    p.add_argument("--pass-wcs", type=str, help="WCS password")
    p.add_argument("--db-wcs", type=str, help="WCS database name")

    # Optional overrides for EIP
    p.add_argument("--host-eip", type=str, help="EIP host")
    p.add_argument("--port-eip", type=int, help="EIP port")
    p.add_argument("--user-eip", type=str, help="EIP user")
    p.add_argument("--pass-eip", type=str, help="EIP password")
    p.add_argument("--db-eip", type=str, help="EIP database name")

    # Optional overrides for IOTDS
    p.add_argument("--host-iotds", type=str, help="IOTDS host")
    p.add_argument("--port-iotds", type=int, help="IOTDS port")
    p.add_argument("--user-iotds", type=str, help="IOTDS user")
    p.add_argument("--pass-iotds", type=str, help="IOTDS password")
    p.add_argument("--db-iotds", type=str, help="IOTDS database name")

    return p.parse_args()


def main() -> int:
    args = parse_args()

    # Build configs (allow CLI overrides without modifying this file)
    wcs_cfg = DbConfig(
        host=args.host_wcs or DEFAULT_WCS["host"],
        port=args.port_wcs or DEFAULT_WCS["port"],
        user=args.user_wcs or DEFAULT_WCS["user"],
        password=args.pass_wcs or DEFAULT_WCS["password"],
        database=args.db_wcs or DEFAULT_WCS["database"],
    )
    eip_cfg = DbConfig(
        host=args.host_eip or DEFAULT_EIP["host"],
        port=args.port_eip or DEFAULT_EIP["port"],
        user=args.user_eip or DEFAULT_EIP["user"],
        password=args.pass_eip or DEFAULT_EIP["password"],
        database=args.db_eip or DEFAULT_EIP["database"],
    )
    iotds_cfg = DbConfig(
        host=args.host_iotds or DEFAULT_IOTDS["host"],
        port=args.port_iotds or DEFAULT_IOTDS["port"],
        user=args.user_iotds or DEFAULT_IOTDS["user"],
        password=args.pass_iotds or DEFAULT_IOTDS["password"],
        database=args.db_iotds or DEFAULT_IOTDS["database"],
    )

    # Run checks
    wcs_res = ping_mysql(wcs_cfg)
    eip_res = ping_mysql(eip_cfg)
    iotds_res = ping_mysql(iotds_cfg)

    overall_ok = (wcs_res.ok and eip_res.ok and iotds_res.ok)

    if args.json:
        out = {
            "ok": overall_ok,
            "wcs": {
                "ok": wcs_res.ok,
                "ms": wcs_res.ms,
                **({"error": wcs_res.error} if wcs_res.error else {}),
                "host": wcs_cfg.host,
                "port": wcs_cfg.port,
                "db": wcs_cfg.database,
            },
            "eip": {
                "ok": eip_res.ok,
                "ms": eip_res.ms,
                **({"error": eip_res.error} if eip_res.error else {}),
                "host": eip_cfg.host,
                "port": eip_cfg.port,
                "db": eip_cfg.database,
            },
            "iotds": {
                "ok": iotds_res.ok,
                "ms": iotds_res.ms,
                **({"error": iotds_res.error} if iotds_res.error else {}),
                "host": iotds_cfg.host,
                "port": iotds_cfg.port,
                "db": iotds_cfg.database,
            }
        }
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print(f"=== DB Connection Check ===")
        print(f"[WCS]   host={wcs_cfg.host}:{wcs_cfg.port} db={wcs_cfg.database}")
        if wcs_res.ok:
            print(f"  -> OK (ms={wcs_res.ms})")
        else:
            print(f"  -> NG (ms={wcs_res.ms}) error={wcs_res.error}")

        print(f"[EIP]   host={eip_cfg.host}:{eip_cfg.port} db={eip_cfg.database}")
        if eip_res.ok:
            print(f"  -> OK (ms={eip_res.ms})")
        else:
            print(f"  -> NG (ms={eip_res.ms}) error={eip_res.error}")

        print(f"[IOTDS] host={iotds_cfg.host}:{iotds_cfg.port} db={iotds_cfg.database}")
        if iotds_res.ok:
            print(f"  -> OK (ms={iotds_res.ms})")
        else:
            print(f"  -> NG (ms={iotds_res.ms}) error={iotds_res.error}")

        print(f"Overall: {'OK' if overall_ok else 'NG'}")

    return 0 if overall_ok else 1


if __name__ == "__main__":
    sys.exit(main())