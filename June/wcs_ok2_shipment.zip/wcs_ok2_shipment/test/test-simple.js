// --- Allowed lists taken from your service (kept in sync with backend) ---
const ALLOWED_PHASES = [
    "GO_FETCHING","SHELF_FETCHED","GO_DELIVERING","QUEUING","SHELF_ARRIVED","GO_RETURN","SHELF_TURNING",
    "MOVING","CHARGING","ARRIVED_RECEIVE","ARRIVED_DROP","ARRIVED_WAIT_POINT","LEAVING_WAIT_POINT",
    "RECEIVE_FINISH","DROP_FINISH","BOX_FETCHED","BOX_ARRIVED","ARRIVED_ELEVATOR_ENTRY","ENTERED_ELEVATOR",
    "LEAVED_ELEVATOR","ARRIVED","FETCHED"
  ];
  
  const ALLOWED_TASK_TYPES = [
    "GO_SOMEWHERE_TO_STAY","DELIVER_SHELF_TO_STATION","DELIVER_SHELF","DELIVER_NEW_SHELF",
    "GO_WORK","CARRY_PACKAGE","DELIVER_PALLET","DELIVER_BOX","GO_WORK_ORDER_TO_PERSON",
    "MOVE_SHELF","GO_MAINTAIN_TO_STAY","GO_CHARGE_YOURSELF","GO_CIRCLE","GO_TO_INSPECTION"
  ];
  
  const ALLOWED_INSTRUCTIONS = [
    "NONE","GO_FETCH","GO_TURN","GO_RETURN","CANCEL","CANCEL_INSTRUCTION","GO_NEXT","PRIORITY_SET",
    "CLEAR_WAITPOINT","GO_RECEIVE","GO_DROP","ALLOW_ENTER_ELEVATOR","ALLOW_LEAVE_ELEVATOR",
    "UPDATE_PARCEL","UPDATE_BOX","FINISHED"
  ];
  
  // --- Helper to fill a <select> with options ---
  function fillSelect(selectEl, options, { includeEmpty = true, emptyLabel = "(empty)" } = {}) {
    selectEl.innerHTML = "";
    if (includeEmpty) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = emptyLabel;
      selectEl.appendChild(opt);
    }
    for (const v of options) {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      selectEl.appendChild(opt);
    }
  }
  
  function buildSamplePayload() {
    const requestId = document.getElementById('requestId').value.trim() || "req-001";
    const taskId    = document.getElementById('taskId').value.trim()    || "task-123";
    const robotId   = document.getElementById('robotId').value.trim()   || "RBT-01";
  
    const taskPhase = document.getElementById('taskPhase').value.trim();
    const destCell  = document.getElementById('destCell').value.trim();
    const taskType  = document.getElementById('taskType').value.trim();
    const instr     = document.getElementById('instruction').value.trim();
  
    // Default to EXECUTING if user hasn't clicked quick status yet
    const taskStatus = (window.__currentStatus || "EXECUTING").toUpperCase();
  
    return {
      "msgType": "RobotTaskCallbackMsg",
      "request": {
        "header": {
          "requestId": requestId
        },
        "body": {
          "taskId": taskId,
          "robotId": robotId,
          "taskStatus": taskStatus,
          ...(taskPhase ? { "taskPhase": taskPhase } : {}),
          ...(destCell ? { "destCellCode": destCell } : {}),
          ...(taskType ? { "taskType": taskType } : {}),
          ...(instr ? { "instruction": instr } : {})
        }
      }
    };
  }
  
  function setPayloadTextArea(obj) {
    const text = JSON.stringify(obj, null, 2);
    document.getElementById('payload').value = text;
  }
  
  function getEndpoint() {
    return document.getElementById('endpoint').value.trim();
  }
  
  function showResponse(objOrText) {
    const pre = document.getElementById('response');
    if (typeof objOrText === 'string') {
      pre.textContent = objOrText;
    } else {
      pre.textContent = JSON.stringify(objOrText, null, 2);
    }
  }
  
  function parsePayload() {
    const raw = document.getElementById('payload').value;
    try {
      return JSON.parse(raw);
    } catch (e) {
      alert("Invalid JSON in payload textarea.\n\n" + e.message);
      throw e;
    }
  }
  
  // --- Wire up controls on load ---
  window.addEventListener('DOMContentLoaded', () => {
    // Fill dropdowns
    fillSelect(document.getElementById('taskPhase'), ALLOWED_PHASES, { includeEmpty: true, emptyLabel: "(none)" });
    fillSelect(document.getElementById('taskType'), ALLOWED_TASK_TYPES, { includeEmpty: true, emptyLabel: "(none)" });
    fillSelect(document.getElementById('instruction'), ALLOWED_INSTRUCTIONS, { includeEmpty: true, emptyLabel: "(none)" });
  
    // Set some sensible defaults
    document.getElementById('taskPhase').value = "MOVING";
    document.getElementById('taskType').value = "DELIVER_SHELF";
    document.getElementById('instruction').value = "GO_NEXT";
  
    // initialize payload textarea with sample
    setPayloadTextArea(buildSamplePayload());
  
    // quick status buttons
    document.querySelectorAll('.status-btns button').forEach(btn => {
      btn.addEventListener('click', () => {
        window.__currentStatus = btn.dataset.status;
        // refresh payload to reflect new status
        setPayloadTextArea(buildSamplePayload());
      });
    });
  
    // update payload when dropdowns change
    ['taskPhase','taskType','instruction','requestId','taskId','robotId','destCell'].forEach(id => {
      document.getElementById(id).addEventListener('change', () => {
        setPayloadTextArea(buildSamplePayload());
      });
      document.getElementById(id).addEventListener('input', () => {
        setPayloadTextArea(buildSamplePayload());
      });
    });
  
    // prettify
    document.getElementById('prettifyBtn').addEventListener('click', () => {
      const obj = parsePayload();
      setPayloadTextArea(obj);
    });
  
    // reset sample
    document.getElementById('resetBtn').addEventListener('click', () => {
      window.__currentStatus = "EXECUTING";
      document.getElementById('requestId').value = "req-001";
      document.getElementById('taskId').value = "task-123";
      document.getElementById('robotId').value = "RBT-01";
      document.getElementById('destCell').value = "A1-01";
      document.getElementById('taskPhase').value = "MOVING";
      document.getElementById('taskType').value = "DELIVER_SHELF";
      document.getElementById('instruction').value = "GO_NEXT";
      setPayloadTextArea(buildSamplePayload());
      showResponse("(waiting...)");
    });
  
    // send POST
    document.getElementById('sendBtn').addEventListener('click', async () => {
      const endpoint = getEndpoint();
      let payload;
      try {
        payload = parsePayload();
      } catch (_) {
        return;
      }
  
      showResponse("Sending...");
  
      try {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
  
        const text = await res.text();
        // Try to parse JSON, otherwise show raw
        try {
          const json = JSON.parse(text);
          showResponse({ status: res.status, ok: res.ok, json });
        } catch {
          showResponse({ status: res.status, ok: res.ok, text });
        }
      } catch (err) {
        showResponse("Network/Fetch error: " + (err && err.message ? err.message : String(err)));
      }
    });
  });

//   Sample Request Payload 
//   {
//     "msgType": "RobotTaskCallbackMsg",
//     "request": {
//       "header": { "requestId": "req-001" },
//       "body": {
//         "taskId": "task-123",
//         "robotId": "RBT-01",
//         "taskStatus": "EXECUTING",
//         "taskPhase": "MOVING",
//         "destCellCode": "A1-01",
//         "taskType": "DELIVER_SHELF",
//         "instruction": "GO_NEXT"
//       }
//     }
//   }

//   Sample Response Payload 
// {
//     "id": "geekCode_geekWarehouseCode_001",
//     "msgType": "RobotTaskCallbackMsg",
//     "request": {
//       "header": {
//         "responseId": "req-001",
//         "code": "ca5ebc4251374e35a5f6afb2a52fd6dd",
//         "msg": "3.3.0"
//       },
//       "body": {}
//     }
//   }
  