
UPDATE t_pallet_status
SET
  status = 'EMPTY',
  input_time = NULL,
  completion_time = NULL
WHERE pallet_id = 6;

--------------------------
Step A — FORCE signal OFF
--------------------------

UPDATE t_output
SET value = 0
WHERE signal_id = 1300;

--------------------------
Step B — Wait one IoTDS cycle
--------------------------

--------------------------
Step C — Turn OUTPUT ON
--------------------------
UPDATE t_output
SET value = 1
WHERE signal_id = 1300;

--------------------------
Step A — FORCE signal OFF
--------------------------
UPDATE t_input
SET value = 0
WHERE signal_id = 1300;

--------------------------
Step B — Wait one IoTDS cycle
--------------------------

--------------------------
Step C — Turn INPUT ON
--------------------------
UPDATE t_input
SET value = 1
WHERE signal_id = 1300;