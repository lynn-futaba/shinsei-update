// --- Allowed lists taken from your service (kept in sync with backend) ---
const ALLOWED_PHASES = [
    "GO_FETCHING","SHELF_FETCHED","GO_DELIVERING","QUEUING","SHELF_ARRIVED","GO_RETURN","SHELF_TURNING",
    "MOVING","CHARGING","ARRIVED_RECEIVE","ARRIVED_DROP","ARRIVED_WAIT_POINT","LEAVING_WAIT_POINT",
    "RECEIVE_FINISH","DROP_FINISH","BOX_FETCHED","BOX_ARRIVED","ARRIVED_ELEVATOR_ENTRY","ENTERED_ELEVATOR",
    "LEAVED_ELEVATOR","ARRIVED","FETCHED"
  ];
  
  const ALLOWED_TASK_TYPES = [
    "GO_SOMEWHERE_TO_STAY","DELIVER_SHELF_TO_STATION","DELIVER_SHELF","DELIVER_NEW_SHELF",
    "GO_WORK","CARRY_PACKAGE","DELIVER_PALLET","DELIVER_BOX","GO_WORK_ORDER_TO_PERSON",
    "MOVE_SHELF","GO_MAINTAIN_TO_STAY","GO_CHARGE_YOURSELF","GO_CIRCLE","GO_TO_INSPECTION"
  ];
  
  const ALLOWED_INSTRUCTIONS = [
    "NONE","GO_FETCH","GO_TURN","GO_RETURN","CANCEL","CANCEL_INSTRUCTION","GO_NEXT","PRIORITY_SET",
    "CLEAR_WAITPOINT","GO_RECEIVE","GO_DROP","ALLOW_ENTER_ELEVATOR","ALLOW_LEAVE_ELEVATOR",
    "UPDATE_PARCEL","UPDATE_BOX","FINISHED"
  ];
  
  // --- Helper to fill a <select> with options ---
  function fillSelect(selectEl, options, { includeEmpty = true, emptyLabel = "(none)" } = {}) {
    selectEl.innerHTML = "";
    if (includeEmpty) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = emptyLabel;
      selectEl.appendChild(opt);
    }
    for (const v of options) {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      selectEl.appendChild(opt);
    }
  }
  
  function buildSamplePayload() {
    const requestId = document.getElementById('requestId').value.trim() || "req-001";
    const taskId    = document.getElementById('taskId').value.trim()    || "task-123";
    const robotId   = document.getElementById('robotId').value.trim()   || "RBT-01";
  
    const taskPhase = document.getElementById('taskPhase').value.trim();
    const destCell  = document.getElementById('destCell').value.trim();
    const taskType  = document.getElementById('taskType').value.trim();
    const instr     = document.getElementById('instruction').value.trim();
  
    // Default to EXECUTING if user hasn't clicked quick status yet
    const taskStatus = (window.__currentStatus || "EXECUTING").toUpperCase();
  
    return {
      "msgType": "RobotTaskCallbackMsg",
      "request": {
        "header": {
          "requestId": requestId
        },
        "body": {
          "taskId": taskId,
          "robotId": robotId,
          "taskStatus": taskStatus,
          ...(taskPhase ? { "taskPhase": taskPhase } : {}),
          ...(destCell ? { "destCellCode": destCell } : {}),
          ...(taskType ? { "taskType": taskType } : {}),
          ...(instr ? { "instruction": instr } : {})
        }
      }
    };
  }
  
  function setPayloadTextArea(obj) {
    const text = JSON.stringify(obj, null, 2);
    document.getElementById('payload').value = text;
  }
  
  function getEndpoint() {
    return document.getElementById('endpoint').value.trim();
  }
  
  function showResponse(objOrText) {
    const pre = document.getElementById('response');
    if (typeof objOrText === 'string') {
      pre.textContent = objOrText;
    } else {
      pre.textContent = JSON.stringify(objOrText, null, 2);
    }
  }
  
  function parsePayload() {
    const raw = document.getElementById('payload').value;
    try {
      return JSON.parse(raw);
    } catch (e) {
      alert("Invalid JSON in payload textarea.\n\n" + e.message);
      throw e;
    }
  }
  
  // --- Simple logger for Simulator ---
  function simLog(line) {
    const el = document.getElementById('simLog');
    const time = new Date().toLocaleTimeString();
    el.textContent += `[${time}] ${line}\n`;
    el.scrollTop = el.scrollHeight;
  }
  
  function setSimState(state) {
    const badge = document.getElementById('simState');
    badge.textContent = state;
    badge.style.background = state === 'running' ? '#e7fff1' : '#eef';
    badge.style.borderColor = state === 'running' ? '#9adfb6' : '#ccd';
  }
  
  // --- Send helper (used by both manual send and simulator) ---
  async function sendPayload(payload) {
    const endpoint = getEndpoint();
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const text = await res.text();
    try {
      const json = JSON.parse(text);
      return { status: res.status, ok: res.ok, json };
    } catch {
      return { status: res.status, ok: res.ok, text };
    }
  }
  
  // --- Lifecycle Simulator ---
  let simAbort = false;
  function stopSimulator() { simAbort = true; }
  
  function getDelayMs() {
    const raw = document.getElementById('simDelay').value.trim();
    const ms = parseInt(raw, 10);
    return Number.isFinite(ms) && ms >= 0 ? ms : 1500;
  }
  
  // Choose a phase that roughly matches the status
  function phaseForStatus(status) {
    switch (status) {
      case 'NEW': return 'GO_FETCHING';
      case 'ASSIGNED': return 'GO_DELIVERING';
      case 'EXECUTING': return 'MOVING';
      case 'COMPLETED': return 'ARRIVED';
      case 'CANCELED': return 'ARRIVED_WAIT_POINT';
      default: return '';
    }
  }
  
  // Choose a reasonable instruction for each step (optional)
  function instructionForStatus(status) {
    switch (status) {
      case 'NEW': return 'NONE';
      case 'ASSIGNED': return 'GO_NEXT';
      case 'EXECUTING': return 'GO_TURN';
      case 'COMPLETED': return 'FINISHED';
      case 'CANCELED': return 'CANCEL';
      default: return '';
    }
  }
  
  async function runLifecycle() {
    // lock UI
    document.getElementById('simStartBtn').disabled = true;
    document.getElementById('simStopBtn').disabled = false;
    setSimState('running');
    simAbort = false;
    simLog('Lifecycle started');
  
    // Fixed fields
    const taskId = document.getElementById('taskId').value.trim() || 'task-123';
    const robotId = document.getElementById('robotId').value.trim() || 'RBT-01';
    const destCell = document.getElementById('destCell').value.trim();
    const taskType = document.getElementById('taskType').value.trim() || 'DELIVER_SHELF';
  
    // Sequence
    const sequence = ['NEW', 'ASSIGNED', 'EXECUTING', 'COMPLETED'];
    const delay = getDelayMs();
  
    for (let i = 0; i < sequence.length; i++) {
      if (simAbort) { simLog('Lifecycle aborted by user'); break; }
  
      const status = sequence[i];
      const phase = phaseForStatus(status);
      const instr = instructionForStatus(status);
      const requestId = `req-sim-${Date.now()}-${i}`;
  
      // Build step payload
      const payload = {
        msgType: 'RobotTaskCallbackMsg',
        request: {
          header: { requestId },
          body: {
            taskId,
            robotId,
            taskStatus: status,
            ...(phase ? { taskPhase: phase } : {}),
            ...(destCell ? { destCellCode: destCell } : {}),
            ...(taskType ? { taskType } : {}),
            ...(instr ? { instruction: instr } : {})
          }
        }
      };
  
      // show in editor and send
      setPayloadTextArea(payload);
      simLog(`Sending status=${status} phase=${phase || '(none)'} instruction=${instr || '(none)'} requestId=${requestId}`);
      showResponse('Sending (simulator)...');
      try {
        const result = await sendPayload(payload);
        showResponse(result);
        simLog(`→ Response ${result.status} ${result.ok ? 'OK' : 'ERR'}`);
      } catch (e) {
        simLog(`→ Fetch error: ${e && e.message ? e.message : String(e)}`);
        break; // stop on hard errors
      }
  
      if (i < sequence.length - 1) {
        await new Promise(r => setTimeout(r, delay));
      }
    }
  
    // unlock UI
    document.getElementById('simStartBtn').disabled = false;
    document.getElementById('simStopBtn').disabled = true;
    setSimState('stopped');
    if (!simAbort) simLog('Lifecycle finished');
  }
  
  // --- Wire up controls on load ---
  window.addEventListener('DOMContentLoaded', () => {
    // Fill dropdowns
    fillSelect(document.getElementById('taskPhase'), ALLOWED_PHASES, { includeEmpty: true, emptyLabel: "(none)" });
    fillSelect(document.getElementById('taskType'), ALLOWED_TASK_TYPES, { includeEmpty: true, emptyLabel: "(none)" });
    fillSelect(document.getElementById('instruction'), ALLOWED_INSTRUCTIONS, { includeEmpty: true, emptyLabel: "(none)" });
  
    // Set defaults
    document.getElementById('taskPhase').value = "MOVING";
    document.getElementById('taskType').value = "DELIVER_SHELF";
    document.getElementById('instruction').value = "GO_NEXT";
  
    // initialize payload textarea with sample
    setPayloadTextArea(buildSamplePayload());
  
    // quick status buttons
    document.querySelectorAll('.status-btns button').forEach(btn => {
      btn.addEventListener('click', () => {
        window.__currentStatus = btn.dataset.status;
        setPayloadTextArea(buildSamplePayload());
      });
    });
  
    // update payload when fields change
    ['taskPhase','taskType','instruction','requestId','taskId','robotId','destCell'].forEach(id => {
      const el = document.getElementById(id);
      el.addEventListener('change', () => setPayloadTextArea(buildSamplePayload()));
      el.addEventListener('input', () => setPayloadTextArea(buildSamplePayload()));
    });
  
    // prettify
    document.getElementById('prettifyBtn').addEventListener('click', () => {
      const obj = parsePayload();
      setPayloadTextArea(obj);
    });
  
    // reset sample
    document.getElementById('resetBtn').addEventListener('click', () => {
      window.__currentStatus = "EXECUTING";
      document.getElementById('requestId').value = "req-001";
      document.getElementById('taskId').value = "task-123";
      document.getElementById('robotId').value = "RBT-01";
      document.getElementById('destCell').value = "A1-01";
      document.getElementById('taskPhase').value = "MOVING";
      document.getElementById('taskType').value = "DELIVER_SHELF";
      document.getElementById('instruction').value = "GO_NEXT";
      setPayloadTextArea(buildSamplePayload());
      showResponse("(waiting...)");
      simLog('Reset form & payload');
    });
  
    // manual send
    document.getElementById('sendBtn').addEventListener('click', async () => {
      let payload;
      try { payload = parsePayload(); } catch (_) { return; }
      showResponse("Sending...");
      try {
        const result = await sendPayload(payload);
        showResponse(result);
      } catch (err) {
        showResponse("Network/Fetch error: " + (err && err.message ? err.message : String(err)));
      }
    });
  
    // simulator controls
    document.getElementById('simStartBtn').addEventListener('click', runLifecycle);
    document.getElementById('simStopBtn').addEventListener('click', () => {
      stopSimulator();
      document.getElementById('simStopBtn').disabled = true;
      simLog('Stop requested');
    });
  });