
=========================================================================================================================
➀　Docker compose オフラインインストール
=========================================================================================================================

🔹 Step 1: Download on a machine WITH internet
curl -L https://github.com/docker/compose/releases/download/v2.27.0/docker-compose-linux-x86_64 -o docker-compose

🔹 Step 2: Transfer to server and Install on server
mkdir -p /usr/local/lib/docker/cli-plugins/

copy ⇒ docker-compose to /usr/local/lib/docker/cli-plugins/ using WinSCP File Transfer Protocol

chmod +x /usr/local/lib/docker/cli-plugins/docker-compose

🔹 Step 3:Create symlink
ln -s /usr/local/lib/docker/cli-plugins/docker-compose /usr/bin/docker-compose

🔹 Step 4: Verify
docker compose version

Docker Compose version v2.27.0

=========================================================================================================================
②　Create Service in Systemd
=========================================================================================================================

touch /etc/systemd/system/wcs-ok2-shipment.service

[Unit]
Description=WCS Docker Compose App
Requires=docker.service
After=docker.service

[Service]
# Working directory where docker-compose.yml exists
WorkingDirectory=/usr/local/tmcpython/wcs_ok2_shipment

# Start Docker Compose in detached mode
ExecStart=/usr/bin/docker compose up -d

# Stop all containers defined in docker-compose
ExecStop=/usr/bin/docker compose down

# Always restart the service if it crashes
Restart=always
# RestartSec=5

# Give enough time for container start/stop
TimeoutStartSec=120
TimeoutStopSec=120

[Install]
WantedBy=multi-user.target
=========================================================================================================================

# 1. Reload systemd to detect new service
sudo systemctl daemon-reload

# 2. Enable service to start on boot
sudo systemctl enable wcs-ok2-shipment

Output: Created symlink /etc/systemd/system/multi-user.target.wants/wcs-ok2-shipment.service → /etc/systemd/system wcs-ok2-shipment.service.

# 3. Start service now
sudo systemctl start wcs-ok2-shipment

# 4. Check status
sudo systemctl status wcs-ok2-shipment
sudo systemctl stop wcs-ok2-shipment
sudo systemctl restart wcs-ok2-shipment
=========================================================================================================================

