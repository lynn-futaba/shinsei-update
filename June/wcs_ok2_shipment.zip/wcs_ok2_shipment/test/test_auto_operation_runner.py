import time
import threading
import pytest

# RunControll
from run_controll import RunControll


# ============================================================
# ✅ Fake Repo  (DB substitute)
# ============================================================
class FakeRepo:
    """偽のDBリポジトリ (ライン状態・システム状態のみ提供)"""

    def get_system_status(self):
        # mode=1, preparation_ok=1, auto_running=1 → 自動運転 ON
        return [{
            "mode": 1,
            "preparation_ok": 1,
            "auto_running": 1
        }]

    def get_line_status(self):
        # 2ライン分、運転許可あり
        return [
            {"line_id": 1, "transport_permission": 1},
            {"line_id": 2, "transport_permission": 1},
        ]


# ============================================================
# ✅ Fake RMS API
# ============================================================
class FakeRMSApi:
    """偽のRMS API。搬送タスクは実行せず即成功返す"""

    def get_operation(self, line_id):
        return True

    def get_carry_data(self, line_id, mode):
        # OperationService が必要とする dict 形式を返す
        return (
            {
                "input": {"id": "input"},
                "temp": {"id": "temp"},
                "wait": {"id": "wait"},
                "complete": {"id": "complete"},
                "lift": {"id": "lift"},
            },
            {
                "complete": {"id": "kt_complete"},
                "wait": {"id": "kt_wait"},
                "empty": {"id": "kt_empty"},
            },
            {
                "complete": {"id": "pl_complete"},
                "wait": {"id": "pl_wait"},
                "empty": {"id": "pl_empty"},
            }
        )

    def update(self, *a):
        return True

    def clear_update(self, *a):
        return True

    def complete_carry(self, *args, **kwargs):
        # (result, task_id, task_info)
        return True, 999, {"mock_task": True}

    def operation_update(self, *a):
        return True

    def set_lift_plat(self, *a):
        return True


# ============================================================
# ✅ Fake OperationService
# (We override start_operation to verify execution)
# ============================================================
class FakeOperationService:
    """OperationService の start_operation が呼ばれたかチェックする"""

    def __init__(self, line_id, repo, rms_api):
        self.line_id = line_id
        self.repo = repo
        self.rms_api = rms_api
        self.called = False

    def start_operation(self):
        """スレッド内で呼び出されるテスト用メソッド"""
        self.called = True


# ============================================================
# ✅ Factories
# ============================================================
def fake_rms_api_factory():
    return FakeRMSApi()


def fake_operation_service_factory(line_id, repo, rms_api):
    return FakeOperationService(line_id, repo, rms_api)


# ============================================================
# ✅ Test 1:
# RunControll should start 1 thread per line
# ============================================================
def test_runner_starts_threads_per_line():
    repo = FakeRepo()
    runner = RunControll(
        repo=repo,
        rms_api_factory=fake_rms_api_factory,
        service_factory=fake_operation_service_factory,
    )

    runner.run_cycle()  # execute once

    # 2 threads should be created
    assert len(runner._manager.threads) == 2

    # All threads must be alive
    assert all(t.is_alive() for t in runner._manager.threads.values())


# ============================================================
# ✅ Test 2:
# Running cycle twice should NOT create duplicate threads
# ============================================================
def test_runner_does_not_duplicate_threads():
    repo = FakeRepo()
    runner = RunControll(
        repo=repo,
        rms_api_factory=fake_rms_api_factory,
        service_factory=fake_operation_service_factory,
    )

    runner.run_cycle()

    initial_threads = runner._manager.threads.copy()

    # run again → should not create new threads
    runner.run_cycle()

    assert runner._manager.threads == initial_threads


# ============================================================
# ✅ Test 3:
# OperationService.start_operation must be executed inside each thread
# ============================================================
def test_operation_service_is_called():
    repo = FakeRepo()

    # Capture service objects so we can inspect `.called`
    service_objects = {}

    def factory(line_id, repo, api):
        svc = FakeOperationService(line_id, repo, api)
        service_objects[line_id] = svc
        return svc

    runner = RunControll(
        repo=repo,
        rms_api_factory=fake_rms_api_factory,
        service_factory=factory,
    )

    runner.run_cycle()

    # Wait for threads to execute
    time.sleep(0.1)

    # Both services should have been started
    assert service_objects[1].called is True
    assert service_objects[2].called is True


# ============================================================
# ✅ Test 4:
# Ensure thread per line is unique
# ============================================================
def test_thread_manager_unique_per_line():
    repo = FakeRepo()
    runner = RunControll(
        repo=repo,
        rms_api_factory=fake_rms_api_factory,
        service_factory=fake_operation_service_factory,
    )

    runner.run_cycle()

    threads = runner._manager.threads

    # Keys should be line_id values
    assert set(threads.keys()) == {1, 2}

    # Values must be thread objects
    assert all(isinstance(t, threading.Thread) for t in threads.values())