// static/js/map.js (flat AMR, large hit area, full-shape clicks; exports renderSVG only)
(function (global, $) {
  'use strict';

  const svgNS = "http://www.w3.org/2000/svg";

  // === tweakable constants ===
  const AMR_RADIUS     = 14;  // AMR visible size
  const AMR_HIT_RADIUS = 22;  // AMR hit area (transparent overlay)
  const ARROW_SIZE     = 6;   // AMR triangle half-width
  const ARROW_OFFSET   = 5;   // triangle distance from circle edge
  const LABEL_OFFSET   = 14;  // label gap above robot

  // Default control IDs (Bootstrap buttons + range)
  const DEFAULT_CONTROLS = { in: 'zoom-in', out: 'zoom-out', reset: 'zoom-reset', range: 'zoom-range' };
  const DEFAULT_IDS = { mapElId: 'map', canvasElId: 'map-canvas', viewportElId: 'map-viewport' };

  // ---------- helpers ----------
  function createElNS(name, attrs = {}, text = null) {
    const el = document.createElementNS(svgNS, name);
    for (const [k, v] of Object.entries(attrs)) {
      if (v !== undefined && v !== null) el.setAttribute(k, String(v));
    }
    if (text != null) el.textContent = String(text);
    return el;
  }

  function buildPolylinePoints(points) {
    if (!points) return '';
    if (typeof points === 'string') return points;
    if (Array.isArray(points)) {
      return points.map(p => `${p.x},${p.y}`).join(' ');
    }
    return '';
  }

  // Emit selection events consumed by admin.js (wireMapSelectionToInputs)
  function emitSelection(mapEl, kind, payload) {
    try {
      // Kind-specific + generic
      mapEl.dispatchEvent(new CustomEvent(`map:${kind}Selected`, { detail: payload, bubbles: true }));
      mapEl.dispatchEvent(new CustomEvent('map:selected',        { detail: { kind, ...payload }, bubbles: true }));
    } catch (e) {
      console.warn('[map.js] emitSelection failed', e);
    }
  }

  // ---------- pan & zoom (applies to #map-canvas) ----------
  function attachZoomPan({ viewportEl, canvasEl, controls }) {
    let scale = 1, tx = 0, ty = 0;

    // If there is a stored transform on canvas data-attrs, restore it
    const ds = canvasEl.dataset || {};
    if (ds.mapScale) scale = Number(ds.mapScale) || 1;
    if (ds.mapTx)    tx    = Number(ds.mapTx)    || 0;
    if (ds.mapTy)    ty    = Number(ds.mapTy)    || 0;

    const r = controls.range ? document.getElementById(controls.range) : null;
    const MIN = r ? Number(r.min || 0.5) : 0.5;
    const MAX = r ? Number(r.max || 3.0) : 3.0;
    const STEP = r ? Number(r.step || 0.1) : 0.1;

    const apply = () => {
      canvasEl.style.transform = `translate(${tx}px, ${ty}px) scale(${scale})`;
      if (r) r.value = String(scale);
      // Persist on dataset so re-renders can restore
      canvasEl.dataset.mapScale = String(scale);
      canvasEl.dataset.mapTx = String(tx);
      canvasEl.dataset.mapTy = String(ty);
    };

    const setScale = (next, cx, cy) => {
      const prev = scale;
      const nextClamped = Math.max(MIN, Math.min(MAX, next));
      if (nextClamped === prev) return;
      scale = nextClamped;

      const rect = viewportEl.getBoundingClientRect();
      const X = cx ?? rect.left + rect.width / 2;
      const Y = cy ?? rect.top  + rect.height / 2;

      const preX = (X - rect.left - tx) / prev;
      const preY = (Y - rect.top  - ty) / prev;
      tx = (X - rect.left) - preX * scale;
      ty = (Y - rect.top ) - preY * scale;
      apply();
    };

    document.getElementById(controls.in)?.addEventListener('click', () => setScale(scale + STEP));
    document.getElementById(controls.out)?.addEventListener('click', () => setScale(scale - STEP));
    document.getElementById(controls.reset)?.addEventListener('click', () => { scale = 1; tx = 0; ty = 0; apply(); });
    r?.addEventListener('input', () => setScale(Number(r.value)));

    let dragging = false, sx = 0, sy = 0, stx = 0, sty = 0;
    const down = (e) => {
      dragging = true; canvasEl.classList.add('dragging');
      const p = ('touches' in e) ? e.touches[0] : e;
      sx = p.clientX; sy = p.clientY; stx = tx; sty = ty;
      e.preventDefault();
    };
    const move = (e) => {
      if (!dragging) return;
      const p = ('touches' in e) ? e.touches[0] : e;
      tx = stx + (p.clientX - sx);
      ty = sty + (p.clientY - sy);
      apply();
    };
    const up = () => { dragging = false; canvasEl.classList.remove('dragging'); };

    // Pan is bound to the viewport to avoid catching controls
    viewportEl.addEventListener('mousedown', down);
    viewportEl.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    viewportEl.addEventListener('touchstart', down, { passive: false });
    viewportEl.addEventListener('touchmove', move,   { passive: false });
    window.addEventListener('touchend', up);

    // Initial apply
    apply();

    return {
      apply,
      getTransform: () => ({ scale, tx, ty }),
      setTransform: (s, x, y) => { scale = s; tx = x; ty = y; apply(); }
    };
  }

  // One-time guard
  function ensureZoomPanOnce() {
    try {
      const viewportEl = document.getElementById(DEFAULT_IDS.viewportElId);
      const canvasEl   = document.getElementById(DEFAULT_IDS.canvasElId);
      if (!viewportEl || !canvasEl) return;

      // If we've already initialized zoom/pan, skip
      if (canvasEl.dataset.zoomPanInit === '1') return;

      attachZoomPan({ viewportEl, canvasEl, controls: DEFAULT_CONTROLS });
      canvasEl.dataset.zoomPanInit = '1';
    } catch (e) {
      console.warn('[map.js] ensureZoomPanOnce failed', e);
    }
  }

  // ---------- core render ----------
  function renderSVG(mapEl, rawRoot) {
    if (!mapEl) return;

    // unwrap safely
    const root = rawRoot?.data ?? rawRoot ?? {};

    // Accept both root.size and root.siza for compatibility
    const sizeArr = root.size || root.siza || [1200, 800];
    const W = Number(sizeArr[0]) || 1200;
    const H = Number(sizeArr[1]) || 800;

    // Build SVG
    const svg = createElNS('svg', { width: W, height: H, style: 'background-color:#ffffff' });

    // --- CELLS (full-shape clickable) ---
    (root.cells || []).forEach(item => {
      const x = +item.location_x || 0;
      const y = +item.location_y || 0;
      const w = +item.width || 10;
      const h = +item.height || 10;
      const code = item.cellCode || item.cell_code || '';

      // group for cell
      const g = createElNS('g', {});
      g.style.cursor = 'pointer';

      // colored rect
      const rect = createElNS('rect', { x, y, width: w, height: h, fill: item.color || '#b7c3d0' });
      rect.classList.add('cell-element');

      // FULL clickable overlay (transparent)
      const overlay = createElNS('rect', {
        x, y, width: w, height: h,
        fill: 'rgba(0,0,0,0)', stroke: 'none'
      });
      overlay.style.pointerEvents = 'all';

      // label
      const text = createElNS('text', {
        x: x + w / 2,
        y: y + h / 1.5,
        fill: 'black',
        'font-size': '10px',
        'text-anchor': 'middle',
        'dominant-baseline': 'hanging'
      }, code || 'Cell');
      text.classList.add('cell-element');

      const onClick = () => emitSelection(mapEl, 'cell', { code, cellCode: code });
      g.addEventListener('click', onClick);
      overlay.addEventListener('click', onClick);
      rect.addEventListener('click', onClick);
      text.addEventListener('click', onClick);

      g.appendChild(rect);
      g.appendChild(overlay);
      g.appendChild(text);
      svg.appendChild(g);
    });

    // --- SHELVES / KOTATSUS (full-shape clickable) ---
    (root.kotatsus || []).forEach(item => {
      const x = +item.location_x || 0;
      const y = +item.location_y || 0;
      const w = +item.width || 10;
      const h = +item.height || 10;
      const angle = +item.angle || 0;
      const id = item.id ?? '';
      const shelfCode = item.shelfCode || id || '';

      const g = createElNS('g', {});
      g.style.cursor = 'pointer';

      // visible shape (stroke only)
      const shelf = createElNS('rect', {
        x, y, width: w, height: h,
        fill: 'none',
        stroke: item.color || '#333',
        'stroke-width': 2
      });
      if (angle !== 0) {
        const cx = x + w / 2;
        const cy = y + h / 2;
        shelf.setAttribute('transform', `rotate(${angle}, ${cx}, ${cy})`);
      }
      shelf.classList.add('shelf-element');

      // FULL clickable overlay (transparent)
      const overlay = createElNS('rect', {
        x, y, width: w, height: h,
        fill: 'rgba(0,0,0,0)', stroke: 'none'
      });
      overlay.style.pointerEvents = 'all';

      // label
      const text = createElNS('text', {
        x: x + w / 2,
        y: y + h / 4,
        fill: 'blue',
        'font-size': '10px',
        'text-anchor': 'middle',
        'dominant-baseline': 'middle'
      }, shelfCode || 'Shelf');
      text.classList.add('shelf-element');

      const onClick = () => emitSelection(mapEl, 'shelf', { shelfCode, id });
      g.addEventListener('click', onClick);
      overlay.addEventListener('click', onClick);
      shelf.addEventListener('click', onClick);
      text.addEventListener('click', onClick);

      g.appendChild(shelf);
      g.appendChild(overlay);
      g.appendChild(text);
      svg.appendChild(g);
    });

    // --- AMRs (flat, bigger, full-hit circle) ---
    (root.amrs || []).forEach(item => {
      const x = +item.location_x || 0;
      const y = +item.location_y || 0;

      const g = createElNS('g', { class: 'amr-node' });
      g.style.cursor = 'pointer';

      // transparent HIT circle (large area)
      const hit = createElNS('circle', {
        cx: x, cy: y, r: AMR_HIT_RADIUS,
        fill: 'rgba(0,0,0,0)', stroke: 'none'
      });
      hit.style.pointerEvents = 'all';

      // visible body (flat color)
      const body = createElNS('circle', {
        cx: x, cy: y, r: AMR_RADIUS,
        fill: '#4a90e2', stroke: '#1f1f1f', 'stroke-width': 2
      });
      body.classList.add('robot-element');

      // direction triangle (front)
      const tipY = y - AMR_RADIUS - ARROW_OFFSET;
      const arrow = createElNS('polygon', {
        points: `${x},${tipY} ${x - ARROW_SIZE},${tipY + ARROW_SIZE} ${x + ARROW_SIZE},${tipY + ARROW_SIZE}`,
        fill: '#ffffff', stroke: '#ffffff', 'stroke-width': 1
      });
      arrow.classList.add('robot-arrow');

      // label above
      const label = createElNS('text', {
        x, y: y - (AMR_RADIUS + LABEL_OFFSET),
        fill: '#111',
        'font-size': '12px',
        'font-weight': '700',
        'text-anchor': 'middle',
        'dominant-baseline': 'baseline'
      }, item.robotId || '');
      label.classList.add('robot-element');

      const onClick = () => emitSelection(mapEl, 'amr', { id: item.id ?? '', robotId: item.robotId || '' });

      // Attach to whole group + all parts (robust)
      g.addEventListener('click', onClick);
      hit.addEventListener('click', onClick);
      body.addEventListener('click', onClick);
      arrow.addEventListener('click', onClick);
      label.addEventListener('click', onClick);

      g.appendChild(hit);
      g.appendChild(body);
      g.appendChild(arrow);
      g.appendChild(label);
      svg.appendChild(g);

      // Optional: path polyline under/around robot
      const pts = buildPolylinePoints(item.path);
      if (pts) {
        const polyline = createElNS('polyline', {
          points: pts, stroke: 'blue', fill: 'none', 'stroke-width': 1.5
        });
        polyline.classList.add('path-element', 'robot-element');
        svg.appendChild(polyline);
      }
    });

    // Replace contents and ensure zoom/pan is initialized
    mapEl.innerHTML = '';
    mapEl.appendChild(svg);

    // one-time zoom/pan setup (applies to #map-canvas transform)
    ensureZoomPanOnce();
  }

  // ---------- export only the renderer ----------
  // Expose renderSVG for admin.js to call on 'map:payload'
  global.renderSVG = renderSVG;

})(window, jQuery);