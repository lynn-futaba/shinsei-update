"""
ドメインエンティティ定義 (Domain Entities)
作成者: Lynn
----------------------------------
システム全体で使用される共通のデータ構造（エンティティ）を定義するファイル。

主な役割:
1. 型定義: 各データ（AMR、パレット、タスク等）の属性を明確に定義。
2. バリデーション: __post_init__ メソッドにより、不正なデータ（空文字、型違い等）
   がシステム内部に侵入するのを防ぎます。
3. ビジネスルールのカプセル化: データの操作メソッド（例: PalletScheduleLine.add_pair）
   をエンティティ自身に持たせることで、ロジックの散らばりを防ぎます。

このファイルにあるクラスが、システムにおける「正しいデータの形」を保証します。
"""
# app/domain/entities.py
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List

class DomainValidationError(Exception):
    pass

@dataclass
class Amr:
    """
    AMR エンティティ
    - amr_id: ID (主キー)
    - request_id: リクエストID (None可: 未割当)
    - kotatsu_id: 積載コタツ (None可: 未積載)
    - current_cell_code: 現在セルコード (None可: 未確定/屋外)
    - status: 稼働状態 (例: '待機', '実行', '異常', '充電', など)
    """
    amr_id: str
    status: str
    request_id: Optional[str] = None
    kotatsu_id: Optional[str] = None
    current_cell_code: Optional[str] = None

    def __post_init__(self) -> None:
        if not isinstance(self.amr_id, str) or not self.amr_id.strip():
            raise DomainValidationError("amr_id is required and must be non-empty str")
        if not isinstance(self.status, str) or not self.status.strip():
            raise DomainValidationError("status is required and must be non-empty str")
        if self.request_id is not None and not isinstance(self.request_id, str):
            raise DomainValidationError("request_id must be str or None")
        if self.kotatsu_id is not None and not isinstance(self.kotatsu_id, str):
            raise DomainValidationError("kotatsu_id must be str or None")
        if self.current_cell_code is not None and not isinstance(self.current_cell_code, str):
            raise DomainValidationError("current_cell_code must be str or None")
        
@dataclass
class AssemblyLine:
    """
    組立ライン
    - line_code: ラインコード (主キー)
    - pallet_type: パレット種類（例: '330インナー' など）
    - product_item: 生産品目（例: '5581894100' など）
    """
    line_code: str
    pallet_type: str
    product_item: str

    def __post_init__(self) -> None:
        if not isinstance(self.line_code, str) or not self.line_code.strip():
            raise DomainValidationError("line_code is required and must be non-empty str")
        if not isinstance(self.pallet_type, str) or not self.pallet_type.strip():
            raise DomainValidationError("pallet_type is required and must be non-empty str")
        if not isinstance(self.product_item, str) or not self.product_item.strip():
            raise DomainValidationError("product_item is required and must be non-empty str")
    
@dataclass
class Kotatsu:
    """
    Kotatsu
    - kotatsu_id: コタツID (主キー)
    - pallet_id: パレットID (未積載なら None)
    - cell_code: セルコード (未配置/未確定なら None)
    """
    kotatsu_id: str
    pallet_id: Optional[str] = None
    cell_code: Optional[str] = None

    def __post_init__(self) -> None:
        if not isinstance(self.kotatsu_id, str) or not self.kotatsu_id.strip():
            raise DomainValidationError("kotatsu_id is required and must be non-empty str")
        if self.pallet_id is not None and not isinstance(self.pallet_id, str):
            raise DomainValidationError("pallet_id must be str or None")
        if self.cell_code is not None and not isinstance(self.cell_code, str):
            raise DomainValidationError("cell_code must be str or None")

@dataclass
class Liftman:
    """
    リフトマン
    - cell_code: セルコード (主キー)
    - selected_pallet: 選択パレット（パレットID 等）
    """
    cell_code: str
    selected_pallet: str

    def __post_init__(self) -> None:
        if not isinstance(self.cell_code, str) or not self.cell_code.strip():
            raise DomainValidationError("cell_code is required and must be non-empty str")
        if not isinstance(self.selected_pallet, str) or not self.selected_pallet.strip():
            raise DomainValidationError("selected_pallet is required and must be non-empty str")
        
@dataclass
class LogisticsInstruction:
    """
    物流指示
    - line_code: ラインコード (主キー)
    - pallet_variation: パレットバリエーション
    """
    line_code: str
    pallet_variation: str

    def __post_init__(self) -> None:
        if not isinstance(self.line_code, str) or not self.line_code.strip():
            raise DomainValidationError("line_code is required and must be non-empty str")
        if not isinstance(self.pallet_variation, str) or not self.pallet_variation.strip():
            raise DomainValidationError("pallet_variation is required and must be non-empty str")
        
@dataclass
class Maguchi:
    """
    間口アクセス設定
    - line_id: ラインID（例: 1）
    - line_name: ライン名（例: 'T66'）
    - name: 間口（例:'間口1'）
    - transport_permission: 搬送許可（True/False）
    - pallet_name: パレット名（LH 300アウター(T64)）
    """
    line_id: int
    line_name: str
    name: str
    transport_permission: bool
    pallet_name: str
    
    def __post_init__(self) -> None:
        if not isinstance(self.line_id, int) or self.line_id < 0:
            raise DomainValidationError("line_id must be int (>=0)")
        if not isinstance(self.line_name, str) or not self.line_name.strip():
            raise DomainValidationError("line_name is required and must be non-empty str")
        if not isinstance(self.name, str) or not self.name.strip():
            raise DomainValidationError("name is required and must be non-empty str")
        if not isinstance(self.transport_permission, bool):
            raise DomainValidationError("transport_permission must be bool")
        if not isinstance(self.pallet_name, str) or not self.pallet_name.strip():
            raise DomainValidationError("pallet_name is required and must be non-empty str")
        
@dataclass
class Pallet:
    """
    パレット
    - pallet_id: パレットID (主キー)
    - pallet_type: パレット種類（例: '330インナー'）
    - pallet_variation: パレットバリエーション（例: 'A', 'B'）
    - status: ステータス（例: 'EMPTY', 'FILL', 'DONE' など）
    - location_cell_code: 位置(セルコード)
    - start_time: 投入時間 (None可)
    - completion_time: 完成時間 (None可)
    """
    pallet_id: str
    pallet_type: str
    pallet_variation: str
    status: str
    location_cell_code: Optional[str] = None
    start_time: Optional[datetime] = None
    completion_time: Optional[datetime] = None

    def __post_init__(self) -> None:
        if not isinstance(self.pallet_id, str) or not self.pallet_id.strip():
            raise DomainValidationError("pallet_id is required and must be non-empty str")
        if not isinstance(self.pallet_type, str) or not self.pallet_type.strip():
            raise DomainValidationError("pallet_type is required and must be non-empty str")
        if not isinstance(self.pallet_variation, str) or not self.pallet_variation.strip():
            raise DomainValidationError("pallet_variation is required and must be non-empty str")
        if not isinstance(self.status, str) or not self.status.strip():
            raise DomainValidationError("status is required and must be non-empty str")

        if self.location_cell_code is not None and not isinstance(self.location_cell_code, str):
            raise DomainValidationError("location_cell_code must be str or None")
        if self.start_time is not None and not isinstance(self.start_time, datetime):
            raise DomainValidationError("start_time must be datetime or None")
        if self.completion_time is not None and not isinstance(self.completion_time, datetime):
            raise DomainValidationError("completion_time must be datetime or None")

@dataclass
class TransportTask:
    """
    搬送タスク状態 (t_task_status)
    - task_id: タスクID
    - status: ステータス (EXECUTING, COMPLETED, etc.)
    - phase: フェーズ (SHELF_FETCHED, etc.)
    - robot_id: ロボットID
    - dest_cell: 行先セル
    - task_type: タスク種別
    - instruction: 指示 (READY, GO_RETURN, etc.)
    - updated_date: 更新日時
    """
    task_id: int
    status: str
    phase: str
    robot_id: int
    dest_cell: int
    task_type: str
    instruction: str
    updated_date: str

    def __post_init__(self) -> None:
        if not isinstance(self.task_id, int):
            raise DomainValidationError("task_id must be int")
        # 必要に応じてバリデーションを追加

@dataclass
class Worker:
    """
    作業者アサイン
    - worker_id: 作業者 (主キー1)
    - worker_pallet_id: 作業パレット (主キー2)
    - line_code: ラインコード
    """
    worker_id: str
    worker_pallet_id: str
    line_code: str

    def __post_init__(self) -> None:
        if not isinstance(self.worker_id, str) or not self.worker_id.strip():
            raise DomainValidationError("worker_id is required and must be non-empty str")
        if not isinstance(self.worker_pallet_id, str) or not self.worker_pallet_id.strip():
            raise DomainValidationError("worker_pallet_id is required and must be non-empty str")
        if not isinstance(self.line_code, str) or not self.line_code.strip():
            raise DomainValidationError("line_code is required and must be non-empty str")
        
@dataclass
class ErrorLog:
    """
    t_error_log
    """
    error_num: int
    error_code: str
    task_id: int
    robot_id: int
    rms_error_code: int  # store BIT as int for now
    error_datetime: datetime
    is_completed: bool

@dataclass
class ErrorMaster:
    """
    m_error
    """
    error_code: str
    error_category: str
    error_summary: str
    error_operation: str
    error_description: str
    rms_error_code: int  # store BIT as int for now
    error_level: str

@dataclass
class ErrorListItem:
    """
    View model for the 'エラー表示' table row + modal details (joined from log + master)
    """
    error_num: str
    error_code: str
    error_category: str
    error_summary: str
    error_operation: str
    error_description: str
    error_level: str
    rms_error_code: Optional[int]  # could be None; m_error.rms_error_code may be null
    task_id: Optional[int]  # nullable
    robot_id: Optional[int]
    error_datetime: datetime
    is_completed: bool

@dataclass
class LiftEntrance:
    """
    リフト間口操作画面 / 管理画面 共通エンティティ
    """
    maguchi_name: str
    line_name: str
    pallet_name: str
    transport_status: str
    # --- Optional fields for Worker Repo functionality ---
    # These default to None so Manage Repo doesn't break
    seq_no: Optional[int] = None
    plat_no: Optional[int] = None
    rev: Optional[int] = None

    def __post_init__(self) -> None:
        # Manage Repo logic only requires maguchi_name
        if not self.maguchi_name:
            raise DomainValidationError("maguchi_name is required")
        
        # Validation only runs if the values are actually provided
        if self.seq_no is not None and not isinstance(self.seq_no, int):
            raise DomainValidationError("seq_no must be int")
        if self.rev is not None and not isinstance(self.rev, int):
            raise DomainValidationError("rev must be int")
            
@dataclass(frozen=True)
class PalletPair:
    """
    供給パレット1件（型式ID + 表示名 + 供給数）
    - writes are type-centric (pallet_type int); pallet_name is display-only from m_pallet join
    """
    count: int
    pallet_type: Optional[int] = None
    pallet_name: Optional[str] = None  # display/use only; may be None if type is NULL or unknown

    def __post_init__(self) -> None:
        # count
        if not isinstance(self.count, int):
            raise DomainValidationError("count must be int")
        if self.count < 0:
            raise DomainValidationError("count must be >= 0")

        # pallet_type
        if self.pallet_type is not None:
            if not isinstance(self.pallet_type, int):
                raise DomainValidationError("pallet_type must be an integer or None")
            if self.pallet_type < 0:
                raise DomainValidationError("pallet_type must be >= 0")

        # pallet_name (optional)
        if self.pallet_name is not None and not isinstance(self.pallet_name, str):
            raise DomainValidationError("pallet_name must be a string or None")

@dataclass
class PalletScheduleLine:
    line_name: str
    rev: int
    line_id: Optional[int] = None
    pairs: List[PalletPair] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not isinstance(self.line_name, str) or not self.line_name.strip():
            raise DomainValidationError("line_name is required and must be non-empty str")
        if not isinstance(self.rev, int) or self.rev < 0:
            raise DomainValidationError("rev must be int >= 0")
        if self.line_id is not None and not isinstance(self.line_id, int):
            raise DomainValidationError("line_id must be an integer")
        for p in self.pairs:
            if not isinstance(p, PalletPair):
                raise DomainValidationError("pairs must contain PalletPair objects")

    # domain ops
    def add_pair(self, pair: PalletPair, before_index: Optional[int]) -> None:
        if before_index is None or before_index < 0 or before_index > len(self.pairs):
            self.pairs.append(pair)
        else:
            self.pairs.insert(before_index, pair)

    def update_pair(self, pair_index: int, pair: PalletPair) -> None:
        if pair_index < 0 or pair_index >= len(self.pairs):
            raise IndexError("pair_index out of range")
        self.pairs[pair_index] = pair

    def delete_pair(self, pair_index: int) -> None:
        if pair_index < 0 or pair_index >= len(self.pairs):
            raise IndexError("pair_index out of range")
        self.pairs.pop(pair_index)

    def move_to_group0(self, pair_index: int) -> None:
        if pair_index < 0 or pair_index >= len(self.pairs):
            raise IndexError("pair_index out of range")
        item = self.pairs.pop(pair_index)
        self.pairs.insert(0, item)

@dataclass
class RMSCurrentMode:
    """
    RMS 現在モード
    - mode: True=自動, False=各個
    - preparation_ok: 運転準備 (True=完了)
    - auto_running: 自動運転 (True=運転中)
    """
    system_id: str
    system_name: str
    mode: bool
    preparation_ok: bool
    auto_running: bool

    def __post_init__(self) -> None:
        if not isinstance(self.system_id, str) or not self.system_id.strip():
            raise DomainValidationError("system_id is required and must be non-empty str")
        if not isinstance(self.system_name, str) or not self.system_name.strip():
            raise DomainValidationError("system_name is required and must be non-empty str")
        if not isinstance(self.mode, bool):
            raise DomainValidationError("mode must be bool")
        if not isinstance(self.preparation_ok, bool):
            raise DomainValidationError("preparation_ok must be bool")
        if not isinstance(self.auto_running, bool):
            raise DomainValidationError("auto_running must be bool")




      