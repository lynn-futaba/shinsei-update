/* app/static/js/pallet-supply.js */

(function ($) {
  'use strict';

  console.log('[pallet-supply] boot');

  // ===== API CONFIG =====
  const API_BASE = '/worker/api/v1/pallet_supply';

  async function parseApi(res) {
    let js = null;
    try { js = await res.json(); } catch (e) {}
    const status = res.status;
    const message = (js && typeof js === 'object' && typeof js.message === 'string')
      ? js.message : (res.statusText || 'Request failed');

    if (!res.ok || (js && js.error)) {
      const err = new Error(message);
      err.status = status;
      throw err;
    }
    return js;
  }

  async function apiList() {
    const res = await fetch(API_BASE, { headers: { 'Accept': 'application/json' } });
    const js = await parseApi(res);
    return { lines: js.data.lines, max_pairs: Number(js.data.max_pairs) || 10 };
  }

  async function apiMasterPallets() {
    const res = await fetch('/worker/api/v1/master/pallets', { headers: { 'Accept': 'application/json' } });
    const js = await parseApi(res);
    return js.data.pallets; 
  }

  async function apiUpdate(lineName, pairIndex, palletType, count, rev) {
    const res = await fetch(`${API_BASE}/${encodeURIComponent(lineName)}/pair/${Number(pairIndex)}`, {
      method : 'PUT',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body   : JSON.stringify({ pallet_type: Number(palletType), count: Number(count), rev: Number(rev) })
    });
    const js = await parseApi(res);
    return js.data.line;
  }

  // ===== UI Elements =====
  const $tbody = $('#line-state-body');
  const $thead = $('#line-table thead');
  const $btnEdit = $('#btn-edit');
  const editAddModalEl = document.getElementById('editAddModal');
  const editAddModal = editAddModalEl ? bootstrap.Modal.getOrCreateInstance(editAddModalEl) : null;
  const $palletList = $('#palletList');
  const $supplyInput = $('#supplyInput');
  const $modalSaveBtn = $('#modalSaveBtn');

  // ===== State =====
  const RESET_SELECTION = () => ({ $row: null, lineName: '', pairIndex: -1, palletText: '' });
  let selection = RESET_SELECTION();
  let maxPairsCache = 10;

  // ===== Rendering =====
  function renderLineRow(line, maxPairs) {
    const tr = document.createElement('tr');
    tr.dataset.rev = line.rev ?? 0;

    const th = document.createElement('th');
    th.className = 'text-center sticky-left bg-white fw-bold';
    th.textContent = line.line_name;
    tr.appendChild(th);

    const pairs = line.pairs || [];
    for (let i = 0; i < maxPairs; i++) {
      const p = pairs[i] || {};
      const tdP = document.createElement('td');
      tdP.colSpan = 6; tdP.className = 'text-center pallet-name-cell';
      tdP.textContent = p.pallet_name || ''; 
      
      const tdC = document.createElement('td');
      tdC.colSpan = 4; tdC.className = 'text-center count-cell';
      tdC.textContent = (p.pallet_name) ? p.count : '';
      
      tr.appendChild(tdP); tr.appendChild(tdC);
    }
    return tr;
  }

  async function loadAndRender() {
    const { lines, max_pairs } = await apiList();
    maxPairsCache = max_pairs;

    // Render Header Titles
    $thead.empty();
    const trHead = document.createElement('tr');
    const thLine = document.createElement('th');
    thLine.textContent = 'ライン名';
    thLine.className = 'sticky-left bg-light';
    trHead.appendChild(thLine);

    for (let i = 0; i < maxPairsCache; i++) {
      const thP = document.createElement('th');
      thP.colSpan = 6; thP.className = 'text-center'; thP.textContent = `供給パレット ${i+1}`;
      const thC = document.createElement('th');
      thC.colSpan = 4; thC.className = 'text-center'; thC.textContent = '数';
      trHead.appendChild(thP); trHead.appendChild(thC);
    }
    $thead.append(trHead);

    $tbody.empty();
    lines.forEach(l => $tbody.append(renderLineRow(l, maxPairsCache)));
  }

  // ===== Events =====
  $tbody.on('click', 'td', function () {
    const $td = $(this);
    const $tr = $td.closest('tr');
    const abs = this.cellIndex;
    if (abs <= 0) return;

    $tbody.find('td').removeClass('bg-info text-white');
    const baseRel = abs - 1;
    const startIdx = (baseRel % 2 === 0) ? baseRel : baseRel - 1;
    const $cells = $tr.children('td');
    
    selection = {
      $row: $tr,
      lineName: $tr.find('th').text(),
      pairIndex: Math.floor(startIdx / 2),
      $palletCell: $cells.eq(startIdx).addClass('bg-info text-white'),
      $countCell: $cells.eq(startIdx + 1).addClass('bg-info text-white'),
      palletText: $cells.eq(startIdx).text().trim()
    };
  });

  $('.keypad').on('click', function() {
    const val = $(this).text();
    const curr = $supplyInput.val();
    if (val === 'C') $supplyInput.val('');
    else $supplyInput.val(curr === '0' ? val : curr + val);
  });

  $btnEdit.on('click', async () => {
    if (!selection.$row) { alert('セルを選択してください。'); return; }
    const pallets = await apiMasterPallets();
    $palletList.empty();
    pallets.forEach(p => {
      const active = (p.pallet_name === selection.palletText) ? ' active' : '';
      $palletList.append(`<button type="button" class="list-group-item list-group-item-action${active}" data-type="${p.pallet_type}">${p.pallet_name}</button>`);
    });
    $supplyInput.val(selection.$countCell.text() || '10');
    editAddModal?.show();
  });

  $palletList.on('click', '.list-group-item', function() {
    $palletList.find('.list-group-item').removeClass('active');
    $(this).addClass('active');
  });

  $modalSaveBtn.on('click', async function () {
    const $active = $palletList.find('.list-group-item.active');
    if (!$active.length) return alert('パレットを選択してください。');
    try {
      const line = await apiUpdate(selection.lineName, selection.pairIndex, $active.data('type'), $supplyInput.val(), selection.$row.data('rev'));
      selection.$row.replaceWith(renderLineRow(line, maxPairsCache));
      editAddModal?.hide();
      selection = RESET_SELECTION();
    } catch (err) { alert(err.message); }
  });

  $(() => loadAndRender());
})(jQuery);