# # app/controllers/ops_controller.py
# from flask import Blueprint, jsonify
# import time

# def create_ops_blueprint(container):
#     bp = Blueprint("ops", __name__)

#     @bp.get("/healthz")
#     def healthz():
#         # Liveness only: process is up
#         return jsonify({"status": "ok", "ts": int(time.time())}), 200

#     @bp.get("/readyz")
#     def readyz():
#         # Readiness: cheap dependency checks with small timeouts
#         try:
#             wcs = container.wcs
#             # Only attempt a trivial call if not FAKE
#             if not getattr(wcs, "fake", False):
#                 # prefer a fast ping() if you have one, else a trivial query
#                 if hasattr(wcs, "ping"):
#                     wcs.ping()
#                 else:
#                     with wcs.cursor_ctx() as cur:
#                         cur.execute("SELECT 1")
#                         cur.fetchone()
#             return jsonify({"status": "ready"}), 200
#         except Exception as ex:
#             return jsonify({"status": "degraded", "error": str(ex)}), 503

#     return bp