    # app/controllers/test_controller.py
from __future__ import annotations
from flask import Blueprint, jsonify, render_template, request

# Pull in the standard API format helpers
from app.domain.api_response_format import (
    success, bad_request, not_found, invalid, internal_error
)

from app.infrastructure.setup_log import setup_log
import app.config.config as cfg

# ログ設定 (名前を付ける)
logger = setup_log(cfg.LOG_FOLDER, cfg.TEST_CTRL_LOG_FILE, cfg.BACKUP_DAYS, logger_name="test_ctrl")

def create_test_blueprint(container):
    bp = Blueprint("test_controller", __name__)
    
    # Pull services from container
    # manage_service = container.manage_service
    rms_monitoring_service = container.rms_monitoring_service
    # rms_manual_service = container.rms_manual_service
    # rms_callback_service = container.rms_callback_service
    
    @bp.get("/call_back")
    def rms_call_back():
        # Home/test dashboard (HTML)
        return render_template("test.html", title="Testing")
    
    # ---------------------------------------
    # HTML page: PostRMS API Tester
    # ---------------------------------------
    @bp.get("/post_rms")
    def post_rms():
        """
        Renders a simple page to test posting to RMS through server-side proxy.
        """
        return render_template("test-post-rms.html", title="RMS POST Tester")

    # ---------------------------------------
    # API: Proxy - Query by instruction_id (GET or POST)
    #   - Uses PostRmsApi.get_rms_info(instruction_id)
    # ---------------------------------------
    @bp.post("/api/v1/rms/query")
    def rms_query_instruction():
        """
        JSON body: { "instruction_id": 0-11 }
        Returns raw vendor JSON (if ok) in standard envelope.
        """
        payload = request.get_json(silent=True) or {}
        instruction_id = payload.get("instruction_id", None)
        if instruction_id is None:
            return bad_request("instruction_id is required (0..11)")
        try:
            instruction_id = int(instruction_id)
        except Exception:
            return invalid("instruction_id must be an integer")

        try:
            # Use the same RMS config as monitoring service
            ip = getattr(rms_monitoring_service, "ip", None)
            port = getattr(rms_monitoring_service, "port", None)
            if not ip:
                return internal_error(details="RMS IP not configured")
            from app.interfaces.api_client.post_rms_api import PostRmsApi
            with PostRmsApi(ip, port) as rms:
                data = rms.get_rms_info(instruction_id)
            if data is None:
                return internal_error(details="RMS returned no data (network/vendor error)")
            return success(data=data)
        except Exception as ex:
            logger.exception("rms_query_instruction failed")
            return internal_error(details=str(ex))

    
    @bp.route("/iotds/run-once", methods=["POST"])
    def run_iotds_once():
        result = container.iotds_service.detect_and_update()
        return jsonify(result)
        
    return bp