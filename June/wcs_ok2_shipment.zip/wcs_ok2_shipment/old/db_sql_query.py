import mysql.connector

class DBSQLQuery:
    def __init__(self, host, user, password, database):
        self.connection = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        self.cursor = self.connection.cursor()

    # クエリを実行するための共通メソッド

    def close_connection(self):
        self.cursor.close()
        self.connection.close()

    # ここに必要なSQLクエリを追加していきます
    def m_location(self):
        query = "SELECT * FROM m_location"
        return query


