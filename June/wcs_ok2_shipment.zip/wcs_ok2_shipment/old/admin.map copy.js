/**
 * RMS マップモニタリング・フロントエンド (admin.map.js)
 * 作成者: Lynn
 * ----------------------------------
 * 工場内のレイアウト、ロボット（AMR）、および棚（コタツ）を可視化するUI制御スクリプト。
 * * 主な役割:
 * 1. リアルタイム・レンダリング:
 * - 3秒ごとに `/rms_map_monitor` APIから最新座標を取得し、SVGを動的に再生成します。
 * 2. インタラクティブな操作性:
 * - マウスホイールによるズーム、ドラッグによるマップの移動（パン）を実装し、
 * 広大な工場敷地内の特定のエリアを詳細に確認できます。
 * 3. ロボット・パスの可視化:
 * - ロボットが現在計画している移動経路をアニメーション付きの点線（robot-path-line）で
 * 表示し、衝突防止の状況を視覚的に把握できます。
 * 4. セルおよび棚の識別:
 * - 「I型」の棚デザインや、各セルのコードを表示。クリックイベントにより
 * 詳細情報（map:select）を他パネルと同期させます。
 * * 管理者が現場に足を運ばずとも、PC画面上で「今の現場」を直感的に把握するためのツールです。
 */

   $('<style>')
   .prop('type', 'text/css')
   .html(`
       @keyframes lineFlow { from { stroke-dashoffset: 20; } to { stroke-dashoffset: 0; } }
       .robot-path-line { animation: lineFlow 0.5s linear infinite; }
       .map-canvas { transition: transform 0.1s ease-out; }
   `).appendTo('head');

$(document).ready(function() {
   let scale = 1, pointX = 0, pointY = 0, start = { x: 0, y: 0 }, isDragging = false;
   const $map = $('#map'), $container = $('#map-container');

   function setTransform() {
       $map.css({
           'transform': `translate(${pointX}px, ${pointY}px) scale(${scale})`,
           'transform-origin': '0 0'
       });
   }

   // PAN & ZOOM
   $container.on('mousedown', function(e) {
       if ($(e.target).is('button')) return;
       e.preventDefault();
       start = { x: e.clientX - pointX, y: e.clientY - pointY };
       isDragging = true;
       $container.css('cursor', 'grabbing');
   });

   $(window).on('mousemove', (e) => {
       if (!isDragging) return;
       pointX = e.clientX - start.x; pointY = e.clientY - start.y;
       setTransform();
   }).on('mouseup', () => { isDragging = false; $container.css('cursor', 'grab'); });

   $container.on('wheel', function(e) {
       e.preventDefault();
       const delta = e.originalEvent.deltaY, zoomSpeed = 1.1, oldScale = scale;
       scale = Math.min(Math.max(0.05, (delta > 0 ? scale / zoomSpeed : scale * zoomSpeed)), 15);
       const rect = $container[0].getBoundingClientRect();
       const mouseX = e.clientX - rect.left, mouseY = e.clientY - rect.top;
       pointX -= (mouseX - pointX) * (scale / oldScale - 1);
       pointY -= (mouseY - pointY) * (scale / oldScale - 1);
       setTransform();
   });

   $('#zoom-in').on('click', () => { scale *= 1.2; setTransform(); });
   $('#zoom-out').on('click', () => { scale /= 1.2; setTransform(); });
   $('#zoom-reset').on('click', fitMapToContainer);

   function fitMapToContainer() {
       const svg = $map.find('svg')[0];
       if (!svg) return;
       const svgW = svg.getAttribute('width'), svgH = svg.getAttribute('height');
       const conW = $container.width(), conH = $container.height();
       scale = Math.min(conW / svgW, conH / svgH) * 0.9;
       pointX = (conW - (svgW * scale)) / 2; pointY = (conH - (svgH * scale)) / 2;
       setTransform();
   }

   function map_monito() {
       $.ajax({
           url: "/manage/api/v1/rms_map_monitor",
           type: "GET",
           success: function(response) {
               if (!response || !response.data) return;
               const svgNS = "http://www.w3.org/2000/svg", mapData = response.data;
               const [width, height] = mapData.size || [1000, 1000];

               const svg = document.createElementNS(svgNS, "svg");
               svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
               svg.setAttribute("width", width); svg.setAttribute("height", height);
               svg.style.display = "block";

               // --- 1. Render Cells (Pale Water Color) ---
               (mapData.cells || []).forEach(cell => {
                   const g = document.createElementNS(svgNS, "g");
                   const rect = document.createElementNS(svgNS, "rect");
                   rect.setAttribute("x", cell.location_x); 
                   rect.setAttribute("y", cell.location_y);
                   rect.setAttribute("width", cell.width); 
                   rect.setAttribute("height", cell.height);
                   rect.setAttribute("fill", "#e0f7fa"); // Pale Water Color
                   rect.setAttribute("stroke", "#b2ebf2"); // Slightly darker border
                   rect.setAttribute("stroke-width", "0.5");
                   g.appendChild(rect);

                   // Restore Cell Label
                   if (cell.width > 25 && cell.cellCode) {
                       const cellTxt = document.createElementNS(svgNS, "text");
                       cellTxt.setAttribute("x", cell.location_x + (cell.width / 2));
                       cellTxt.setAttribute("y", cell.location_y + (cell.height / 2) + 3);
                       cellTxt.setAttribute("font-size", "9");
                       cellTxt.setAttribute("fill", "#00838f"); // Contrast color for text
                       cellTxt.setAttribute("text-anchor", "middle");
                       cellTxt.setAttribute("pointer-events", "none");
                       cellTxt.textContent = cell.cellCode;
                       g.appendChild(cellTxt);
                   }

                   g.style.cursor = "crosshair";
                   g.onclick = (e) => { e.stopPropagation(); $(document).trigger('map:select', { type: 'cell', id: cell.cellCode }); };
                   svg.appendChild(g);
               });

               // --- 2. Render Shelves (I-Shape) ---
               (mapData.kotatsus || []).forEach(k => {
                   const g = document.createElementNS(svgNS, "g");
                   const baseW = k.width * 1.2, baseH = k.height * 1.2;
                   const cx = k.location_x + (baseW / 2), cy = k.location_y + (baseH / 2);
                   g.setAttribute("transform", `rotate(${k.angle || 0}, ${cx}, ${cy})`);
                   
                   const rect = document.createElementNS(svgNS, "rect");
                   const narrowW = baseW * 0.4;
                   rect.setAttribute("x", k.location_x + (baseW - narrowW) / 2); 
                   rect.setAttribute("y", k.location_y);
                   rect.setAttribute("width", narrowW); rect.setAttribute("height", baseH);
                   rect.setAttribute("fill", "#333"); rect.setAttribute("rx", "2");

                   const topBar = document.createElementNS(svgNS, "rect");
                   topBar.setAttribute("x", k.location_x); topBar.setAttribute("y", k.location_y);
                   topBar.setAttribute("width", baseW); topBar.setAttribute("height", baseH * 0.15);
                   topBar.setAttribute("fill", "#333");

                   const botBar = document.createElementNS(svgNS, "rect");
                   botBar.setAttribute("x", k.location_x); botBar.setAttribute("y", k.location_y + (baseH * 0.85));
                   botBar.setAttribute("width", baseW); botBar.setAttribute("height", baseH * 0.15);
                   botBar.setAttribute("fill", "#333");

                   const txt = document.createElementNS(svgNS, "text");
                   txt.setAttribute("x", cx); txt.setAttribute("y", cy + 4);
                   txt.setAttribute("font-size", "12"); txt.setAttribute("fill", "#fff");
                   txt.setAttribute("font-weight", "bold"); txt.setAttribute("text-anchor", "middle");
                   txt.setAttribute("pointer-events", "none");
                   txt.textContent = k.shelfCode;

                   g.appendChild(rect); g.appendChild(topBar); g.appendChild(botBar); g.appendChild(txt);
                   g.onclick = (e) => { e.stopPropagation(); $(document).trigger('map:select', { type: 'shelf', id: k.shelfCode }); };
                   svg.appendChild(g);
               });

               // --- 3. Render AMRs (with Paths) ---
               (mapData.amrs || []).forEach(robot => {
                   if (robot.path && robot.path.length > 0) {
                       const pathLine = document.createElementNS(svgNS, "polyline");
                       const pts = robot.path.map(p => Array.isArray(p) ? p.join(',') : `${p.x || p.location_x},${p.y || p.location_y}`).join(' ');
                       pathLine.setAttribute("points", pts); pathLine.setAttribute("class", "robot-path-line");
                       pathLine.setAttribute("fill", "none"); pathLine.setAttribute("stroke", robot.color || "green");
                       pathLine.setAttribute("stroke-width", "2"); pathLine.setAttribute("stroke-dasharray", "8,4");
                       svg.appendChild(pathLine);
                   }
                   const g = document.createElementNS(svgNS, "g");
                   const body = document.createElementNS(svgNS, "circle");
                   body.setAttribute("cx", robot.location_x); body.setAttribute("cy", robot.location_y);
                   body.setAttribute("r", 25); body.setAttribute("fill", robot.color || "green");
                   body.setAttribute("stroke", "white"); body.setAttribute("stroke-width", "4");
                   body.style.filter = `drop-shadow(0px 0px 8px ${robot.color || "green"})`;
                   const lbl = document.createElementNS(svgNS, "text");
                   lbl.setAttribute("x", robot.location_x); lbl.setAttribute("y", robot.location_y + 8);
                   lbl.setAttribute("font-size", "16"); lbl.setAttribute("fill", "#fff");
                   lbl.setAttribute("text-anchor", "middle"); lbl.textContent = robot.robotId.toString().slice(-3);
                   g.appendChild(body); g.appendChild(lbl); svg.appendChild(g);
               });

               $map.html(svg); setTransform();
           }
       });
   }

   setInterval(map_monito, 3000); map_monito();
   setTimeout(fitMapToContainer, 500);
});