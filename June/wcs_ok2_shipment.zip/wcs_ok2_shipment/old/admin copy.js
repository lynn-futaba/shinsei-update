/* ======================================================================
   admin.js (arranged for easier debugging)
   - Structure:
     1) Config & Diagnostics
     2) Core Helpers (apiFetch, confirm, time)
     3) UI Helpers (accordion, gauge, RMS lamp, auto state)
     4) Backend API Wrappers
     5) Feature Modules (wiring + renderers)
     6) DOM Ready bootstrap
====================================================================== */
'use strict';

/* ======================================================================
   1) Config & Diagnostics
====================================================================== */
const API = {
  base: '/manage/api/v1',
  path(p) { return `${this.base}${p}`; }
};
console.info('[admin.js] Loaded. API base =', API.base);

/* Expose helpers for DevTools debugging */
window.API = API;

/* ======================================================================
   2) Core Helpers (envelope-aware API, confirm modal, time)
====================================================================== */
/**
 * Envelope-aware fetch:
 *   - Accepts JSON; returns only `data` on success.
 *   - Parses JSON even for non-2xx responses if possible.
 *   - Throws Error with best-possible message on failures.
 */
async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Accept': 'application/json', ...(options.headers || {}) },
    ...options
  });

  let json = null;
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) {
    json = await res.json().catch(() => null);
  } else {
    // Try anyway; could still be JSON from proxies
    json = await res.json().catch(() => null);
  }

  if (!res.ok) {
    const msg = json?.message || res.statusText || `HTTP ${res.status}`;
    const code = json?.error?.code || '';
    const details = json?.error?.details;
    const suffix = details ? ` - ${typeof details === 'string' ? details : JSON.stringify(details)}` : '';
    throw new Error(code ? `[${code}] ${msg}${suffix}` : `${msg}${suffix}`);
  }

  // Envelope validation
  const s = Number(json?.status ?? res.status);
  if (!Number.isFinite(s) || s < 200 || s >= 300) {
    const code = json?.error?.code || 'ERROR';
    const msg = json?.message || 'Unexpected API response';
    const details = json?.error?.details;
    const suffix = details ? ` - ${typeof details === 'string' ? details : JSON.stringify(details)}` : '';
    throw new Error(`[${code}] ${msg}${suffix}`);
  }

  return json?.data;
}
window.apiFetch = apiFetch; // for console usage

/**
 * Bootstrap Confirm Modal
 */
function showConfirm(message /* string */) {
  return new Promise((resolve) => {
    let modalEl = document.getElementById('confirmModal');
    if (!modalEl) {
      modalEl = document.createElement('div');
      modalEl.className = 'modal fade';
      modalEl.id = 'confirmModal';
      modalEl.tabIndex = -1;
      modalEl.setAttribute('aria-hidden', 'true');
      modalEl.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title fs-2">確認</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="閉じる"></button>
            </div>
            <div class="modal-body">
              <p class="fs-2 mb-4"></p>
              <div class="d-flex justify-content-end" style="gap:.5rem;">
                <button type="button" class="btn btn-primary btn-lg btn-ok">実行</button>
                <button type="button" class="btn btn-secondary btn-lg btn-cancel">キャンセル</button>
              </div>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modalEl);
    }

    const p = modalEl.querySelector('.modal-body p');
    if (p) p.textContent = message ?? 'よろしいですか？';

    const bs = new bootstrap.Modal(modalEl, { backdrop: true, keyboard: false, focus: true });
    const okBtn = modalEl.querySelector('.btn-ok');
    const cancelBtn = modalEl.querySelector('.btn-cancel');

    let resolved = false;

    const onOk = () => { if (resolved) return; resolved = true; bs.hide(); cleanup(); resolve(true); };
    const onCancel = () => { if (resolved) return; resolved = true; bs.hide(); cleanup(); resolve(false); };
    const onHidden = () => { if (!resolved) { resolved = true; cleanup(); resolve(false); } };
    const cleanup = () => {
      modalEl.removeEventListener('hidden.bs.modal', onHidden);
      okBtn?.removeEventListener('click', onOk);
      cancelBtn?.removeEventListener('click', onCancel);
    };

    modalEl.addEventListener('hidden.bs.modal', onHidden, { once: true });
    okBtn?.addEventListener('click', onOk);
    cancelBtn?.addEventListener('click', onCancel);

    bs.show();
  });
}

/** Time util: updates #current-time once per second */
function getCurrentTime() {
  const now = new Date();
  const formatted = now.toLocaleString("ja-JP", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
  const timeEl = document.getElementById("current-time");
  if (timeEl) timeEl.textContent = `現在時刻: ${formatted}`;
}

/* ======================================================================
   3) UI Helpers (accordion, gauge, RMS lamp, auto state)
====================================================================== */
function setAccordionDisabled(disabled) {
  const acc = document.getElementById('opsAccordion'); // accordion root
  const headerBtn = document.querySelector('#opsHeader .accordion-button');
  const collapse = document.getElementById('opsCollapse');

  if (!acc) return;

  // Visual + interaction disable on whole accordion
  acc.classList.toggle('pe-none', disabled);
  acc.classList.toggle('opacity-50', disabled);
  acc.setAttribute('aria-disabled', String(disabled));

  // Disable all focusable controls within the accordion body
  acc.querySelectorAll('button, input, select, textarea, a').forEach(el => {
    if (disabled) {
      if (!el.dataset.prevDisabled) el.dataset.prevDisabled = String(el.disabled || false);
      if (!el.dataset.prevTabindex) el.dataset.prevTabindex = String(el.tabIndex || 0);
      el.disabled = true;
      el.tabIndex = -1;
      el.setAttribute('aria-disabled', 'true');
    } else {
      if (el.dataset.prevDisabled !== undefined) {
        el.disabled = (el.dataset.prevDisabled === 'true');
        delete el.dataset.prevDisabled;
      } else {
        el.disabled = false;
      }
      if (el.dataset.prevTabindex !== undefined) {
        el.tabIndex = Number(el.dataset.prevTabindex);
        delete el.dataset.prevTabindex;
      } else {
        el.tabIndex = 0;
      }
      el.removeAttribute('aria-disabled');
    }
  });

  // Collapse it when disabling; leave state alone when enabling
  if (collapse && disabled) {
    collapse.classList.remove('show');
    collapse.setAttribute('aria-expanded', 'false');
  }
  if (headerBtn) {
    if (disabled) {
      headerBtn.classList.add('disabled');
      headerBtn.setAttribute('tabindex', '-1');
      headerBtn.setAttribute('aria-disabled', 'true');
    } else {
      headerBtn.classList.remove('disabled');
      headerBtn.removeAttribute('aria-disabled');
      headerBtn.removeAttribute('tabindex');
    }
  }
}

/* ----- Auto state (3-step) ----- */
const AUTO_STATE_SEQ = [
  { key: 'ready',   label: '起動準備', add: ['btn-warning'],                      remove: ['btn-secondary','btn-success','btn-light'], inlineBg: null,                textClass: 'text-dark'  },
  { key: 'start',   label: '起動',     add: ['btn-success','text-white'],         remove: ['btn-secondary','btn-warning','btn-light'], inlineBg: null,                textClass: 'text-white' },
  { key: 'running', label: '運転中',   add: ['btn-light','text-white'],           remove: ['btn-secondary','btn-warning','btn-success'], inlineBg: 'rgb(255, 94, 0)', textClass: 'text-white' },
];

function getRunBtn() { return document.getElementById('tab-ab'); }

function stripBtnVariants(btn) {
  btn.classList.remove(
    'btn-primary','btn-secondary','btn-success','btn-danger',
    'btn-warning','btn-info','btn-light','btn-dark','text-white','text-dark'
  );
  btn.style.removeProperty('background-color');
}

function setAutoStateOnRunBtn(stateIndex) {
  const btn = getRunBtn();
  if (!btn) return;

  const idx = Math.max(0, Math.min(AUTO_STATE_SEQ.length - 1, stateIndex));
  const st  = AUTO_STATE_SEQ[idx];

  btn.dataset.autoStateIndex = String(idx);
  stripBtnVariants(btn);
  st.remove?.forEach(c => btn.classList.remove(c));
  st.add?.forEach(c => btn.classList.add(c));

  if (st.inlineBg) btn.style.setProperty('background-color', st.inlineBg, 'important');

  if (st.textClass === 'text-white') {
    btn.classList.add('text-white');
  } else {
    btn.classList.remove('text-white');
    btn.classList.add('text-dark');
  }

  btn.textContent = st.label;
  btn.setAttribute('aria-checked', 'false');

  const isRunning = (st.key === 'running');
  if (isRunning) {
    btn.dataset.autoLocked = '1';
    btn.classList.add('pe-none');
  } else {
    btn.dataset.autoLocked = '0';
    btn.classList.remove('pe-none');
  }
}

function advanceAutoState() {
  const btn = getRunBtn();
  if (!btn) return;
  if (btn.dataset.autoLocked === '1') return;

  const cur = Number(btn.dataset.autoStateIndex ?? '0');
  const next = (cur + 1) % AUTO_STATE_SEQ.length;
  setAutoStateOnRunBtn(next);
}

/* ----- Mode gauge & labels ----- */
function updateGaugeUI() {
  const autoRadio = document.getElementById('mode-auto');
  const indvRadio = document.getElementById('mode-indv');
  const autoLabel = document.querySelector('label[for="mode-auto"]');
  const indvLabel = document.querySelector('label[for="mode-indv"]');
  const gauge = document.getElementById('lever-mode');
  if (!autoLabel || !indvLabel || !gauge) return;

  const GREEN = '#198754';
  const GREY  = '#d4dfe9';

  autoLabel.classList.remove('bg-success', 'bg-secondary');
  indvLabel.classList.remove('bg-success', 'bg-secondary');

  const isIndv = (indvRadio && indvRadio.checked);
  if (isIndv) {
    indvLabel.classList.add('bg-success');
    autoLabel.classList.add('bg-secondary');
    gauge.style.setProperty('--clr-arc-grad-left', GREY);
    gauge.style.setProperty('--clr-arc-grad-right', GREEN);
  } else {
    autoLabel.classList.add('bg-success');
    indvLabel.classList.add('bg-secondary');
    gauge.style.setProperty('--clr-arc-grad-left', GREEN);
    gauge.style.setProperty('--clr-arc-grad-right', GREY);
  }
}

/* Prevent yellow toggle when 各個 + "停止" button */
function preventIndvGreyToggle() {
  const btn = document.getElementById('tab-ab');
  if (!btn) return;
  btn.addEventListener('click', (e) => {
    const indv = document.getElementById('mode-indv');
    if (indv && indv.checked) {
      if (btn.classList.contains('btn-secondary')) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
    }
  }, true);
}

/* ----- RMS Lamp ----- */
function setRMSState(state /* 'on' | 'off' */) {
  const rmsBtn = document.getElementById('tab-rms');
  if (!rmsBtn) return;
  const s = (state === 'on') ? 'on' : 'off';
  rmsBtn.dataset.rmsState = s;

  rmsBtn.classList.remove(
    'btn-primary','btn-secondary','btn-success','btn-danger',
    'btn-warning','btn-info','btn-light','btn-dark','text-white','text-dark'
  );
  rmsBtn.classList.add('btn-lg','fw-bold','btn-fat','text-white');

  rmsBtn.style.removeProperty('background-color');
  rmsBtn.style.removeProperty('box-shadow');
  rmsBtn.style.borderRadius = '9999px';

  if (s === 'on') {
    const ORANGE = 'rgb(255, 94, 0)';
    rmsBtn.style.setProperty('background-color', ORANGE, 'important');
    rmsBtn.style.boxShadow = '0 0 0.5rem rgba(255,94,0,0.6), 0 0 1.25rem rgba(255,94,0,0.45)';
  } else {
    const RED = 'rgb(220, 53, 69)';
    rmsBtn.style.setProperty('background-color', RED, 'important');
    rmsBtn.style.boxShadow = '0 0 0.4rem rgba(220,53,69,0.45)';
  }
  rmsBtn.setAttribute('aria-checked', (s === 'on') ? 'true' : 'false');
}

function toggleRMSState() {
  const rmsBtn = document.getElementById('tab-rms');
  if (!rmsBtn) return;
  const next = (rmsBtn.dataset.rmsState === 'on') ? 'off' : 'on';
  setRMSState(next);
}

/* ----- Mode UI apply ----- */
function applyModeUI(mode) {
  const isIndv = (mode === 'indv');

  // 1) Accordion enable/disable
  setAccordionDisabled(!isIndv);  // 自動: true (disable), 各個: false (enable)

  // 2) 運転状態ボタン (#tab-ab)
  const runBtn = document.getElementById('tab-ab');
  if (runBtn) {
    if (isIndv) {
      stripBtnVariants(runBtn);
      runBtn.classList.add('btn-secondary','text-white');
      runBtn.textContent = '停止';
      runBtn.style.removeProperty('background-color');
      runBtn.setAttribute('aria-checked', 'false');
    } else {
      setAutoStateOnRunBtn(0);  // 起動準備
    }
  }
}

/* ======================================================================
   4) Backend API Wrappers (envelope-aware)
====================================================================== */
async function apiGetRmsStatus() {
  // GET /manage/api/v1/rms_status -> { system_status, job_status }
  return await apiFetch(API.path('/rms_status'), { method: 'GET' });
}

async function apiGetRmsMode() {
  const arr = await apiFetch(API.path('/get_rms_current_mode'), { method: 'GET' });
  const item = Array.isArray(arr) && arr.length ? arr[0] : null;
  if (!item) throw new Error('No RMS mode data');
  return Number(item.mode) === 1 ? 1 : 0;
}

async function apiSetRmsMode(mode /* 1|0 */) {
  const result = await apiFetch(API.path('/rms_set_mode'), {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode: Number(mode) === 1 ? 1 : 0 })
  });
  return Number(result?.mode) === 1 ? 1 : 0;
}

async function apiRmsAutoPrepare() { return apiFetch(API.path('/rms_auto_prepare'), { method: 'POST' }); }

async function apiRmsAutoStart()   { return apiFetch(API.path('/rms_auto_start'),   { method: 'POST' }); }

async function apiRmsAutoRun()     { return apiFetch(API.path('/rms_auto_run'),     { method: 'POST' }); }

/* ======================================================================
   5) Feature Modules (wiring + renderers)
====================================================================== */

/* -------------------------
   Mode toggle wiring (自動/各個) + initial sync from API
------------------------- */
function wireModeToggle() {
  console.debug('[wire] wireModeToggle');
  const auto = document.getElementById('mode-auto');
  const indv = document.getElementById('mode-indv');

  async function initFromAPI() {
    try {
      const mode = await apiGetRmsMode(); // 1=auto, 0=indv
      if (mode === 1) {
        if (auto) auto.checked = true;
        if (indv) indv.checked = false;
        applyModeUI('auto');
      } else {
        if (auto) auto.checked = false;
        if (indv) indv.checked = true;
        applyModeUI('indv');
      }
      updateGaugeUI();
    } catch (err) {
      console.error('RMS mode init failed:', err);
      applyModeUI((indv && indv.checked) ? 'indv' : 'auto');
      updateGaugeUI();
    }
  }

  async function onChange(targetMode /* 'auto' | 'indv' */) {
    const want = (targetMode === 'auto') ? 1 : 0;
    auto && (auto.disabled = true);
    indv && (indv.disabled = true);

    try {
      const newMode = await apiSetRmsMode(want);
      const isAuto = (newMode === 1);
      if (auto) auto.checked = isAuto;
      if (indv) indv.checked = !isAuto;
      applyModeUI(isAuto ? 'auto' : 'indv');
      updateGaugeUI();
    } catch (err) {
      console.error('Set RMS mode failed:', err);
      alert('モード切替に失敗しました。もう一度お試しください。');
      try {
        const mode = await apiGetRmsMode();
        const isAuto = (mode === 1);
        if (auto) auto.checked = isAuto;
        if (indv) indv.checked = !isAuto;
        applyModeUI(isAuto ? 'auto' : 'indv');
        updateGaugeUI();
      } catch (_) { /* ignore */ }
    } finally {
      auto && (auto.disabled = false);
      indv && (indv.disabled = false);
    }
  }

  auto?.addEventListener('change', () => { if (auto.checked) onChange('auto'); });
  indv?.addEventListener('change', () => { if (indv.checked) onChange('indv'); });

  initFromAPI();
}

/* -------------------------
   Manual controls (各個操作)
------------------------- */
function wireManualOps() {
  console.debug('[wire] wireManualOps');

  // DOM elements
  const $amr    = document.getElementById('amrNumber');
  const $shelf  = document.getElementById('kotatsuNumber');  // "shelf"
  const $cell   = document.getElementById('cellNumber');
  const $angle  = document.getElementById('rotationAngle');

  const $btnMove   = document.getElementById('btnSingleMove');    // 単体移動
  const $btnLoad   = document.getElementById('btnShelfTransport'); // 棚搬送 (go_return)
  const $btnFetch  = document.getElementById('btnLoadedMove');     // 積載移動 (go_fetch)
  const $btnCancel = document.getElementById('btnCancel');         // キャンセル

  if (!$amr || !$cell || !$btnMove || !$btnLoad || !$btnFetch || !$btnCancel) {
    console.warn('[manual-ops] Required elements not found; skipping wire-up.');
    return;
  }

  // Helpers -----------------------------
  function normalizeStr(v) { return String(v ?? '').trim(); }

  function readAngle() {
    const raw = normalizeStr($angle?.value ?? '');
    if (!raw) return 0;
    const num = Number(raw);
    return Number.isFinite(num) ? num : 0;
  }

  function readForm() {
    return {
      robot_id:  normalizeStr($amr.value),
      shelf_id:  normalizeStr($shelf?.value ?? ''),
      cell_code: normalizeStr($cell.value),
      angle:     readAngle(),
    };
  }

  function setBusy(btn, busy) {
    if (!btn) return;
    btn.disabled = !!busy;
    const prev = btn.dataset.prevText || btn.textContent;
    if (!btn.dataset.prevText) btn.dataset.prevText = prev;
    btn.textContent = busy ? `${prev}…` : prev;
  }

  function endpointFor(action) {
    switch (action) {
      case 'move':   return API.path('/rms_manual_move');
      case 'cancel': return API.path('/rms_manual_cancel');
      case 'load':   return API.path('/rms_manual_load');
      case 'fetch':  return API.path('/rms_manual_fetch');
      default: throw new Error(`Unknown action: ${action}`);
    }
  }

  function payloadFor(action, form) {
    switch (action) {
      case 'move':   return ({ robot_id: form.robot_id, cell_code: form.cell_code });
      case 'cancel': return ({ robot_id: form.robot_id, cell_code: form.cell_code });
      case 'load':   return ({ robot_id: form.robot_id, shelf_id: form.shelf_id, cell_code: form.cell_code, angle: form.angle });
      case 'fetch':  return ({ robot_id: form.robot_id, shelf_id: form.shelf_id, cell_code: form.cell_code, angle: form.angle });
    }
  }

  function validate(action, form) {
    const missing = [];
    if (!form.robot_id) missing.push('AMR番号');
    if (!form.cell_code && (action === 'move' || action === 'cancel' || action === 'load' || action === 'fetch')) {
      missing.push('セル番号');
    }
    if (!form.shelf_id && (action === 'load' || action === 'fetch')) {
      missing.push('コタツ番号');
    }
    if (missing.length) {
      return `必須項目が不足しています: ${missing.join('、')}`;
    }
    return null;
  }

  async function callApi(action, form, btn) {
    const url = endpointFor(action);
    const body = payloadFor(action, form);

    setBusy(btn, true);
    try {
      const data = await apiFetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(body),
      });
      alert('実行しました（サーバー応答: OK）');
      return data;
    } finally {
      setBusy(btn, false);
    }
  }

  async function handleAction(action, btn) {
    try {
      const form = readForm();

      const errMsg = validate(action, form);
      if (errMsg) {
        alert(errMsg);
        return;
      }

      // Confirm
      const ok = await showConfirm((() => {
        switch (action) {
          case 'move':   return `AMR ${form.robot_id} を セル ${form.cell_code} へ単体移動します。よろしいですか？`;
          case 'cancel': return `AMR ${form.robot_id} のタスクを（セル ${form.cell_code}）でキャンセルします。よろしいですか？`;
          case 'load':   return `AMR ${form.robot_id} で 棚 ${form.shelf_id} を セル ${form.cell_code} へ搬送（角度 ${form.angle}°）します。よろしいですか？`;
          case 'fetch':  return `AMR ${form.robot_id} で 棚 ${form.shelf_id} を セル ${form.cell_code} へ積載移動（角度 ${form.angle}°）します。よろしいですか？`;
          default:       return '実行しますか？';
        }
      })());
      if (!ok) return;

      await callApi(action, form, btn);
    } catch (err) {
      console.error(`[manual-ops] ${action} failed:`, err);
      alert(`操作に失敗しました。\n${String(err?.message || err)}`);
    }
  }

  // Bind buttons -----------------------------
  document.getElementById('btnSingleMove')   ?.addEventListener('click', () => handleAction('move',   $btnMove));
  document.getElementById('btnShelfTransport')?.addEventListener('click', () => handleAction('load',   $btnLoad));
  document.getElementById('btnLoadedMove')    ?.addEventListener('click', () => handleAction('fetch',  $btnFetch));
  document.getElementById('btnCancel')        ?.addEventListener('click', () => handleAction('cancel', $btnCancel));
}

/* -------------------------
   Error list
------------------------- */
function loadAndRenderErrors() {
  console.debug('[wire] loadAndRenderErrors');
  const tbody = document.getElementById('error-table-body');
  const refreshBtn = document.getElementById('error-refresh-btn');
  if (!tbody) return;

  function levelToBadge(level, isCompleted) {
    if (isCompleted) return 'bg-light text-muted border'; // Neutral color if resolved
    const v = String(level || '').toUpperCase();
    if (v === 'ERROR') return 'bg-danger';
    if (v === 'WARN' || v === 'WARNING') return 'bg-warning text-dark';
    if (v === 'INFO') return 'bg-info text-dark';
    return 'bg-secondary';
  }

  function buildRow(item) {
    // Correctly handle the boolean/string/number variation of is_completed
    const isDone = item.is_completed === true || item.is_completed === 1 || item.is_completed === "true";
    
    const tr = document.createElement('tr');
    if (isDone) {
        tr.style.opacity = '0.6';
        tr.classList.add('table-light');
    }

    // Set datasets for the Detail Modal
    tr.dataset.errorNum = item.error_num || '';
    tr.dataset.errorLevel = item.error_level || 'High';
    tr.dataset.errorCategory = item.source || 'RMS';

    // 1. Details Button
    const tdNo = document.createElement('td');
    const btn = document.createElement('button');
    btn.className = "btn btn-sm btn-outline-secondary";
    btn.textContent = "詳細";
    btn.onclick = (e) => {
        e.stopPropagation(); // Prevent double trigger if row has a click listener
        openDetailFromRow(tr);
    };
    tdNo.appendChild(btn);

    // 2. Error Code
    const tdCode = document.createElement('td');
    tdCode.className = "cursor-pointer text-primary"; // Make it look clickable
    tdCode.innerHTML = `<code>${item.error_code || '-'}</code>`;

    // 3. Content (Badges + Summary)
    const tdContent = document.createElement('td');
    
    // Source Badge: Dark for RMS, Primary (Blue) for WCS
    const sourceSpan = document.createElement('span');
    sourceSpan.className = `badge ${item.source === 'RMS' ? 'bg-dark' : 'bg-primary'} me-2`;
    sourceSpan.textContent = item.source;
    
    // Level/Summary Badge
    const summarySpan = document.createElement('span');
    summarySpan.className = `badge ${levelToBadge(item.error_level, isDone)}`;
    summarySpan.textContent = item.error_summary || '-';
    
    tdContent.appendChild(sourceSpan);
    tdContent.appendChild(summarySpan);

    // 4. Time
    const tdTime = document.createElement('td');
    tdTime.className = 'small font-monospace';
    tdTime.textContent = item.error_datetime || '-';

    tr.appendChild(tdNo);
    tr.appendChild(tdCode);
    tr.appendChild(tdContent);
    tr.appendChild(tdTime);
    
    return tr;
  }

  async function fetchErrors() {
    try {
        const response = await apiFetch(API.path('/get_error_list'), { method: 'GET' });
        
        // Debugging: See exactly what the variable holds
        console.log("Response received:", response);

        // Flexible check: use response.data if it exists, otherwise use response itself
        const payload = response.data ? response.data : response;

        if (!payload.athena && !payload.local) {
            console.warn("Payload does not contain expected keys:", payload);
            return [];
        }

        const local = (payload.local || []).map(i => ({ ...i, source: 'WCS' }));
        const athena = (payload.athena || []).map(i => ({ ...i, source: 'RMS' }));
        
        return [...local, ...athena];
    } catch (e) {
        console.error("Fetch failed", e);
        throw e;
    }
}

  async function render() {
    try {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">読み込み中...</td></tr>';
        const items = await fetchErrors();
        
        // Sorting by date (Newest first)
        items.sort((a, b) => (b.error_datetime || '').localeCompare(a.error_datetime || ''));
        
        tbody.innerHTML = '';
        if (items.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">現在、表示できるエラーはありません</td></tr>';
            return;
        }

        const frag = document.createDocumentFragment();
        items.forEach((it, i) => frag.appendChild(buildRow(it, i)));
        tbody.appendChild(frag);

      } catch (err) {
        tbody.innerHTML = `
          <tr><td colspan="4" class="text-center text-danger">取得エラー: ${err.message}</td></tr>
        `;
      }
    }

  render();

  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      refreshBtn.disabled = true;
      const prev = refreshBtn.textContent;
      refreshBtn.textContent = '更新中...';
      render().finally(() => {
        refreshBtn.disabled = false;
        refreshBtn.textContent = prev;
      });
    });
  }

  // Error table modal on "エラーコード" click
  (function () {
    const modalEl = document.getElementById('errorDetailModal');
    if (!modalEl) return;

    const modal = new bootstrap.Modal(modalEl, { backdrop: true, keyboard: true });

    (function tuneErrorDetailFooter() {
      const footer = modalEl.querySelector('.modal-footer');
      if (footer) {
        footer.classList.remove('justify-content-start');
        footer.classList.add('justify-content-end');
        footer.style.gap = '.5rem';
      }
      modalEl.querySelectorAll('.modal-footer .btn, .modal-body .btn').forEach(btn => {
        btn.classList.add('btn-lg');
      });
    })();

    function setText(id, value) {
      const el = document.getElementById(id);
      if (el) el.textContent = value ?? '-';
    }

    function openDetailFromRow(row) {
      const code = (row.cells[1]?.textContent || '').trim();
      const content = (row.cells[2]?.innerText || '').trim();
      const time = (row.cells[3]?.textContent || '').trim();

      const no = row.dataset.errorNum || '—';
      const level = row.dataset.errorLevel || '—';
      const type = row.dataset.errorCategory || '—';
      const detail = row.dataset.errorDescription || content || '—';
      const action = 'ネットワーク確認してください。';

      setText('err-no', no);
      setText('err-code', code || '—');
      setText('err-level', level);
      setText('err-type', type);
      setText('err-content', content || '—');
      setText('err-detail', detail);
      setText('err-action', action);
      setText('err-time', time || '—');

      modal.show();
    }

    tbody?.addEventListener('click', (e) => {
      const cell = e.target.closest('td');
      const row = e.target.closest('tr');
      if (!cell || !row) return;
      if (cell.cellIndex !== 1) return; // 2nd column only
      openDetailFromRow(row);
    });

    tbody?.addEventListener('keydown', (e) => {
      const cell = e.target.closest('td');
      const row = e.target.closest('tr');
      if (!cell || !row) return;
      if (cell.cellIndex !== 1) return;
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openDetailFromRow(row);
      }
    });

    Array.from(tbody?.rows || []).forEach(tr => {
      const codeCell = tr.cells[1];
      if (codeCell) codeCell.tabIndex = 0;
    });

    modalEl.addEventListener('click', (e) => {
      const btn = e.target.closest('#err-reset-btn');
      if (!btn) return;

      ['err-no','err-code','err-level','err-type','err-content','err-detail','err-action','err-time']
        .forEach(id => setText(id, '-'));

      btn.disabled = true;
      const original = btn.textContent;
      btn.textContent = 'リセット済';
      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = original;
      }, 800);
    });
  })();
}

// -------------------------
//   Line States (list + click-to-toggle)
// -------------------------
function loadAndRenderLineStates() {
  console.debug('[wire] loadAndRenderLineStates started');

  const GREEN_HEX = '#ace1af';

  const setCellToGreen = (td) => {
    td.classList.remove('bg-secondary', 'text-white');
    td.classList.add('bg-light', 'text-dark');
    td.style.setProperty('background-color', GREEN_HEX, 'important');
  };

  const setCellToGrey = (td) => {
    td.classList.remove('bg-light', 'text-dark');
    td.classList.add('bg-secondary', 'text-white');
    td.style.removeProperty('background-color');
  };

  async function fetchLineStates() {
    const response = await apiFetch(API.path('/get_line_state_list'), { method: 'GET' });
    console.debug('[wire] API Response:', response);

    // Handle different apiFetch return shapes
    const items = response.data || response || []; 

    if (!Array.isArray(items)) {
        console.error('Data is not an array:', items);
        return [];
    }

    return items.map(e => ({
      line_id: String(e.line_id ?? '').trim(),
      line_name: String(e.line_name ?? '').trim(),
      transport_permission: Boolean(e.transport_permission),
      pallets: Array.isArray(e.pallets) ? e.pallets : [] 
    }));
  }

  function buildRow(item) {
    const tr = document.createElement('tr');
    tr.dataset.lineId = item.line_id;
    tr.dataset.lineName = item.line_name;

    // Col 1: Cell Name
    const tdCell = document.createElement('td');
    tdCell.textContent = item.line_name || '-';
    if (item.transport_permission) setCellToGreen(tdCell);
    else setCellToGrey(tdCell);
    tr.appendChild(tdCell);

    // Col 2 & 3: Pallet Name 1 & 2
    for (let i = 0; i < 2; i++) {
        const tdPallet = document.createElement('td');
        let pName = (item.pallets && item.pallets[i]) ? item.pallets[i] : '—';
        if (pName === "None" || pName === "") pName = "—";
        tdPallet.textContent = pName;
        tr.appendChild(tdPallet);
    }
    return tr;
  }

  async function render() {
    // RE-SELECT inside render to ensure it exists in DOM
    const targetBody = document.getElementById('line-state-body');
    if (!targetBody) {
        console.warn('Target <tbody> not found yet. Retrying...');
        return;
    }

    try {
      const items = await fetchLineStates();
      console.debug('[wire] Items to render:', items.length);

      targetBody.innerHTML = ''; // Clear current content
      
      if (items.length === 0) {
        targetBody.innerHTML = '<tr><td colspan="3" class="text-center">No data found</td></tr>';
        return;
      }

      items.sort((a, b) => a.line_name.localeCompare(b.line_name, 'ja'));

      const frag = document.createDocumentFragment();
      for (const item of items) frag.appendChild(buildRow(item));
      targetBody.appendChild(frag);

    } catch (err) {
      console.error('Render failed:', err);
      targetBody.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Fetch Error</td></tr>';
    }
  }

  // Run immediately
  render();
}

// -------------------------
//   Click-to-toggle on line state cells
// -------------------------
function wireLineStateCellClick() {
  console.debug('[wire] wireLineStateCellClick');
  const tbody = document.querySelector('#line-state-body');
  if (!tbody) return;

  const GREEN_HEX = '#ace1af';

  // Optional: limit which line names are clickable. Remove this Set if all are allowed.
  const TARGET_LINE_NAMES = new Set(['T63', 'T64', 'T65', 'T66']);


  // Works with /manage/api/v1/line_state/permission
  // Sends { line_id: <number|string> } depending on the value.
  // Returns true/false based on the server's transport_permission.
  async function toggleRequestFlag(lineID) {
    // If the ID is all digits, send it as a Number; otherwise keep as string.
    const normalized = /^\d+$/.test(String(lineID)) ? Number(lineID) : String(lineID);

    const result = await apiFetch(API.path('/line_state/permission'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ line_id: normalized })
    });

    // apiFetch already returns the unwrapped "data" object from your success() envelope
    // expected shape: { line_id: <...>, transport_permission: true|false }
    return Boolean(result.transport_permission);
  }


  function setCellToGreen(td) {
    td.classList.remove('bg-secondary', 'text-white');
    td.classList.add('bg-light', 'text-dark');
    td.style.setProperty('background-color', GREEN_HEX, 'important');
  }

  function setCellToGrey(td) {
    td.classList.remove('bg-light', 'text-dark');
    td.classList.add('bg-secondary', 'text-white');
    td.style.removeProperty('background-color');
  }

  function setBusy(td, busy) {
    if (busy) {
      td.dataset.prevText = td.textContent.trim();
      td.textContent = `${td.dataset.prevText} …`;
      td.style.opacity = '0.8';
      td.style.cursor = 'wait';
    } else {
      if (td.dataset.prevText) {
        td.textContent = td.dataset.prevText;
        delete td.dataset.prevText;
      }
      td.style.opacity = '';
      td.style.cursor = '';
    }
  }

  tbody.addEventListener('click', async (e) => {
    const td = e.target.closest('td');
    const tr = e.target.closest('tr');
    if (!td || !tr) return;
    if (td.cellIndex !== 0) return; // Only first column (line name) clickable

    const lineId = tr.dataset.lineId;       // backend expects this
    const lineName = tr.dataset.lineName;   // optional filter

    if (!lineId) return;
    if (TARGET_LINE_NAMES.size > 0 && !TARGET_LINE_NAMES.has(lineName)) return;

    try {
      setBusy(td, true);
      const requestFlag = await toggleRequestFlag(lineId);
      if (requestFlag) setCellToGreen(td);
      else setCellToGrey(td);
    } catch (err) {
      console.error('permission toggle 失敗:', err);
      alert('更新に失敗しました。ネットワークまたはサーバーをご確認ください。');
    } finally {
      setBusy(td, false);
    }
  });
}

/* -------------------------
   Task Status RMS
------------------------- */
function loadAndRenderTaskStatus() {
  const tbody = document.getElementById('task-status-body');

  if (!tbody) {
    console.error('❌ #task-status-body not found');
    return;
  }

  async function render() {
    try {
      console.log('👉 Loading task status...');

      const items = await apiFetch(
        API.path('/get_task_status'),
        { method: 'GET' }
      );

      console.log('✅ Task items:', items);

      // Clear table
      tbody.innerHTML = '';

      // Empty case
      if (!Array.isArray(items) || items.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="6" class="text-center text-muted">
              タスクがありません
            </td>
          </tr>`;
        return;
      }

      const frag = document.createDocumentFragment();

      items.forEach(task => {
        const tr = document.createElement('tr');

        const td = (val) => {
          const el = document.createElement('td');
          el.textContent = val ?? '-';
          return el;
        };

        // Columns
        tr.appendChild(td(task.task_id));
        tr.appendChild(td(task.robot_id));

        // Status with color
        const statusTd = td(task.status);
        if (task.status === 'EXECUTING') {
          statusTd.className = 'text-primary fw-bold';
        } else if (task.status === 'COMPLETED') {
          statusTd.className = 'text-success';
        } else if (task.status === 'ERROR') {
          statusTd.className = 'text-danger fw-bold';
        }
        tr.appendChild(statusTd);

        tr.appendChild(td(task.instruction));
        tr.appendChild(td(task.destination));
        tr.appendChild(td(task.task_type));

        frag.appendChild(tr);
      });

      tbody.appendChild(frag);

    } catch (err) {
      console.error('❌ Render error:', err);

      tbody.innerHTML = `
        <tr>
          <td colspan="6" class="text-danger text-center">
            エラー: ${err.message}
          </td>
        </tr>`;
    }
  }

  render();
}

/* -------------------------
    Lift Entrance (Pivoted)
------------------------- */
/* -------------------------
    Lift Entrance - 4 Column Version
------------------------- */
function loadAndRenderLiftEntrance() {
  const tbody = document.getElementById('lift-state-body');
  if (!tbody) return;

  async function render() {
    try {
      const response = await apiFetch(API.path('/get_lift_entrance'), { method: 'GET' });
      const items = Array.isArray(response.data) ? response.data : response;

      tbody.innerHTML = '';
      items.forEach(item => {
        const tr = document.createElement('tr');
        const status = String(item.transport_status || '').toUpperCase();

        // 1. Column: Maguchi (Always shows)
        const tdMaguchi = document.createElement('td');
        tdMaguchi.textContent = item.maguchi_name || '-';
        tdMaguchi.className = "bg-light fw-bold text-center align-middle";
        tr.appendChild(tdMaguchi);

        if (status === 'WAIT') {
          // --- Special Case: Merged row for WAIT ---
          const tdWait = document.createElement('td');
          tdWait.colSpan = 3; // Fills Line, Pallet, and Status columns
          tdWait.textContent = '完成品搬入待ち';
          tdWait.className = "text-center align-middle bg-secondary text-white fw-bold";
          tr.appendChild(tdWait);
        } else {
          // --- Normal Case: 3 separate columns ---
          
          // 2. Column: Line Name
          const tdLine = document.createElement('td');
          tdLine.textContent = item.line_name || '';
          tdLine.className = "text-center align-middle";
          
          // 3. Column: Pallet Name
          const tdPallet = document.createElement('td');
          tdPallet.textContent = item.pallet_name || '';
          tdPallet.className = "text-center align-middle";
          
          // 4. Column: Status
          const tdStatus = document.createElement('td');
          tdStatus.className = "text-center align-middle";
          
          // Apply labels and colors for non-WAIT statuses
          if (status === 'READY' || status === 'REDY') {
            const label = '取出開始';
            const ORANGE = 'rgb(250, 96, 0)';
            [tdLine, tdPallet, tdStatus].forEach(td => {
              td.style.backgroundColor = ORANGE;
              td.style.color = 'white';
            });
            tdStatus.textContent = label;
          } else if (status === 'COMP' || status === 'COMPLETE') {
            const GREEN = '#ace1af';
            tdLine.style.backgroundColor = GREEN;
            tdPallet.style.backgroundColor = GREEN;
            tdStatus.style.backgroundColor = '#6c757d';
            tdStatus.style.color = 'white';
            tdStatus.textContent = '完了';
          } else {
            tdStatus.textContent = item.transport_status;
          }

          tr.appendChild(tdLine);
          tr.appendChild(tdPallet);
          tr.appendChild(tdStatus);
        }

        tbody.appendChild(tr);
      });
    } catch (err) {
      console.error(err);
    }
  }
  render();
}

/* -------------------------
   Map selection → fill inputs (INDV mode only)
------------------------- */
function wireMapSelectionToInputs() {
  const mapRoot = document.getElementById('map');
  if (!mapRoot) return;

  const isIndv = () => document.getElementById('mode-indv')?.checked === true;

  function expandAccordion() {
    const collapse = document.getElementById('opsCollapse');
    if (collapse && !collapse.classList.contains('show')) {
      const c = new bootstrap.Collapse(collapse, { toggle: false });
      c.show();
    }
  }

  function fill(id, value) {
    const el = document.getElementById(id);
    if (!el || value == null || String(value).trim() === '') return;
    el.value = String(value).trim();
    expandAccordion();
    try { el.focus({ preventScroll: false }); } catch {}
  }

  // Generic combined event
  mapRoot.addEventListener('map:selected', (e) => {
    if (!isIndv()) return;
    const d = e.detail || {};
    switch (d.kind) {
      case 'cell':
        fill('cellNumber',   d.code || d.cellCode || d.id);
        break;
      case 'amr':
        fill('amrNumber',    d.id   || d.robotId   || d.code);
        break;
      case 'shelf':
      case 'kotatsu':
        fill('kotatsuNumber', d.shelfCode || d.id || d.code);
        break;
    }
  });

  // Kind-specific back-compat events
  mapRoot.addEventListener('map:cellSelected',   (e) => { if (!isIndv()) return; const d = e.detail || {}; fill('cellNumber',    d.code || d.cellCode || d.id); });
  mapRoot.addEventListener('map:amrSelected',    (e) => { if (!isIndv()) return; const d = e.detail || {}; fill('amrNumber',     d.id   || d.robotId   || d.code); });
  mapRoot.addEventListener('map:shelfSelected',  (e) => { if (!isIndv()) return; const d = e.detail || {}; fill('kotatsuNumber', d.shelfCode || d.id || d.code); });

  console.debug('[wire] wireMapSelectionToInputs');
}

/* -------------------------
   Run button (auto 3-step) wiring
------------------------- */
function wireRunButtonAdvance() {
  console.debug('[wire] wireRunButtonAdvance');
  const btn = document.getElementById('tab-ab');
  if (!btn) return;

  btn.addEventListener('click', async (e) => {
    const indv = document.getElementById('mode-indv');
    if (indv && indv.checked) return; // 各個は無視（別API後日）
    if (btn.dataset.autoLocked === '1') { e.preventDefault(); e.stopPropagation(); return; }

    e.preventDefault(); e.stopPropagation();
    const cur = Number(btn.dataset.autoStateIndex ?? '0');

    try {
      if (cur === 0) {
        const ok = await showConfirm('「起動準備」を実行しますか？');
        if (!ok) return;
        await apiRmsAutoPrepare();
        setAutoStateOnRunBtn(1);  // 起動へ
        return;
      }
      if (cur === 1) {
        const ok = await showConfirm('「起動」を実行しますか？');
        if (!ok) return;
        await apiRmsAutoStart();
        setAutoStateOnRunBtn(2);  // 運転中へ
        return;
      }
      // Already 運転中: fire run assertion (idempotent)
      await apiRmsAutoRun();
      setAutoStateOnRunBtn(2);
    } catch (err) {
      console.error('自動ステップ失敗:', err);
      alert('自動モードの実行に失敗しました。もう一度お試しください。');
    }
  }, true);
}

/* -------------------------
   RMS Lamp (init + optional poll)
------------------------- */
function wireRmsLamp() {
  console.debug('[wire] wireRmsLamp');
  const rmsBtn = document.getElementById('tab-rms');
  if (!rmsBtn) return;

  // RMS lamp is API-driven; block manual toggles
  rmsBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
  }, true);

  // Initial paint + polling
  if (!rmsBtn.dataset.rmsState) setRMSState('off');
  syncRMSFromAPI();

  if (!window.__rmsLampTimer) {
    window.__rmsLampTimer = setInterval(syncRMSFromAPI, 5000); // 5s poll
  }
}

/* ======================================================================
   6) DOM Ready bootstrap
====================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  console.group('[admin.js] DOMContentLoaded');

  // Clock
  setInterval(getCurrentTime, 1000);

  // Mode UI
  wireModeToggle();
  preventIndvGreyToggle();

  // Buttons demo styling (keep RMS/AB look)
  (function demoButtonsLook() {
    const setActive = (btn) => {
      document.querySelectorAll('#tab-rms, #tab-ab')
        .forEach(el => el.classList.remove('btn-warning','text-white'));
      btn.classList.add('btn-warning','text-white');
    };
    document.getElementById('tab-rms')?.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation(); // Lamp is API-driven; block demo color
    }, true);
    document.getElementById('tab-ab')?.addEventListener('click',  (e) => setActive(e.currentTarget));
  })();

  // Force 自動 mode default to 「起動準備」 at load if already selected
  (function enforceAutoInit() {
    const auto = document.getElementById('mode-auto');
    const runBtn = document.getElementById('tab-ab');
    if (!runBtn) return;
    if (auto && auto.checked) {
      runBtn.style.removeProperty('background-color');
      setAutoStateOnRunBtn(0);
    }
  })();

  // Feature wires
  wireRmsLamp();
  wireRunButtonAdvance();
  loadAndRenderErrors();
  loadAndRenderLineStates();
  wireLineStateCellClick();
  loadAndRenderTaskStatus();
  wireManualOps();
  loadAndRenderLiftEntrance();

  // NEW: Map → Inputs (INDV only)
  wireMapSelectionToInputs();

  console.groupEnd();
});

/* ----- RMS状態 ----- */
async function syncRMSFromAPI() {
  try {
    const data = await apiGetRmsStatus(); // { system_status, job_status }
    const sys = String(data?.system_status || '').toUpperCase();
    const job = String(data?.job_status || '').toUpperCase();
    const lampOn = (sys === 'RUNNING' && job === 'RUNNING');
    setRMSState(lampOn ? 'on' : 'off');   // 'on' => Orange, 'off' => Red (your existing styling)
  } catch (err) {
    console.error('[RMS Lamp] sync failed:', err);
    setRMSState('off');                   // Fail-safe
  }
}

/**
 * Listen for map selection events and fill manual operation inputs
 */
function wireMapAutoFill() {
  $(document).on('map:select', function(e, data) {
      // Only auto-fill if we are in "各個操作" (Individual Mode)
      const isIndv = document.getElementById('mode-indv')?.checked;
      if (!isIndv) return;

      console.log(`[AutoFill] Selected ${data.type}: ${data.id}`);

      switch(data.type) {
          case 'amr':
              const $amr = $('#amrNumber');
              $amr.val(data.id);
              // Visual feedback
              $amr.addClass('is-valid');
              setTimeout(() => $amr.removeClass('is-valid'), 1000);
              break;
              
          case 'shelf':
              const $shelf = $('#kotatsuNumber');
              $shelf.val(data.id);
              $shelf.addClass('is-valid');
              setTimeout(() => $shelf.removeClass('is-valid'), 1000);
              break;
              
          case 'cell':
              const $cell = $('#cellNumber');
              $cell.val(data.id);
              $cell.addClass('is-valid');
              setTimeout(() => $cell.removeClass('is-valid'), 1000);
              break;
      }
  });
}

// Call this function in your DOM ready block in admin.js
$(document).ready(function() {
  // ... existing init code ...
  wireMapAutoFill();
});

$(document).on('map:select', function(e, selection) {
  if (selection.type === 'shelf') {
      $('input[name="shelfCode"]').val(selection.id);
  } 
  else if (selection.type === 'amr') {
      $('input[name="robotId"]').val(selection.id);
  } 
  else if (selection.type === 'cell') {
      // This will fill your target location/cell input
      $('input[name="cellCode"], input[name="location"]').val(selection.id);
  }
});