"""
作業者リポジトリ (WorkerRepository)
作成者: Lynn
----------------------------------
現場作業者（Worker）向け画面に関連するDB操作を一括管理するクラス。

主な役割:
1. データアクセス: 間口情報、リフト搬入口状態、パレット供給スケジュールの取得・更新。
2. 整合性の担保: 更新時の「楽観的ロック（Optimistic Locking）」の実装。
   - expected_rev（期待されるリビジョン）をチェックし、他のユーザーとの更新競合を防ぎます。
3. トランザクション管理: 状態遷移（READY → WORK → COMPLETE）のバリデーションと、
   失敗時のロールバック処理を行います。
4. ドメイン変換: DBの生データを、WorkerFactory を通じてドメインエンティティに変換します。

この層がDBの具体的なSQLや接続管理を隠蔽することで、ビジネスロジック側は純粋な
エンティティ操作に集中できるようになります。
"""
# app/infrastructure/repositories/worker_repository.py
from __future__ import annotations
from typing import Optional, Iterable, List, Dict
from mysql.connector.cursor import MySQLCursorDict

from app.interfaces.sql.wcs_sql_query import WCSSQLQuery
from app.infrastructure.factory.domain_factory import WorkerFactory
from app.domain.entities import Maguchi, LiftEntrance, PalletScheduleLine, PalletPair

from app.domain.exception import NotFoundError, InvalidStateError, StaleWriteError

from app.infrastructure.setup_log import setup_log
import app.config.config as cfg

# ログ設定 (名前を付ける)
logger = setup_log(cfg.LOG_FOLDER, cfg.WORKER_REPO_LOG_FILE, cfg.BACKUP_DAYS, logger_name="worker_repo")

_TABLE = "maguchi"
# Backtick `type` to avoid potential keyword issues.
_COLUMNS = "cell_code, `type`, kotatsu_id, transport_permission, line_code"

class WorkerRepository(WorkerFactory):
    """
    Production implementation (DB connection). 
    """

    def __init__(self, db, wcs_sql: WCSSQLQuery, db_name: str = "test_test_futaba_ok2_shippment"):
        # REMOVED: super().__init__(db=db, db_name=db_name) 
        # Most Factories are utility classes and don't take init args.
        
        self._worker_factory = WorkerFactory  
        self._db = db
        self._db_name = db_name
        self._sql = wcs_sql
        logger.info("[WorkerRepository] initialized", extra={"db_name": db_name})
    
    # @staticmethod
    # def _to_entity(row: dict) -> Maguchi:
    #     return Maguchi(
    #         cell_code=str(row["cell_code"]),
    #         type=str(row["type"]),
    #         transport_permission=bool(row["transport_permission"]),
    #         line_code=str(row["line_code"]),
    #         kotatsu_id=str(row["kotatsu_id"]) if row.get("kotatsu_id") is not None else None
    #     )

    # def get(self, cell_code: str) -> Optional[Maguchi]:
    #     sql = f"SELECT * FROM m_line WHERE cell_code=%s LIMIT 1"
    #     conn = self._db.get_connection(self._db_name)
    #     try:
    #         cur: MySQLCursorDict = conn.cursor(dictionary=True)
    #         cur.execute(sql, (cell_code,))
    #         row = cur.fetchone()
    #         cur.close()
    #         return self._to_entity(row) if row else None
    #     finally:
    #         conn.close()

    # def list(
    #     self,
    #     *,
    #     type: Optional[str] = None,
    #     kotatsu_id: Optional[str] = None,
    #     transport_permission: Optional[bool] = None,
    #     line_code: Optional[str] = None,
    # ) -> Iterable[Maguchi]:
    #     where: List[str] = []
    #     params: List[object] = []

    #     if type:
    #         where.append("`type` = %s")
    #         params.append(type)
    #     if kotatsu_id:
    #         where.append("kotatsu_id = %s")
    #         params.append(kotatsu_id)
    #     if transport_permission is not None:
    #         where.append("transport_permission = %s")
    #         params.append(1 if transport_permission else 0)
    #     if line_code:
    #         where.append("line_code = %s")
    #         params.append(line_code)

    #     sql = f"SELECT * FROM {_TABLE}"
    #     if where:
    #         sql += " WHERE " + " AND ".join(where)
    #     sql += " ORDER BY cell_code"

    #     conn = self._db.get_connection(self._db_name)
    #     try:
    #         cur: MySQLCursorDict = conn.cursor(dictionary=True)
    #         cur.execute(sql, tuple(params))
    #         rows = cur.fetchall()
    #         cur.close()
    #         return [self._to_entity(r) for r in rows]
    #     finally:
    #         conn.close()

    # def update(self, entity: Maguchi) -> None:
    #     sql = f"""
    #         UPDATE {_TABLE}
    #            SET `type`=%s,
    #                kotatsu_id=%s,
    #                transport_permission=%s,
    #                line_code=%s
    #          WHERE cell_code=%s
    #     """.strip()
    #     params = (
    #         entity.type,
    #         entity.kotatsu_id,
    #         int(entity.transport_permission),
    #         entity.line_code,
    #         entity.cell_code,
    #     )
    #     conn = self._db.get_connection(self._db_name)
    #     try:
    #         with conn.cursor() as cur:
    #             cur.execute(sql, params)
    #         conn.commit()
    #     except Exception:
    #         conn.rollback()
    #         raise
    #     finally:
    #         conn.close()

    # def delete(self, cell_code: str) -> None:
    #     sql = f"DELETE FROM {_TABLE} WHERE cell_code=%s"
    #     conn = self._db.get_connection(self._db_name)
    #     try:
    #         with conn.cursor() as cur:
    #             cur.execute(sql, (cell_code,))
    #         conn.commit()
    #     except Exception:
    #         conn.rollback()
    #         raise
    #     finally:
    #         conn.close()

    # def exists(self, cell_code: str) -> bool:
    #     sql = f"SELECT 1 FROM {_TABLE} WHERE cell_code=%s LIMIT 1"
    #     conn = self._db.get_connection(self._db_name)
    #     try:
    #         cur = conn.cursor()
    #         cur.execute(sql, (cell_code,))
    #         ok = cur.fetchone() is not None
    #         cur.close()
    #         return ok
    #     finally:
    #         conn.close()
    
    # ---------- Lift Entrance ----------
    def list_lift_entrance(self) -> list[LiftEntrance]:
        sql = self._sql.t_lift_station_select_all()
        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            rows = cur.fetchall()
            cur.close()
            return [WorkerFactory.get_lift_entrance(r) for r in rows]
        finally:
            conn.close()

    # --- get single row by primary key ---
    def get_by_pk(self, plat_no: int, seq_no: int) -> LiftEntrance | None:
        sql = self._sql.t_lift_station_select_one_by_pk()
        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql, (plat_no, seq_no))
            row = cur.fetchone()
            cur.close()
            return WorkerFactory.get_lift_entrance(row) if row else None
        finally:
            conn.close()    

    # --- update state using (plat_no, seq_no) ---
    def update_state(self, plat_no: int, seq_no: int, next_state: str) -> LiftEntrance:
        """
        Handles state transitions:
        READY(or REDY)/WAIT -> WORK
        WORK -> COMP
        Stores textual status ('READY','WAIT','WORK','COMP') for consistency.
        Accepts existing numeric values as well (0..3) for compatibility.
        """
        sql_lock   = self._sql.t_lift_station_lock_status_by_pk()
        sql_update = self._sql.t_lift_station_update_status_by_pk()
        sql_select = self._sql.t_lift_station_select_one_by_pk()

        # status mappings (both ways)
        status_to_code = {'READY':0, 'REDY':0, 'WAIT':1, 'WORK':2, 'COMP':3, 'COMPLETE':3}
        code_to_status = {0:'READY', 1:'WAIT', 2:'WORK', 3:'COMP'}

        conn = self._db.get_connection()
        try:
            cur = conn.cursor(dictionary=True)

            # 1) Lock targeted row
            cur.execute(sql_lock, (plat_no, seq_no))
            row = cur.fetchone()
            if not row:
                raise NotFoundError(f"Platform {plat_no}, seq {seq_no} not found.")

            # Normalize current status string
            raw = row["transport_status"]
            # Accept 'WORK' / '2' / 2 / None safely
            if raw is None:
                raise InvalidStateError("現在の状態が不明です（NULL）")
            if isinstance(raw, (int, float)) or str(raw).isdigit():
                current_code = int(raw)
                current = code_to_status.get(current_code, None)
                if not current:
                    raise InvalidStateError(f"未知の状態コード: {raw}")
            else:
                current = str(raw).upper().strip()
                # alias
                if current == 'REDY':
                    current = 'READY'

            desired = str(next_state).upper().strip()
            if desired == 'COMPLETE':
                desired = 'COMP'

            # Transition checks
            if current in ('READY', 'WAIT') and desired == 'WORK':
                db_next_text = 'WORK'
            elif current == 'WORK' and desired == 'COMP':
                db_next_text = 'COMP'
            else:
                raise InvalidStateError(f"無効な遷移: {current} → {desired}")

            # 2) Update
            cur.execute(sql_update, (db_next_text, plat_no, seq_no))
            if cur.rowcount == 0:
                raise StaleWriteError("更新に失敗しました（競合の可能性があります）")
            conn.commit()

            # 3) Fetch updated row with joined fields for API
            cur.execute(sql_select, (plat_no, seq_no))
            updated_row = cur.fetchone()
            cur.close()
            return WorkerFactory.get_lift_entrance(updated_row)

        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_line_exists(self, line_name: str) -> bool:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM m_line WHERE line_name = %s", (line_name,))
            return cur.fetchone() is not None
        finally:
            conn.close()

    def ps_list_all(self) -> List[PalletScheduleLine]:
        results = []
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(self._sql.ps_get_all_lines())
            lines = cur.fetchall()
            for row in lines:
                l_id = row["line_id"]
                cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
                pairs = cur.fetchall()
                results.append(WorkerFactory.pallet_schedule_line_from_rows(
                    line_name=row["line_name"], rows=pairs, rev=row["rev"], line_id=l_id
                ))
            return results
        finally:
            conn.close()

    def ps_list_names(self, line_name: str) -> List[Dict]:
        """Return [{pallet_type, pallet_name}] for UI dropdown."""
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(self._sql.ps_get_all_master_pallets())
            rows = cur.fetchall()
            return [{"pallet_type": r["pallet_type"], "pallet_name": r["pallet_name"]} for r in rows]
        finally:
            conn.close()
    
    def ps_update_pair(self, line_name: str, pair_index: int, pallet_type: int, count: int, current_rev: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # Resolve line_id & rev
            cur.execute(self._sql.ps_get_line_by_name(), (line_name,))
            line = cur.fetchone()
            if not line:
                return None
            l_id, db_rev = line["line_id"], int(line["rev"])

            if db_rev != int(current_rev):
                return None

            # (optional) validate pallet_type exists
            cur.execute(self._sql.ps_check_pallet_type_exists(), (pallet_type,))
            if cur.fetchone() is None:
                return None  # or raise NotFoundError

            # Apply change
            cur.execute(self._sql.ps_update_pair(), (pallet_type, count, l_id, pair_index))

            # CAS bump rev
            cur.execute(self._sql.ps_bump_status_rev_cas(), (l_id, current_rev))
            if cur.rowcount != 1:
                conn.rollback()
                return None

            conn.commit()
            return self.ps_get_line(line_name)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()    

    def ps_add_pair(self, line_name: str, before_index: Optional[int], pallet_type: int, count: int, current_rev: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            # Resolve line & ensure status row exists (first time)
            cur.execute(self._sql.ps_get_line_by_name(), (line_name,))
            line = cur.fetchone()
            if not line:
                return None
            l_id, db_rev = line["line_id"], int(line["rev"])

            # Ensure status row exists for CAS (no-op if exists)
            cur.execute(self._sql.ps_ensure_status_row(), (l_id,))

            if db_rev != int(current_rev):
                return None

            # (optional) validate pallet_type exists
            cur.execute(self._sql.ps_check_pallet_type_exists(), (pallet_type,))
            if cur.fetchone() is None:
                return None

            # Determine insertion index from current view
            cur.execute(self._sql.ps_get_pairs_by_line(), (l_id,))
            existing = cur.fetchall()
            n = len(existing)
            target_idx = before_index if (before_index is not None and 0 <= int(before_index) <= n) else n

            # Shift up and insert
            cur.execute(self._sql.ps_shift_pairs_up(), (l_id, target_idx))
            cur.execute(self._sql.ps_insert_pair(), (l_id, target_idx, pallet_type, count))

            # CAS bump
            cur.execute(self._sql.ps_bump_status_rev_cas(), (l_id, current_rev))
            if cur.rowcount != 1:
                conn.rollback()
                return None

            conn.commit()
            return self.ps_get_line(line_name)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_delete_pair(self, line_name: str, pair_index: int, current_rev: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            cur.execute(self._sql.ps_get_line_by_name(), (line_name,))
            line = cur.fetchone()
            if not line:
                return None
            l_id, db_rev = line["line_id"], int(line["rev"])
            if db_rev != int(current_rev):
                return None

            cur.execute(self._sql.ps_delete_pair(), (l_id, pair_index))
            cur.execute(self._sql.ps_shift_pairs_down(), (l_id, pair_index))

            cur.execute(self._sql.ps_bump_status_rev_cas(), (l_id, current_rev))
            if cur.rowcount != 1:
                conn.rollback()
                return None

            conn.commit()
            return self.ps_get_line(line_name)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_move_to_group0(self, line_name: str, pair_index: int, current_rev: int) -> Optional[PalletScheduleLine]:
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)

            cur.execute(self._sql.ps_get_line_by_name(), (line_name,))
            line = cur.fetchone()
            if not line:
                return None
            l_id, db_rev = line["line_id"], int(line["rev"])
            if db_rev != int(current_rev):
                return None

            # Move target out
            cur.execute("UPDATE t_pallet_supply_pairs SET pair_index = -1 WHERE line_id = %s AND pair_index = %s", (l_id, pair_index))
            # Close gap
            cur.execute(self._sql.ps_shift_pairs_down(), (l_id, pair_index))
            # Open gap at 0
            cur.execute(self._sql.ps_shift_pairs_up(), (l_id, 0))
            # Place at 0
            cur.execute("UPDATE t_pallet_supply_pairs SET pair_index = 0 WHERE line_id = %s AND pair_index = -1", (l_id,))

            # CAS bump
            cur.execute(self._sql.ps_bump_status_rev_cas(), (l_id, current_rev))
            if cur.rowcount != 1:
                conn.rollback()
                return None

            conn.commit()
            return self.ps_get_line(line_name)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def ps_get_line(self, line_name: str) -> Optional[PalletScheduleLine]:
        """Helper to refresh a single line row in UI"""
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(self._sql.ps_get_line_by_name(), (line_name,))
            row = cur.fetchone()
            if not row: return None
            cur.execute(self._sql.ps_get_pairs_by_line(), (row['line_id'],))
            return WorkerFactory.pallet_schedule_line_from_rows(
                line_name=line_name, rows=cur.fetchall(), rev=row['rev'], line_id=row['line_id']
            )
        finally:
            conn.close()
    
    def get_all_master_pallets(self) -> List[Dict]:
        """Service calls this exactly"""
        # Use self._queries (not self._sql if you renamed it)
        sql = self._sql.ps_get_all_master_pallets() 
        conn = self._db.get_connection(self._db_name)
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql)
            return cur.fetchall()
        except Exception as e:
            print(f"Database Error: {e}") # This will show in your terminal
            raise e
        finally:
            conn.close()

